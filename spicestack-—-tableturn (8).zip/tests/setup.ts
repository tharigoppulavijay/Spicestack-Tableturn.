import fs from 'fs';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import { afterAll } from 'vitest';

const tempDbPath = path.join(
  os.tmpdir(),
  `spicestack-test-${process.pid}-${crypto.randomUUID()}.db`
);

process.env.NODE_ENV = 'test';
process.env.DB_PATH = tempDbPath;
process.env.AUTH_SECRET = 'vitest-strong-hmac-secret-key-at-least-32-chars-long';

afterAll(() => {
  for (const suffix of ['', '-wal', '-shm']) {
    const file = `${tempDbPath}${suffix}`;
    if (fs.existsSync(file)) {
      try {
        fs.unlinkSync(file);
      } catch {
        // Ignore cleanup locks on shutdown
      }
    }
  }
});
