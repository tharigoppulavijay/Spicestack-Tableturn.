import { beforeAll, describe, expect, it } from 'vitest';
import { initializeDatabase } from '../backend/database/db.ts';
import { seedDatabaseIfEmpty } from '../backend/database/seed.ts';
import {
  addDaysToDate,
  allocateBestTable,
  calculateTargetPrepStart,
  computeTicketRuntime,
  deriveCustomerOrderStage,
  isWithinOpeningHours,
} from '../backend/services/kitchenEngine.ts';
import type { ClockState, KitchenTicket, Reservation, ReservationStatus } from '../src/types/index.ts';

function makeClock(date: string, time: string): ClockState {
  return {
    mode: 'simulated',
    current_date: date,
    current_time: time,
    current_iso: `${date}T${time}:00`,
    display_time: time,
  };
}

function makeTicket(
  overrides: Partial<KitchenTicket> & {
    reservation_date?: string;
    arrival_time?: string;
    reservation_status?: ReservationStatus;
  } = {}
): KitchenTicket & { reservation_date?: string; arrival_time?: string; reservation_status?: ReservationStatus } {
  return {
    id: 1,
    reservation_id: 1,
    pre_order_id: 1,
    item_name: 'Chicken Biryani',
    quantity: 1,
    table_number: 'Table 4',
    booking_code: 'SS-8000',
    target_prep_start: '2026-05-10T19:40:00',
    preparation_time: 20,
    status: 'Pending' as const,
    priority: 'Normal' as const,
    allergies: 'Dairy',
    notes: '',
    started_at: null,
    ready_at: null,
    reservation_date: '2026-05-10',
    arrival_time: '20:00',
    reservation_status: 'Confirmed',
    ...overrides,
  };
}

describe('Arrival-Synchronized Kitchen Engine', () => {
  beforeAll(() => {
    initializeDatabase();
    seedDatabaseIfEmpty();
  });

  it('calculates TargetPrepStart = GuestArrivalTime - DishPrepTime cleanly', () => {
    expect(calculateTargetPrepStart('2026-05-10', '20:00', 20)).toBe('2026-05-10T19:40:00');
    expect(calculateTargetPrepStart('2026-05-10', '20:00', 5)).toBe('2026-05-10T19:55:00');
    expect(calculateTargetPrepStart('2026-05-10', '12:15', 30)).toBe('2026-05-10T11:45:00');
  });

  it('handles midnight date boundaries without losing the previous calendar date', () => {
    expect(calculateTargetPrepStart('2026-05-10', '00:10', 25)).toBe('2026-05-09T23:45:00');
    expect(addDaysToDate('2026-05-31', 1)).toBe('2026-06-01');
  });

  it('transitions priority Normal -> High (<=5m to fire) -> Urgent (at fire time)', () => {
    const ticket = makeTicket();

    const at725 = computeTicketRuntime(ticket, makeClock('2026-05-10', '19:25'));
    expect(at725.should_fire_now).toBe(false);
    expect(at725.minutes_until_fire).toBe(15);
    expect(at725.minutes_until_arrival).toBe(35);
    expect(at725.priority).toBe('Normal');
    expect(at725.fire_alert_message).toBeNull();

    const at736 = computeTicketRuntime(ticket, makeClock('2026-05-10', '19:36'));
    expect(at736.should_fire_now).toBe(false);
    expect(at736.minutes_until_fire).toBe(4);
    expect(at736.priority).toBe('High');

    const at740 = computeTicketRuntime(ticket, makeClock('2026-05-10', '19:40'));
    expect(at740.should_fire_now).toBe(true);
    expect(at740.is_overdue).toBe(false);
    expect(at740.priority).toBe('Urgent');
    expect(at740.fire_alert_message).toBe('FIRE DISH NOW — GUEST ARRIVES IN 20 MINUTES');
  });

  it('tracks remaining cook time and overdue cooking alerts while Cooking', () => {
    const cookingTicket = makeTicket({
      status: 'Cooking',
      started_at: '2026-05-10T19:40:00',
    });

    const midCook = computeTicketRuntime(cookingTicket, makeClock('2026-05-10', '19:52'));
    expect(midCook.cooking_remaining_minutes).toBe(8);
    expect(midCook.is_overdue).toBe(false);

    const overdueCook = computeTicketRuntime(cookingTicket, makeClock('2026-05-10', '20:05'));
    expect(overdueCook.cooking_remaining_minutes).toBe(0);
    expect(overdueCook.is_overdue).toBe(true);
  });

  it('escalates immediately to Urgent when guest checks in early', () => {
    const earlyCheckIn = computeTicketRuntime(
      makeTicket({ reservation_status: 'Checked In' }),
      makeClock('2026-05-10', '19:25')
    );

    expect(earlyCheckIn.should_fire_now).toBe(true);
    expect(earlyCheckIn.priority).toBe('Urgent');
    expect(earlyCheckIn.fire_alert_message).toContain('GUEST CHECKED IN');
  });

  it('flags overdue tickets when arrival time has passed without starting', () => {
    const overdue = computeTicketRuntime(
      makeTicket(),
      makeClock('2026-05-10', '20:05')
    );

    expect(overdue.should_fire_now).toBe(true);
    expect(overdue.is_overdue).toBe(true);
    expect(overdue.priority).toBe('Urgent');
    expect(overdue.fire_alert_message).toContain('OVERDUE FIRE');
  });

  it('derives customer tracker stages accurately including Ready and Cancelled', () => {
    const baseRes = { status: 'Confirmed' } as Reservation;
    expect(deriveCustomerOrderStage(baseRes, [])).toBe('Reservation Confirmed');
    expect(deriveCustomerOrderStage(baseRes, [makeTicket()])).toBe('Order Confirmed');
    expect(deriveCustomerOrderStage(baseRes, [{ ...makeTicket(), should_fire_now: true }])).toBe(
      'Waiting for Preparation'
    );
    expect(deriveCustomerOrderStage(baseRes, [{ ...makeTicket(), status: 'Cooking' }])).toBe('Cooking');
    expect(deriveCustomerOrderStage(baseRes, [{ ...makeTicket(), status: 'Ready' }])).toBe('Ready / Plated');
    expect(deriveCustomerOrderStage(baseRes, [{ ...makeTicket(), status: 'Served' }])).toBe('Served');
    expect(deriveCustomerOrderStage({ status: 'Cancelled' } as Reservation, [makeTicket()])).toBe('Cancelled');
  });

  it('validates opening hours and optimal table capacity allocation', () => {
    expect(isWithinOpeningHours('11:00', '11:00 - 23:30')).toBe(true);
    expect(isWithinOpeningHours('23:00', '11:00 - 23:30')).toBe(true);
    expect(isWithinOpeningHours('23:15', '11:00 - 23:30')).toBe(false);
    expect(isWithinOpeningHours('09:30', '11:00 - 23:30')).toBe(false);

    const bestForTwo = allocateBestTable('2026-05-20', '20:00', 2);
    expect(bestForTwo?.capacity).toBeGreaterThanOrEqual(2);
    expect(bestForTwo?.capacity).toBe(2);

    const noneForTooLarge = allocateBestTable('2026-05-20', '20:00', 18);
    expect(noneForTooLarge).toBeNull();
  });
});
