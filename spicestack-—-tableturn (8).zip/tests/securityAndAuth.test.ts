import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import express from 'express';
import request from 'supertest';
import { beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { initializeDatabase } from '../backend/database/db.ts';
import { seedDatabaseIfEmpty } from '../backend/database/seed.ts';
import { createApp } from '../backend/app.ts';
import {
  isDemoAuthEnabled,
  isWeakSecret,
  resolveRuntimeSecret,
  signToken,
  verifyToken,
} from '../backend/middleware/auth.ts';
import {
  clearRateLimiters,
  createRateLimiter,
  getRateLimiterStats,
} from '../backend/middleware/security.ts';
import type { User } from '../src/types/index.ts';

const app = createApp();

describe('Security, Secret Enforcement, Demo Auth Policy, Rate Limiter Bounds & Probes', () => {
  beforeAll(() => {
    initializeDatabase();
    seedDatabaseIfEmpty();
  });

  beforeEach(() => {
    clearRateLimiters();
  });

  describe('Secret Validation & Production Startup Guards', () => {
    it('rejects missing, short, placeholder, or low-entropy secrets in production without generating fallbacks', () => {
      expect(() => resolveRuntimeSecret({ NODE_ENV: 'production' })).toThrow(/AUTH_SECRET/);
      expect(() =>
        resolveRuntimeSecret({ NODE_ENV: 'production', AUTH_SECRET: 'too-short-secret' })
      ).toThrow(/AUTH_SECRET/);
      expect(() =>
        resolveRuntimeSecret({
          NODE_ENV: 'production',
          AUTH_SECRET: 'REPLACE_WITH_STRONG_RANDOM_64_CHAR_HEX_SECRET',
        })
      ).toThrow(/AUTH_SECRET/);
      expect(() =>
        resolveRuntimeSecret({
          NODE_ENV: 'production',
          AUTH_SECRET: 'a'.repeat(48),
        })
      ).toThrow(/AUTH_SECRET/);

      const strong = crypto.randomBytes(32).toString('hex');
      expect(isWeakSecret(strong)).toBe(false);
      expect(resolveRuntimeSecret({ NODE_ENV: 'production', AUTH_SECRET: strong })).toBe(strong);

      // Never writes a .spicestack-auth.key fallback file to workspace root
      expect(fs.existsSync(path.resolve(process.cwd(), '.spicestack-auth.key'))).toBe(false);
    });

    it('verifies token issuer, expiry, issued-at, and rejects tampered signatures or payloads', () => {
      const user: User = {
        id: 1,
        name: 'Aarav Sharma',
        email: 'customer@spicestack.io',
        role: 'customer',
        phone: '+91 98450 11223',
      };
      const valid = signToken(user, 300);
      expect(verifyToken(valid)?.email).toBe(user.email);

      const [payload, sig] = valid.split('.');
      const tamperedPayload = Buffer.from(
        JSON.stringify({ ...JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')), role: 'manager' })
      ).toString('base64url');
      expect(verifyToken(`${tamperedPayload}.${sig}`)).toBeNull();
      expect(verifyToken(`${payload}.${sig.slice(0, -2)}xx`)).toBeNull();
      expect(verifyToken('malformed-token')).toBeNull();
    });
  });

  describe('Environment-Aware Demo Auth & Clock Guards', () => {
    it('evaluates isDemoAuthEnabled cleanly across dev, test, production, and hackathon mode', () => {
      expect(isDemoAuthEnabled({ NODE_ENV: 'development' })).toBe(true);
      expect(isDemoAuthEnabled({ NODE_ENV: 'test' })).toBe(true);
      expect(isDemoAuthEnabled({ NODE_ENV: 'development', ALLOW_DEMO_AUTH: 'false' })).toBe(false);
      expect(isDemoAuthEnabled({ NODE_ENV: 'production' })).toBe(false);
      expect(isDemoAuthEnabled({ NODE_ENV: 'production', ALLOW_DEMO_AUTH: 'true' })).toBe(true);
      expect(isDemoAuthEnabled({ NODE_ENV: 'production', HACKATHON_DEMO_MODE: 'true' })).toBe(true);
    });

    it('blocks /api/auth/login-demo and restricts /api/clock in production when demo auth is disabled', async () => {
      const prevEnv = process.env.NODE_ENV;
      const prevAllow = process.env.ALLOW_DEMO_AUTH;
      const prevHackathon = process.env.HACKATHON_DEMO_MODE;

      process.env.NODE_ENV = 'production';
      delete process.env.ALLOW_DEMO_AUTH;
      delete process.env.HACKATHON_DEMO_MODE;

      try {
        const demoUsersRes = await request(app).get('/api/auth/demo-users');
        expect(demoUsersRes.status).toBe(200);
        expect(demoUsersRes.body).toEqual({ demoEnabled: false, users: [] });

        const loginDemoRes = await request(app).post('/api/auth/login-demo').send({ role: 'manager' });
        expect(loginDemoRes.status).toBe(403);

        const unauthClock = await request(app).post('/api/clock').send({ advanceMinutes: 5 });
        expect(unauthClock.status).toBe(401);

        const customerToken = signToken({
          id: 1,
          name: 'Guest',
          email: 'customer@spicestack.io',
          role: 'customer',
          phone: '',
        });
        const customerClock = await request(app)
          .post('/api/clock')
          .set('Authorization', `Bearer ${customerToken}`)
          .send({ advanceMinutes: 5 });
        expect(customerClock.status).toBe(403);

        const managerToken = signToken({
          id: 4,
          name: 'Manager',
          email: 'manager@spicestack.io',
          role: 'manager',
          phone: '',
        });
        const managerClock = await request(app)
          .post('/api/clock')
          .set('Authorization', `Bearer ${managerToken}`)
          .send({ time: '19:25' });
        expect(managerClock.status).toBe(200);
      } finally {
        process.env.NODE_ENV = prevEnv;
        if (prevAllow !== undefined) process.env.ALLOW_DEMO_AUTH = prevAllow;
        if (prevHackathon !== undefined) process.env.HACKATHON_DEMO_MODE = prevHackathon;
      }
    });
  });

  describe('Bounded Rate Limiting & Health/Readiness Probes', () => {
    it('caps in-memory rate-limit buckets at maxKeys and exposes standard rate-limit headers', async () => {
      const miniApp = express();
      miniApp.set('trust proxy', true);
      miniApp.get(
        '/limited',
        createRateLimiter({ windowMs: 60_000, max: 2, keyPrefix: 'test-cap', maxKeys: 10 }),
        (_req, res) => res.json({ ok: true })
      );

      for (let i = 1; i <= 25; i++) {
        const res = await request(miniApp).get('/limited').set('X-Forwarded-For', `10.0.0.${i}`);
        expect(res.status).toBe(200);
        expect(res.headers['x-ratelimit-limit']).toBe('2');
        expect(res.headers['x-ratelimit-remaining']).toBe('1');
        expect(res.headers['x-ratelimit-reset']).toBeTruthy();
      }
      expect(getRateLimiterStats().size).toBeLessThanOrEqual(10);

      // Same IP exceeding max gets 429 with Retry-After
      await request(miniApp).get('/limited').set('X-Forwarded-For', '10.0.0.25');
      const blocked = await request(miniApp).get('/limited').set('X-Forwarded-For', '10.0.0.25');
      expect(blocked.status).toBe(429);
      expect(blocked.headers['retry-after']).toBeTruthy();
    });

    it('returns sanitized database health status from /api/health, /api/health/live, and /api/health/ready', async () => {
      const [health, live, ready] = await Promise.all([
        request(app).get('/api/health'),
        request(app).get('/api/health/live'),
        request(app).get('/api/health/ready'),
      ]);

      expect(live.status).toBe(200);
      expect(live.body.status).toBe('alive');

      for (const probe of [health, ready]) {
        expect(probe.status).toBe(200);
        expect(probe.body.status).toBe('ok');
        expect(probe.body.readiness).toBe('ready');
        expect(probe.body.database).toBe('connected');
        expect(JSON.stringify(probe.body)).not.toMatch(/AUTH_SECRET|spicestack\.db|password/i);
      }
    });
  });
});
