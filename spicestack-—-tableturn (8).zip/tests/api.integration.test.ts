import fs from 'fs';
import path from 'path';
import request from 'supertest';
import { beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { initializeDatabase, db } from '../backend/database/db.ts';
import { seedDatabaseIfEmpty } from '../backend/database/seed.ts';
import { createApp } from '../backend/app.ts';
import { clearIdempotencyCache, clearRateLimiters } from '../backend/middleware/security.ts';
import { signToken } from '../backend/middleware/auth.ts';
import type { User } from '../src/types/index.ts';

const app = createApp();

let customerToken = '';
let hostessToken = '';
let kitchenToken = '';
let managerToken = '';
let currentDate = '';

async function loginRole(role: User['role']): Promise<string> {
  const res = await request(app).post('/api/auth/login-demo').send({ role });
  expect(res.status).toBe(200);
  return res.body.token as string;
}

describe('SpiceStack — TableTurn Full API Integration Suite', () => {
  beforeAll(async () => {
    initializeDatabase();
    seedDatabaseIfEmpty();
    const settingsRes = await request(app).get('/api/settings');
    expect(settingsRes.status).toBe(200);
    currentDate = settingsRes.body.clock.current_date as string;

    [customerToken, hostessToken, kitchenToken, managerToken] = await Promise.all([
      loginRole('customer'),
      loginRole('hostess'),
      loginRole('kitchen'),
      loginRole('manager'),
    ]);
  });

  beforeEach(() => {
    clearRateLimiters();
    clearIdempotencyCache();
  });

  describe('Security, Authentication, RBAC & Validation', () => {
    it('attaches security headers, X-Request-Id, readiness endpoint, and serves demo-users without SQL errors', async () => {
      const [res, demoRes, healthRes] = await Promise.all([
        request(app).get('/api/settings'),
        request(app).get('/api/auth/demo-users'),
        request(app).get('/api/health'),
      ]);
      expect(res.status).toBe(200);
      expect(res.headers['x-content-type-options']).toBe('nosniff');
      expect(res.headers['x-frame-options']).toBe('SAMEORIGIN');
      expect(res.headers['x-request-id']).toBeTruthy();
      expect(res.headers['x-powered-by']).toBeUndefined();

      expect(demoRes.status).toBe(200);
      expect(demoRes.body.demoEnabled).toBe(true);
      expect(demoRes.body.users).toHaveLength(4);

      expect(healthRes.status).toBe(200);
      expect(healthRes.body.status).toBe('ok');
      expect(healthRes.body.database).toBe('connected');
      expect(healthRes.body.timestamp).toBeTruthy();
    });

    it('rejects privilege-escalation fields on register, enforces customer role, and verifies login', async () => {
      const email = `priya-${Date.now()}@example.com`;
      const escalatedReg = await request(app).post('/api/auth/register').send({
        name: 'Priya Nair',
        email,
        password: 'StrongPassword123',
        phone: '+91 99000 12345',
        role: 'manager',
      });
      expect(escalatedReg.status).toBe(400);

      const regRes = await request(app).post('/api/auth/register').send({
        name: 'Priya Nair',
        email,
        password: 'StrongPassword123',
        phone: '+91 99000 12345',
      });
      expect(regRes.status).toBe(201);
      expect(regRes.body.user.role).toBe('customer');
      expect(regRes.body.token).toBeTruthy();

      const badLogin = await request(app).post('/api/auth/login').send({
        email,
        password: 'WrongPassword',
      });
      expect(badLogin.status).toBe(401);

      const goodLogin = await request(app).post('/api/auth/login').send({
        email,
        password: 'StrongPassword123',
      });
      expect(goodLogin.status).toBe(200);
      expect(goodLogin.body.user.email).toBe(email);
    });

    it('rejects expired tokens and enforces strict RBAC matrix across all 4 roles', async () => {
      const expiredToken = signToken(
        { id: 4, name: 'Maya', email: 'manager@spicestack.io', role: 'manager', phone: '' },
        -30
      );
      const meRes = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${expiredToken}`);
      expect(meRes.body.user).toBeNull();

      expect((await request(app).get('/api/admin/analytics')).status).toBe(401);
      expect(
        (await request(app).get('/api/admin/analytics').set('Authorization', `Bearer ${customerToken}`)).status
      ).toBe(403);
      expect(
        (await request(app).get('/api/admin/analytics').set('Authorization', `Bearer ${hostessToken}`)).status
      ).toBe(403);
      expect(
        (await request(app).get('/api/admin/analytics').set('Authorization', `Bearer ${kitchenToken}`)).status
      ).toBe(403);
      expect(
        (await request(app).get('/api/admin/analytics').set('Authorization', `Bearer ${managerToken}`)).status
      ).toBe(200);

      expect(
        (await request(app).get('/api/kitchen/tickets').set('Authorization', `Bearer ${customerToken}`)).status
      ).toBe(403);
      expect(
        (await request(app).get('/api/kitchen/tickets').set('Authorization', `Bearer ${kitchenToken}`)).status
      ).toBe(200);
      expect(
        (await request(app).get('/api/kitchen/tickets').set('Authorization', `Bearer ${hostessToken}`)).status
      ).toBe(200);

      const anonList = await request(app).get('/api/reservations');
      expect(anonList.status).toBe(200);
      expect(anonList.body.reservations).toEqual([]);
    });

    it('rejects invalid payloads, unknown fields, and bad query params via strict Zod validation', async () => {
      const badMenu = await request(app)
        .post('/api/admin/menu')
        .set('Authorization', `Bearer ${managerToken}`)
        .send({ name: '', price: -50, category_id: 'abc' });
      expect(badMenu.status).toBe(400);

      const unknownField = await request(app)
        .post('/api/auth/login-demo')
        .send({ role: 'customer', extraAdminFlag: true });
      expect(unknownField.status).toBe(400);

      const badQuery = await request(app).get('/api/tables?date=invalid-date');
      expect(badQuery.status).toBe(400);

      const badRes = await request(app)
        .post('/api/reservations')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          customer_name: 'A',
          phone: '12',
          date: 'not-a-date',
          arrival_time: '99:99',
          party_size: 99,
        });
      expect(badRes.status).toBe(400);
    });

    it('enforces sliding-window rate limiting (HTTP 429) on auth endpoints', async () => {
      let lastStatus = 200;
      for (let i = 0; i < 27; i++) {
        const res = await request(app).post('/api/auth/login').send({
          email: 'customer@spicestack.io',
          password: 'wrong',
        });
        lastStatus = res.status;
        if (res.status === 429) {
          expect(res.headers['retry-after']).toBeTruthy();
          expect(res.headers['x-ratelimit-remaining']).toBe('0');
          break;
        }
      }
      expect(lastStatus).toBe(429);
    });
  });

  describe('Reservation Validation, Concurrency, Idempotency & Inventory Restoration', () => {
    it('rejects past dates, outside opening hours, and handles concurrent double-booking race safely', async () => {
      const pastRes = await request(app)
        .post('/api/reservations')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          customer_name: 'Past Tester',
          phone: '+91 90000 11111',
          date: '2020-01-01',
          arrival_time: '19:00',
          party_size: 2,
          auto_allocate: true,
        });
      expect(pastRes.status).toBe(400);

      const lateHourRes = await request(app)
        .post('/api/reservations')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          customer_name: 'Late Tester',
          phone: '+91 90000 11112',
          date: currentDate,
          arrival_time: '23:25',
          party_size: 2,
          auto_allocate: true,
        });
      expect(lateHourRes.status).toBe(400);

      const tablesRes = await request(app).get('/api/tables');
      const table5 = (tablesRes.body.tables as Array<{ id: number; table_number: string }>).find(
        (t) => t.table_number === 'Table 5'
      );
      expect(table5).toBeTruthy();

      const tomorrow = new Date(`${currentDate}T00:00:00`);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const futureDate = tomorrow.toISOString().slice(0, 10);

      const [r1, r2] = await Promise.all([
        request(app)
          .post('/api/reservations')
          .set('Authorization', `Bearer ${customerToken}`)
          .send({
            customer_name: 'Concurrent Guest 1',
            phone: '+91 91111 00001',
            date: futureDate,
            arrival_time: '20:00',
            party_size: 4,
            table_id: table5!.id,
          }),
        request(app)
          .post('/api/reservations')
          .set('Authorization', `Bearer ${customerToken}`)
          .send({
            customer_name: 'Concurrent Guest 2',
            phone: '+91 91111 00002',
            date: futureDate,
            arrival_time: '20:30',
            party_size: 4,
            table_id: table5!.id,
          }),
      ]);

      const statuses = [r1.status, r2.status].sort();
      expect(statuses).toEqual([201, 409]);
    });

    it('supports Idempotency-Key replay safely and restores inventory stock once on cancellation', async () => {
      const menuRes = await request(app).get('/api/menu');
      const biryani = (menuRes.body.items as Array<{ id: number; name: string; stock_quantity: number }>).find(
        (m) => m.name === 'Chicken Biryani'
      );
      expect(biryani).toBeTruthy();
      const initialStock = biryani!.stock_quantity;

      const tomorrow = new Date(`${currentDate}T00:00:00`);
      tomorrow.setDate(tomorrow.getDate() + 2);
      const bookDate = tomorrow.toISOString().slice(0, 10);

      const payload = {
        customer_name: 'Stock Test Guest',
        phone: '+91 97777 88888',
        date: bookDate,
        arrival_time: '19:30',
        party_size: 2,
        auto_allocate: true,
        items: [{ menu_item_id: biryani!.id, quantity: 3 }],
      };

      const idemCreateKey = `create-${Date.now()}`;
      const first = await request(app)
        .post('/api/reservations')
        .set('Authorization', `Bearer ${customerToken}`)
        .set('Idempotency-Key', idemCreateKey)
        .send(payload);
      expect(first.status).toBe(201);
      const reservationId = first.body.reservation.id as number;

      // Retry with same Idempotency-Key replays cached 201 cleanly without double decrementing stock
      const replay = await request(app)
        .post('/api/reservations')
        .set('Authorization', `Bearer ${customerToken}`)
        .set('Idempotency-Key', idemCreateKey)
        .send(payload);
      expect(replay.status).toBe(201);
      expect(replay.headers['x-idempotent-replay']).toBe('true');
      expect(replay.body.reservation.id).toBe(reservationId);

      // Different/missing Idempotency-Key duplicate submission rejected with 409
      const dup = await request(app)
        .post('/api/reservations')
        .set('Authorization', `Bearer ${customerToken}`)
        .send(payload);
      expect(dup.status).toBe(409);

      const afterOrderRow = db.prepare('SELECT stock_quantity FROM menu_items WHERE id = ?').get(biryani!.id) as {
        stock_quantity: number;
      };
      expect(afterOrderRow.stock_quantity).toBe(initialStock - 3);

      // Cancel booking with Idempotency-Key -> stock restored once
      const idemCancelKey = `cancel-${Date.now()}`;
      const cancelRes = await request(app)
        .post(`/api/reservations/${reservationId}/cancel`)
        .set('Authorization', `Bearer ${customerToken}`)
        .set('Idempotency-Key', idemCancelKey);
      expect(cancelRes.status).toBe(200);

      const cancelReplay = await request(app)
        .post(`/api/reservations/${reservationId}/cancel`)
        .set('Authorization', `Bearer ${customerToken}`)
        .set('Idempotency-Key', idemCancelKey);
      expect(cancelReplay.status).toBe(200);
      expect(cancelReplay.headers['x-idempotent-replay']).toBe('true');

      const afterCancelRow = db.prepare('SELECT stock_quantity FROM menu_items WHERE id = ?').get(biryani!.id) as {
        stock_quantity: number;
      };
      expect(afterCancelRow.stock_quantity).toBe(initialStock);

      // Double cancel without idempotency key rejected -> stock not double-restored
      const doubleCancel = await request(app)
        .post(`/api/reservations/${reservationId}/cancel`)
        .set('Authorization', `Bearer ${customerToken}`);
      expect(doubleCancel.status).toBe(400);

      const finalStockRow = db.prepare('SELECT stock_quantity FROM menu_items WHERE id = ?').get(biryani!.id) as {
        stock_quantity: number;
      };
      expect(finalStockRow.stock_quantity).toBe(initialStock);
    });
  });

  describe('Billing Preview, Split Bill & Inventory PATCH APIs', () => {
    it('calculates order totals, splits bills, and patches inventory safely', async () => {
      const calcRes = await request(app)
        .post('/api/billing/calculate')
        .send({
          items: [
            { price: 620, quantity: 1 },
            { price: 420, quantity: 2 },
          ],
          discount_percentage: 10,
        });
      expect(calcRes.status).toBe(200);
      expect(calcRes.body.bill.subtotal).toBe(1460);
      expect(calcRes.body.bill.discountAmount).toBe(146);
      expect(calcRes.body.bill.discountedSubtotal).toBe(1314);
      expect(calcRes.body.bill.totalAmount).toBe(1511.1);

      const equalSplitRes = await request(app)
        .post('/api/billing/split')
        .send({ mode: 'equal', total_amount: 100, diners: 3 });
      expect(equalSplitRes.status).toBe(200);
      expect(equalSplitRes.body.equal.shares).toEqual([33.34, 33.33, 33.33]);

      const menuRes = await request(app).get('/api/menu');
      const dish = menuRes.body.items[0] as { id: number; stock_quantity: number };
      const patchRes = await request(app)
        .patch(`/api/admin/inventory/${dish.id}`)
        .set('Authorization', `Bearer ${managerToken}`)
        .send({ stock_quantity: 0 });
      expect(patchRes.status).toBe(200);
      expect(patchRes.body.item.availability).toBe(0);

      // Restore original stock
      const restoreRes = await request(app)
        .patch(`/api/admin/inventory/${dish.id}`)
        .set('Authorization', `Bearer ${managerToken}`)
        .send({ stock_quantity: dish.stock_quantity, availability: 1 });
      expect(restoreRes.status).toBe(200);
      expect(restoreRes.body.item.availability).toBe(1);
    });
  });

  describe('End-to-End Culinary Sync Walkthrough (8:00 PM Table 4 + Chicken Biryani -> 7:40 PM Fire)', () => {
    it('syncs reservation, billing, 7:40 PM kitchen alert, state transitions, customer tracker, hostess check-in, and analytics', async () => {
      await request(app).post('/api/clock').send({ date: currentDate, time: '19:25' });

      const tablesRes = await request(app).get(`/api/tables?date=${currentDate}&time=20:00&partySize=4`);
      const table4 = (tablesRes.body.tables as Array<{ id: number; table_number: string; is_available_for_slot: boolean }>).find(
        (t) => t.table_number === 'Table 4'
      );
      expect(table4).toBeTruthy();
      expect(table4!.is_available_for_slot).toBe(true);

      const menuRes = await request(app).get('/api/menu');
      const biryani = (menuRes.body.items as Array<{ id: number; name: string; price: number; preparation_time: number }>).find(
        (m) => m.name === 'Chicken Biryani'
      );
      expect(biryani).toBeTruthy();
      expect(biryani!.preparation_time).toBe(20);

      const createRes = await request(app)
        .post('/api/reservations')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          customer_name: 'Walkthrough Guest',
          phone: '+91 96666 55555',
          email: 'customer@spicestack.io',
          date: currentDate,
          arrival_time: '20:00',
          party_size: 4,
          table_id: table4!.id,
          items: [{ menu_item_id: biryani!.id, quantity: 1, customization_notes: 'Extra Raita' }],
        });

      expect(createRes.status).toBe(201);
      const reservation = createRes.body.reservation;
      expect(reservation.table_number).toBe('Table 4');
      expect(reservation.subtotal).toBe(620);
      expect(reservation.gst_amount).toBe(31);
      expect(reservation.service_charge_amount).toBe(62);
      expect(reservation.total_amount).toBe(713);
      expect(reservation.tickets).toHaveLength(1);
      expect(reservation.tickets[0].target_prep_start).toBe(`${currentDate}T19:40:00`);
      const ticketId = reservation.tickets[0].id as number;

      const clockRes = await request(app).post('/api/clock').send({ date: currentDate, time: '19:40' });
      expect(clockRes.status).toBe(200);
      expect(clockRes.body.clock.current_time).toBe('19:40');

      const kdsAt740 = await request(app)
        .get('/api/kitchen/tickets')
        .set('Authorization', `Bearer ${kitchenToken}`);
      expect(kdsAt740.status).toBe(200);
      const ourTickets = (kdsAt740.body.tickets as Array<{
        id: number;
        should_fire_now: boolean;
        priority: string;
        fire_alert_message: string;
      }>).filter((t) => t.id === ticketId);
      expect(ourTickets).toHaveLength(1);
      expect(ourTickets[0].should_fire_now).toBe(true);
      expect(ourTickets[0].priority).toBe('Urgent');
      expect(ourTickets[0].fire_alert_message).toBe('FIRE DISH NOW — GUEST ARRIVES IN 20 MINUTES');

      const skipJump = await request(app)
        .patch(`/api/kitchen/tickets/${ticketId}`)
        .set('Authorization', `Bearer ${kitchenToken}`)
        .send({ status: 'Served' });
      expect(skipJump.status).toBe(409);

      const startCooking = await request(app)
        .patch(`/api/kitchen/tickets/${ticketId}`)
        .set('Authorization', `Bearer ${kitchenToken}`)
        .send({ status: 'Cooking' });
      expect(startCooking.status).toBe(200);
      expect(startCooking.body.ticket.status).toBe('Cooking');

      const dupCooking = await request(app)
        .patch(`/api/kitchen/tickets/${ticketId}`)
        .set('Authorization', `Bearer ${kitchenToken}`)
        .send({ status: 'Cooking' });
      expect(dupCooking.status).toBe(409);

      const trackerCooking = await request(app)
        .get(`/api/reservations?code=${reservation.booking_code}`)
        .set('Authorization', `Bearer ${customerToken}`);
      expect(trackerCooking.body.reservations[0].customer_order_stage).toBe('Cooking');

      await request(app).post('/api/clock').send({ advanceMinutes: 20 });
      const markReady = await request(app)
        .patch(`/api/kitchen/tickets/${ticketId}`)
        .set('Authorization', `Bearer ${kitchenToken}`)
        .send({ status: 'Ready' });
      expect(markReady.status).toBe(200);
      expect(markReady.body.ticket.status).toBe('Ready');

      const trackerReady = await request(app)
        .get(`/api/reservations?code=${reservation.booking_code}`)
        .set('Authorization', `Bearer ${customerToken}`);
      expect(trackerReady.body.reservations[0].customer_order_stage).toBe('Ready / Plated');

      const checkInRes = await request(app)
        .post(`/api/staff/reservations/${reservation.id}/check-in`)
        .set('Authorization', `Bearer ${hostessToken}`);
      expect(checkInRes.status).toBe(200);

      await request(app).post('/api/clock').send({ advanceMinutes: 45 });
      const completeRes = await request(app)
        .patch(`/api/staff/reservations/${reservation.id}`)
        .set('Authorization', `Bearer ${hostessToken}`)
        .send({ status: 'Completed' });
      expect(completeRes.status).toBe(200);

      const analyticsRes = await request(app)
        .get('/api/admin/analytics?range=today')
        .set('Authorization', `Bearer ${managerToken}`);
      expect(analyticsRes.status).toBe(200);
      expect(analyticsRes.body.kpis.completedReservations).toBeGreaterThanOrEqual(1);
      expect(analyticsRes.body.kpis.avgTurnaroundMinutes).toBeGreaterThan(0);
    });
  });

  describe('Upload Filtering, Settings Validation, Hostess Reassignment & Table Delete Guards', () => {
    it('rejects non-image uploads and accepts valid PNG images while cleaning up', async () => {
      const badUpload = await request(app)
        .post('/api/upload')
        .set('Authorization', `Bearer ${managerToken}`)
        .attach('image', Buffer.from('<script>alert(1)</script>'), {
          filename: 'xss.html',
          contentType: 'text/html',
        });
      expect(badUpload.status).toBe(400);

      const pngBytes = Buffer.from(
        'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
        'base64'
      );
      const okUpload = await request(app)
        .post('/api/upload')
        .set('Authorization', `Bearer ${managerToken}`)
        .attach('image', pngBytes, {
          filename: 'dish.png',
          contentType: 'image/png',
        });
      expect(okUpload.status).toBe(200);
      expect(okUpload.body.url).toMatch(/^\/uploads\/dish-.*\.png$/);

      const uploadedFile = path.resolve(process.cwd(), okUpload.body.url.replace(/^\//, ''));
      if (fs.existsSync(uploadedFile)) {
        fs.unlinkSync(uploadedFile);
      }
    });

    it('rejects invalid opening_hours formats and reversed close times on settings update', async () => {
      const badFormat = await request(app)
        .put('/api/admin/settings')
        .set('Authorization', `Bearer ${managerToken}`)
        .send({ opening_hours: 'noon to midnight' });
      expect(badFormat.status).toBe(400);

      const reversedHours = await request(app)
        .put('/api/admin/settings')
        .set('Authorization', `Bearer ${managerToken}`)
        .send({ opening_hours: '22:00 - 12:00' });
      expect(reversedHours.status).toBe(400);
    });

    it('enforces slot/capacity checks on hostess table reassignment and active-booking table delete protection', async () => {
      const t4Res = await request(app)
        .post('/api/admin/tables')
        .set('Authorization', `Bearer ${managerToken}`)
        .send({ table_number: 'QA-4Top', capacity: 4, type: 'Main Dining', section: 'Patio' });
      expect(t4Res.status).toBe(201);
      const t4Id = t4Res.body.table.id as number;

      const t2Res = await request(app)
        .post('/api/admin/tables')
        .set('Authorization', `Bearer ${managerToken}`)
        .send({ table_number: 'QA-2Top', capacity: 2, type: 'Window Booth', section: 'Window' });
      expect(t2Res.status).toBe(201);
      const t2Id = t2Res.body.table.id as number;

      const d = new Date(`${currentDate}T00:00:00`);
      d.setDate(d.getDate() + 3);
      const testDate = d.toISOString().slice(0, 10);

      const bookingRes = await request(app)
        .post('/api/reservations')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          customer_name: 'Reassign QA Guest',
          phone: '+91 98888 77777',
          date: testDate,
          arrival_time: '19:00',
          party_size: 4,
          table_id: t4Id,
        });
      expect(bookingRes.status).toBe(201);
      const resId = bookingRes.body.reservation.id as number;

      const badReassign = await request(app)
        .patch(`/api/staff/reservations/${resId}`)
        .set('Authorization', `Bearer ${hostessToken}`)
        .send({ table_id: t2Id });
      expect(badReassign.status).toBe(409);

      const blockedDelete = await request(app)
        .delete(`/api/admin/tables/${t4Id}`)
        .set('Authorization', `Bearer ${managerToken}`);
      expect(blockedDelete.status).toBe(409);

      const cancelRes = await request(app)
        .post(`/api/reservations/${resId}/cancel`)
        .set('Authorization', `Bearer ${hostessToken}`);
      expect(cancelRes.status).toBe(200);

      const del4 = await request(app)
        .delete(`/api/admin/tables/${t4Id}`)
        .set('Authorization', `Bearer ${managerToken}`);
      const del2 = await request(app)
        .delete(`/api/admin/tables/${t2Id}`)
        .set('Authorization', `Bearer ${managerToken}`);
      expect(del4.status).toBe(200);
      expect(del2.status).toBe(200);
    });
  });
});
