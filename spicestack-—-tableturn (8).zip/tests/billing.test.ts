import { describe, expect, it } from 'vitest';
import {
  calculateEqualSplit,
  calculateItemizedSplit,
  calculateOrderBill,
  roundMoney,
} from '../src/utils/billing.ts';

describe('Billing & Split-Bill Calculations', () => {
  it('computes accurate subtotal, GST (5%), service charge (10%), and total', () => {
    const bill = calculateOrderBill(
      [
        { price: 620, quantity: 2 }, // 1240
        { price: 380, quantity: 1 }, // 380
      ],
      5,
      10
    );

    expect(bill.subtotal).toBe(1620);
    expect(bill.discountAmount).toBe(0);
    expect(bill.gstAmount).toBe(81);
    expect(bill.serviceChargeAmount).toBe(162);
    expect(bill.totalAmount).toBe(1863);
  });

  it('applies percentage and flat discounts safely without ever producing negative totals', () => {
    const billWithPct = calculateOrderBill([{ price: 1000, quantity: 1 }], 5, 10, 10, 0);
    expect(billWithPct.subtotal).toBe(1000);
    expect(billWithPct.discountAmount).toBe(100);
    expect(billWithPct.discountedSubtotal).toBe(900);
    expect(billWithPct.gstAmount).toBe(45);
    expect(billWithPct.serviceChargeAmount).toBe(90);
    expect(billWithPct.totalAmount).toBe(1035);

    const overDiscounted = calculateOrderBill([{ price: 500, quantity: 1 }], 5, 10, 50, 400);
    expect(overDiscounted.discountAmount).toBe(500);
    expect(overDiscounted.discountedSubtotal).toBe(0);
    expect(overDiscounted.totalAmount).toBe(0);
  });

  it('guards against negative, NaN, and Infinity values cleanly', () => {
    const bill = calculateOrderBill(
      [
        { price: 500, quantity: 0 },
        { price: -100, quantity: 2 },
        { price: 250, quantity: -3 },
        { price: Number.NaN, quantity: 2 },
        { price: 200, quantity: Number.POSITIVE_INFINITY },
        { price: 400, quantity: 1 },
      ],
      Number.NaN,
      10
    );

    expect(bill.subtotal).toBe(400);
    expect(bill.gstAmount).toBe(0);
    expect(bill.serviceChargeAmount).toBe(40);
    expect(bill.totalAmount).toBe(440);
  });

  it('handles equal split rounding with remainder cents so shares sum strictly to total', () => {
    const split = calculateEqualSplit(100, 3);
    expect(split.diners).toBe(3);
    expect(split.shares).toEqual([33.34, 33.33, 33.33]);
    expect(split.remainderCents).toBe(1);
    expect(split.totalVerified).toBe(100);

    const oddSplit = calculateEqualSplit(713.5, 4);
    expect(oddSplit.totalVerified).toBe(713.5);
    expect(oddSplit.shares.reduce((s, x) => roundMoney(s + x), 0)).toBe(713.5);
  });

  it('computes itemized split with GST, service charge, and remaining balance', () => {
    const items = [
      { id: 1, price: 620, quantity: 1 },
      { id: 2, price: 420, quantity: 2 },
    ];
    const full = calculateOrderBill(items, 5, 10);
    const itemized = calculateItemizedSplit(items, [1], 5, 10, full.totalAmount);

    expect(itemized.subtotal).toBe(620);
    expect(itemized.gstAmount).toBe(31);
    expect(itemized.serviceChargeAmount).toBe(62);
    expect(itemized.selectedTotal).toBe(713);
    expect(roundMoney(itemized.selectedTotal + itemized.remainingTotal)).toBe(full.totalAmount);
  });
});
