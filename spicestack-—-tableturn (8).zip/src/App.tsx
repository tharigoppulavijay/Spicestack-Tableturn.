import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { CartDrawer } from './components/CartDrawer';
import { AuthModal } from './components/AuthModal';
import { DemoClockDock } from './components/DemoClockDock';
import { ToastContainer } from './components/ToastContainer';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LandingPage } from './pages/LandingPage';
import { MenuPage } from './pages/MenuPage';
import { ReservePage } from './pages/ReservePage';
import { MyReservationsPage } from './pages/MyReservationsPage';
import { HostessPortalPage } from './pages/HostessPortalPage';
import { KitchenDisplayPage } from './pages/KitchenDisplayPage';
import { AdminLayout } from './layouts/AdminLayout';
import { AdminOverviewPage } from './pages/admin/AdminOverviewPage';
import { AdminTablesPage } from './pages/admin/AdminTablesPage';
import { AdminMenuPage } from './pages/admin/AdminMenuPage';
import { AdminInventoryPage } from './pages/admin/AdminInventoryPage';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage';

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-[#070913] text-slate-100">
          <Navbar />
          <CartDrawer />
          <AuthModal />
          <ToastContainer />
          <main>
            <ErrorBoundary>
              <Routes>
                <Route path="/" element={<LandingPage />} />
                <Route path="/menu" element={<MenuPage />} />
                <Route path="/reserve" element={<ReservePage />} />
                <Route path="/my-reservations" element={<MyReservationsPage />} />
                <Route path="/staff" element={<HostessPortalPage />} />
                <Route path="/kitchen" element={<KitchenDisplayPage />} />
                <Route path="/admin" element={<AdminLayout />}>
                  <Route index element={<AdminOverviewPage />} />
                  <Route path="tables" element={<AdminTablesPage />} />
                  <Route path="menu" element={<AdminMenuPage />} />
                  <Route path="inventory" element={<AdminInventoryPage />} />
                  <Route path="settings" element={<AdminSettingsPage />} />
                </Route>
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </ErrorBoundary>
          </main>
          <DemoClockDock />
        </div>
      </BrowserRouter>
    </AppProvider>
  );
}
