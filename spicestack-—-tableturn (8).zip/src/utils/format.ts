export function formatCurrency(amount: number, currency = '₹'): string {
  return `${currency}${Number(amount || 0).toLocaleString('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })}`;
}

export function formatTime12h(hhmm: string): string {
  if (!hhmm || !hhmm.includes(':')) return hhmm || '';
  const [hStr, mStr] = hhmm.split(':');
  let h = Number(hStr);
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h}:${mStr} ${ampm}`;
}

export function formatIsoTime12h(iso: string): string {
  if (!iso || iso.length < 16) return iso;
  return formatTime12h(iso.slice(11, 16));
}

export function generateTimeSlots(openingHours = '11:00 - 23:30', interval = 30): string[] {
  const parts = openingHours.split('-').map((s) => s.trim());
  const startStr = parts[0] || '11:00';
  const endStr = parts[1] || '23:00';
  const [sh, sm] = startStr.split(':').map(Number);
  const [eh, em] = endStr.split(':').map(Number);
  const startMin = (sh || 11) * 60 + (sm || 0);
  const endMin = (eh || 23) * 60 + (em || 0) - 60;

  const slots: string[] = [];
  for (let m = startMin; m <= endMin; m += Math.max(15, interval)) {
    const h = Math.floor(m / 60);
    const min = m % 60;
    slots.push(`${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}`);
  }
  return slots;
}

export function timeToMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minutesToHHMM(totalMinutes: number): string {
  const wrapped = ((totalMinutes % 1440) + 1440) % 1440;
  const h = Math.floor(wrapped / 60);
  const m = wrapped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}
