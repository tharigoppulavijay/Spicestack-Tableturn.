export interface BillLineItem {
  id?: number;
  price: number;
  quantity: number;
}

export interface OrderBillSummary {
  subtotal: number;
  discountAmount: number;
  discountedSubtotal: number;
  gstAmount: number;
  serviceChargeAmount: number;
  totalAmount: number;
}

function safeFinite(value: unknown, fallback = 0): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

export function roundMoney(value: number): number {
  const safe = safeFinite(value, 0);
  return Math.round((safe + Number.EPSILON) * 100) / 100;
}

export function calculateOrderBill(
  items: BillLineItem[],
  gstPercentage = 5,
  serviceChargePercentage = 10,
  discountPercentage = 0,
  discountFlatAmount = 0
): OrderBillSummary {
  const subtotal = roundMoney(
    items.reduce((sum, item) => {
      const rawQty = safeFinite(item.quantity, 0);
      const rawPrice = safeFinite(item.price, 0);
      const qty = Math.max(0, Math.floor(rawQty));
      const price = Math.max(0, rawPrice);
      return sum + price * qty;
    }, 0)
  );

  const safeDiscountPct = Math.min(100, Math.max(0, safeFinite(discountPercentage, 0)));
  const safeDiscountFlat = Math.max(0, safeFinite(discountFlatAmount, 0));
  const pctDiscount = roundMoney((subtotal * safeDiscountPct) / 100);
  const discountAmount = roundMoney(Math.min(subtotal, pctDiscount + safeDiscountFlat));
  const discountedSubtotal = roundMoney(Math.max(0, subtotal - discountAmount));

  const safeGst = Math.max(0, safeFinite(gstPercentage, 0));
  const safeSvc = Math.max(0, safeFinite(serviceChargePercentage, 0));
  const gstAmount = roundMoney((discountedSubtotal * safeGst) / 100);
  const serviceChargeAmount = roundMoney((discountedSubtotal * safeSvc) / 100);
  const totalAmount = roundMoney(discountedSubtotal + gstAmount + serviceChargeAmount);

  return {
    subtotal,
    discountAmount,
    discountedSubtotal,
    gstAmount,
    serviceChargeAmount,
    totalAmount,
  };
}

export interface EqualSplitResult {
  diners: number;
  shares: number[];
  baseShare: number;
  remainderCents: number;
  totalVerified: number;
}

export function calculateEqualSplit(totalAmount: number, diners: number): EqualSplitResult {
  const safeDiners = Math.max(1, Math.floor(safeFinite(diners, 1)));
  const safeTotal = Math.max(0, safeFinite(totalAmount, 0));
  const totalCents = Math.round(roundMoney(safeTotal) * 100);
  const baseCents = Math.floor(totalCents / safeDiners);
  const remainderCents = totalCents - baseCents * safeDiners;

  const shares = Array.from({ length: safeDiners }, (_, idx) => {
    const cents = baseCents + (idx < remainderCents ? 1 : 0);
    return cents / 100;
  });

  const totalVerified = roundMoney(shares.reduce((s, v) => s + v, 0));
  return {
    diners: safeDiners,
    shares,
    baseShare: baseCents / 100,
    remainderCents,
    totalVerified,
  };
}

export interface ItemizedSplitResult {
  subtotal: number;
  gstAmount: number;
  serviceChargeAmount: number;
  selectedTotal: number;
  remainingTotal: number;
}

export function calculateItemizedSplit(
  allItems: Array<{ id: number; price: number; quantity: number }>,
  selectedIds: number[],
  gstPercentage = 5,
  serviceChargePercentage = 10,
  fullOrderTotal?: number
): ItemizedSplitResult {
  const selectedSet = new Set(selectedIds);
  const selectedItems = allItems.filter((item) => selectedSet.has(item.id));
  const selectedBill = calculateOrderBill(selectedItems, gstPercentage, serviceChargePercentage);
  const referenceTotal =
    typeof fullOrderTotal === 'number' && Number.isFinite(fullOrderTotal)
      ? roundMoney(Math.max(0, fullOrderTotal))
      : calculateOrderBill(allItems, gstPercentage, serviceChargePercentage).totalAmount;

  return {
    subtotal: selectedBill.subtotal,
    gstAmount: selectedBill.gstAmount,
    serviceChargeAmount: selectedBill.serviceChargeAmount,
    selectedTotal: selectedBill.totalAmount,
    remainingTotal: Math.max(0, roundMoney(referenceTotal - selectedBill.totalAmount)),
  };
}
