import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, ChevronUp, ChevronDown, UserCheck, Radio } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { UserRole } from '../types';

const ROLE_OPTIONS: Array<{ role: UserRole; label: string; route: string }> = [
  { role: 'customer', label: 'Customer', route: '/reserve' },
  { role: 'hostess', label: 'Hostess', route: '/staff' },
  { role: 'kitchen', label: 'Kitchen', route: '/kitchen' },
  { role: 'manager', label: 'Manager', route: '/admin' },
];

export const DemoClockDock: React.FC = () => {
  const {
    user,
    demoEnabled,
    switchRole,
    setIsAuthModalOpen,
    clock,
    advanceClock,
    setClockTime,
    setClockLive,
    socketConnected,
  } = useApp();
  const [expanded, setExpanded] = useState(false);
  const navigate = useNavigate();

  const canAdjustClock = demoEnabled || (user && ['hostess', 'kitchen', 'manager'].includes(user.role));

  const handleRoleSwitch = async (role: UserRole, route: string) => {
    await switchRole(role);
    navigate(route);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 no-print">
      {expanded ? (
        <div className="w-[330px] sm:w-[370px] rounded-2xl glass-elevated p-4 shadow-2xl border border-violet-500/25">
          <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-amber-400" />
              <span className="text-xs font-semibold text-white">
                {demoEnabled ? 'Demo Controls & Clock' : 'Service Status & Clock'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-[11px] text-slate-300 tabular-nums">
                <Radio className={`h-3 w-3 ${socketConnected ? 'text-emerald-400' : 'text-amber-400'}`} />
                {socketConnected ? 'Synced' : 'Polling'}
              </span>
              <button
                type="button"
                onClick={() => setExpanded(false)}
                aria-label="Collapse demo panel"
                className="rounded-md p-1 text-slate-400 hover:bg-white/10 hover:text-white cursor-pointer"
              >
                <ChevronDown className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Account & Demo Role Switcher */}
          <div className={canAdjustClock ? 'mb-4' : ''}>
            <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
              <span className="truncate">Active: {user?.name || 'Signed Out'}</span>
              <button
                type="button"
                onClick={() => setIsAuthModalOpen(true)}
                className="inline-flex items-center gap-1 text-violet-300 hover:text-violet-200 font-semibold cursor-pointer shrink-0"
              >
                <UserCheck className="h-3.5 w-3.5" />
                {user ? 'Account / Sign Out' : 'Sign In / Register'}
              </button>
            </div>
            {demoEnabled && (
              <div className="grid grid-cols-4 gap-1.5">
                {ROLE_OPTIONS.map((opt) => (
                  <button
                    key={opt.role}
                    type="button"
                    onClick={() => handleRoleSwitch(opt.role, opt.route)}
                    className={`rounded-lg px-2 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      user?.role === opt.role
                        ? 'bg-violet-600 text-white'
                        : 'bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Simulated Clock Controls */}
          {canAdjustClock && (
            <div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                <span>Kitchen Sync Clock ({clock?.mode === 'live' ? 'Live' : 'Simulated'})</span>
                <span className="font-mono font-semibold text-amber-300 tabular-nums">
                  {clock?.display_time || '7:25 PM'}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                <button
                  type="button"
                  onClick={() => setClockTime('19:25')}
                  className="rounded-lg bg-white/5 px-2 py-1.5 text-xs font-mono text-slate-200 hover:bg-white/10 cursor-pointer tabular-nums"
                >
                  7:25 PM
                </button>
                <button
                  type="button"
                  onClick={() => setClockTime('19:40')}
                  className="rounded-lg bg-amber-500/20 border border-amber-500/30 px-2 py-1.5 text-xs font-mono font-semibold text-amber-200 hover:bg-amber-500/30 cursor-pointer tabular-nums"
                >
                  7:40 PM
                </button>
                <button
                  type="button"
                  onClick={() => advanceClock(5)}
                  className="rounded-lg bg-white/5 px-2 py-1.5 text-xs font-mono text-slate-200 hover:bg-white/10 cursor-pointer tabular-nums"
                >
                  +5 min
                </button>
                <button
                  type="button"
                  onClick={() => advanceClock(15)}
                  className="rounded-lg bg-white/5 px-2 py-1.5 text-xs font-mono text-slate-200 hover:bg-white/10 cursor-pointer tabular-nums"
                >
                  +15 min
                </button>
              </div>
              <div className="mt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setClockTime('20:00')}
                  className="flex-1 rounded-lg bg-white/5 px-2 py-1.5 text-xs font-mono text-slate-300 hover:bg-white/10 cursor-pointer tabular-nums"
                >
                  Jump 8:00 PM
                </button>
                <button
                  type="button"
                  onClick={setClockLive}
                  className="flex-1 rounded-lg bg-white/5 px-2 py-1.5 text-xs text-slate-300 hover:bg-white/10 cursor-pointer"
                >
                  Use Live Time
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setExpanded(true)}
          className="inline-flex items-center gap-2.5 rounded-xl glass-elevated px-3.5 py-2.5 text-xs font-medium text-slate-100 shadow-lg border border-violet-500/30 hover:border-violet-400/50 transition-all cursor-pointer"
        >
          <Clock className="h-4 w-4 text-amber-400" />
          <span className="font-mono tabular-nums text-amber-200">
            {clock?.display_time || '7:25 PM'}
          </span>
          <span className="text-slate-500">·</span>
          <span className="capitalize text-violet-300">{user?.role || 'guest'}</span>
          <ChevronUp className="h-3.5 w-3.5 text-slate-400" />
        </button>
      )}
    </div>
  );
};
