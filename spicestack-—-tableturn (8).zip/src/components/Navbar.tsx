import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, ShoppingBag, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Navbar: React.FC = () => {
  const { settings, cartTotals, setIsCartOpen } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isKitchenFullscreen = location.pathname === '/kitchen';
  if (isKitchenFullscreen) return null;

  const navLinks = [
    { label: 'Menu', to: '/menu' },
    { label: 'Reserve', to: '/reserve' },
    { label: 'My Bookings', to: '/my-reservations' },
    { label: 'Hostess', to: '/staff' },
    { label: 'Kitchen', to: '/kitchen' },
    { label: 'Manager', to: '/admin' },
  ];

  const isActive = (path: string) =>
    path === '/admin'
      ? location.pathname.startsWith('/admin')
      : location.pathname === path;

  return (
    <header className="sticky top-0 z-40 glass-nav no-print">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single clean wordmark */}
        <Link
          to="/"
          className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          {settings?.restaurant_name?.split('—')[0]?.trim() || 'SpiceStack'}
        </Link>

        {/* Zone 2: Clean single-line text nav links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          {navLinks.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={`relative py-1 transition-colors whitespace-nowrap shrink-0 ${
                isActive(item.to)
                  ? 'text-white'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {item.label}
              {isActive(item.to) && (
                <span className="absolute inset-x-0 -bottom-0.5 h-0.5 bg-gradient-to-r from-violet-400 to-amber-400 rounded-full" />
              )}
            </Link>
          ))}
        </nav>

        {/* Zone 3: Single primary action */}
        <div className="flex items-center gap-3 shrink-0">
          {cartTotals.itemCount > 0 ? (
            <button
              type="button"
              onClick={() => setIsCartOpen(true)}
              className="inline-flex items-center gap-2 rounded-lg bg-violet-600 px-4 py-2 text-xs font-semibold text-white hover:bg-violet-500 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <ShoppingBag className="h-4 w-4" />
              <span className="tabular-nums">Pre-Order ({cartTotals.itemCount})</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => navigate('/reserve')}
              className="inline-flex items-center rounded-lg bg-gradient-to-r from-violet-600 to-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:from-violet-500 hover:to-indigo-500 transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              Reserve Table
            </button>
          )}

          <button
            type="button"
            onClick={() => setMobileOpen((o) => !o)}
            aria-label="Toggle navigation menu"
            className="md:hidden inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 text-slate-200 hover:bg-white/5"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-t border-white/10 bg-[#090d1c] px-4 py-4 space-y-1">
          {navLinks.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setMobileOpen(false)}
              className={`block rounded-lg px-3 py-2.5 text-sm font-medium ${
                isActive(item.to)
                  ? 'bg-violet-500/15 text-white'
                  : 'text-slate-300 hover:bg-white/5 hover:text-white'
              }`}
            >
              {item.label}
            </Link>
          ))}
        </div>
      )}
    </header>
  );
};
