import React, { useEffect, useMemo, useRef, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Calendar, Download, MessageSquare, Printer, Users, X } from 'lucide-react';
import type { Reservation, SMSLog } from '../types';
import { formatCurrency, formatTime12h } from '../utils/format';
import { calculateEqualSplit, calculateItemizedSplit } from '../utils/billing';

interface BookingPassModalProps {
  reservation: Reservation;
  smsLog?: SMSLog | null;
  currency?: string;
  gstPct?: number;
  svcPct?: number;
  onClose: () => void;
}

export const BookingPassModal: React.FC<BookingPassModalProps> = ({
  reservation,
  smsLog,
  currency = '₹',
  gstPct = 5,
  svcPct = 10,
  onClose,
}) => {
  const qrContainerRef = useRef<HTMLDivElement>(null);
  const [splitMode, setSplitMode] = useState<'none' | 'equal' | 'itemized'>('none');
  const [splitDiners, setSplitDiners] = useState<number>(Math.max(2, reservation.party_size || 2));
  const [selectedItemIds, setSelectedItemIds] = useState<number[]>([]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  const preOrders = useMemo(() => reservation.pre_orders || [], [reservation.pre_orders]);

  const handleDownloadPass = () => {
    const svgEl = qrContainerRef.current?.querySelector('svg');
    if (!svgEl) return;
    const serializer = new XMLSerializer();
    const svgStr = serializer.serializeToString(svgEl);
    const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SpiceStack-Pass-${reservation.booking_code}.svg`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggleItemSplit = (id: number) => {
    setSelectedItemIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const equalSplit = useMemo(
    () => calculateEqualSplit(reservation.total_amount, splitDiners),
    [reservation.total_amount, splitDiners]
  );

  const itemizedShare = useMemo(
    () =>
      calculateItemizedSplit(
        preOrders.map((po) => ({
          id: po.id,
          price: po.price_snapshot,
          quantity: po.quantity,
        })),
        selectedItemIds,
        gstPct,
        svcPct,
        reservation.total_amount
      ),
    [preOrders, selectedItemIds, gstPct, svcPct, reservation.total_amount]
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-pass-title"
    >
      <div className="relative w-full max-w-2xl rounded-2xl glass-elevated border border-white/15 p-6 sm:p-8 shadow-2xl my-8">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close booking pass"
          className="absolute right-5 top-5 rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white no-print cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center border-b border-white/10 pb-6">
          <div
            ref={qrContainerRef}
            className="rounded-xl bg-white p-3.5 shrink-0 shadow-inner"
          >
            <QRCodeSVG
              value={JSON.stringify({
                bookingCode: reservation.booking_code,
                table: reservation.table_number,
                date: reservation.date,
                time: reservation.arrival_time,
                party: reservation.party_size,
              })}
              size={128}
              level="M"
            />
          </div>

          <div className="space-y-1.5">
            <div className="text-xs font-mono text-amber-300 uppercase tracking-wider">
              Confirmed TableTurn Pass
            </div>
            <h2 id="booking-pass-title" className="font-display text-2xl font-bold text-white tabular-nums">
              {reservation.booking_code}
            </h2>
            <p className="text-sm text-slate-300">
              {reservation.customer_name} · {reservation.party_size} Guests ·{' '}
              <span className="text-white font-semibold">{reservation.table_number || 'Assigned at Desk'}</span>
            </p>
            <p className="text-sm text-slate-400 tabular-nums">
              {reservation.date} at {formatTime12h(reservation.arrival_time)}
            </p>
          </div>
        </div>

        {/* Pre-ordered dishes */}
        <div className="py-5 border-b border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Pre-Ordered Dishes & Billing</h3>
            <span className="text-xs text-slate-400 tabular-nums">
              {preOrders.length} {preOrders.length === 1 ? 'item' : 'items'}
            </span>
          </div>

          {preOrders.length === 0 ? (
            <p className="text-sm text-slate-400">
              Table-only reservation. You may order at the table or attach dishes anytime.
            </p>
          ) : (
            <div className="space-y-2">
              {preOrders.map((po) => (
                <div
                  key={po.id}
                  className="flex items-center justify-between text-sm py-1.5 border-b border-white/5 last:border-none"
                >
                  <div>
                    <span className="text-slate-200 font-medium">
                      {po.quantity}x {po.item_name_snapshot}
                    </span>
                    <span className="ml-2 text-xs text-slate-400 tabular-nums">
                      ({po.prep_time_snapshot}m prep)
                    </span>
                    {(po.customization_notes || po.allergy_notes) && (
                      <div className="text-xs text-amber-300/90 mt-0.5">
                        {[po.customization_notes, po.allergy_notes].filter(Boolean).join(' · ')}
                      </div>
                    )}
                  </div>
                  <span className="font-mono text-slate-200 tabular-nums">
                    {formatCurrency(po.price_snapshot * po.quantity, currency)}
                  </span>
                </div>
              ))}

              <div className="pt-2 space-y-1 text-xs text-slate-400">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="tabular-nums text-slate-300">
                    {formatCurrency(reservation.subtotal, currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>GST ({gstPct}%) + Service Charge ({svcPct}%)</span>
                  <span className="tabular-nums text-slate-300">
                    {formatCurrency(reservation.gst_amount + reservation.service_charge_amount, currency)}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-semibold text-white pt-1">
                  <span>Total Payable</span>
                  <span className="tabular-nums text-amber-300">
                    {formatCurrency(reservation.total_amount, currency)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Simulated SMS & Calendar */}
        {smsLog && (
          <div className="py-4 border-b border-white/10 space-y-2 no-print">
            <div className="flex items-center justify-between text-xs text-cyan-300">
              <span className="inline-flex items-center gap-1.5 font-medium">
                <MessageSquare className="h-3.5 w-3.5" />
                SMS Confirmation Simulator
              </span>
              <a
                href={smsLog.calendar_link}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-violet-300 hover:text-violet-200 underline underline-offset-2"
              >
                <Calendar className="h-3.5 w-3.5" />
                Add to Google Calendar
              </a>
            </div>
            <p className="rounded-lg bg-white/5 px-3 py-2 text-xs text-slate-300 font-mono leading-relaxed">
              {smsLog.message}
            </p>
          </div>
        )}

        {/* Stretch Feature D: Split Bill Calculator */}
        {reservation.total_amount > 0 && (
          <div className="py-4 border-b border-white/10 no-print">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                <Users className="h-3.5 w-3.5 text-violet-400" />
                Split Bill Calculator
              </span>
              <div className="flex gap-1 rounded-lg bg-white/5 p-1">
                {(['none', 'equal', 'itemized'] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setSplitMode(m)}
                    className={`rounded-md px-2.5 py-1 text-xs font-medium capitalize cursor-pointer ${
                      splitMode === m ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {m === 'none' ? 'Hide' : m}
                  </button>
                ))}
              </div>
            </div>

            {splitMode === 'equal' && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-lg bg-white/[0.04] p-3 text-sm">
                <div className="flex items-center gap-2">
                  <label htmlFor="split-diners-input" className="text-slate-300">Diners:</label>
                  <input
                    id="split-diners-input"
                    type="number"
                    min={2}
                    max={20}
                    value={splitDiners}
                    onChange={(e) => setSplitDiners(Math.max(2, Math.min(20, Number(e.target.value) || 2)))}
                    className="w-16 rounded-md border border-white/15 bg-[#070913] px-2 py-1 text-center font-mono text-white"
                  />
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400 block">
                    Per Person (incl. tax{equalSplit.remainderCents > 0 ? ` · ${equalSplit.remainderCents}¢ adjusted` : ''})
                  </span>
                  <span className="font-mono font-bold text-amber-300 tabular-nums">
                    {formatCurrency(equalSplit.shares[0] ?? 0, currency)}
                  </span>
                </div>
              </div>
            )}

            {splitMode === 'itemized' && (
              <div className="mt-3 space-y-2 rounded-lg bg-white/[0.04] p-3">
                <p className="text-xs text-slate-400">Select dishes for an individual share:</p>
                <div className="flex flex-wrap gap-2">
                  {preOrders.map((po) => (
                    <button
                      key={po.id}
                      type="button"
                      onClick={() => toggleItemSplit(po.id)}
                      className={`rounded-lg border px-2.5 py-1 text-xs cursor-pointer transition-colors ${
                        selectedItemIds.includes(po.id)
                          ? 'border-violet-400 bg-violet-600/30 text-white'
                          : 'border-white/10 bg-[#070913] text-slate-300'
                      }`}
                    >
                      {po.quantity}x {po.item_name_snapshot}
                    </button>
                  ))}
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-sm border-t border-white/10">
                  <span className="text-slate-300">Selected Share (with GST & Service)</span>
                  <div className="text-right">
                    <span className="font-mono font-bold text-amber-300 tabular-nums block">
                      {formatCurrency(itemizedShare.selectedTotal, currency)}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400 tabular-nums">
                      Remaining: {formatCurrency(itemizedShare.remainingTotal, currency)}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="mt-6 flex flex-wrap items-center justify-end gap-3 no-print">
          <button
            type="button"
            onClick={handleDownloadPass}
            className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-white hover:bg-white/10 cursor-pointer"
          >
            <Download className="h-4 w-4" />
            Download QR Pass
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-white hover:bg-white/10 cursor-pointer"
          >
            <Printer className="h-4 w-4" />
            Print Pass
          </button>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center rounded-lg bg-violet-600 px-5 py-2 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
