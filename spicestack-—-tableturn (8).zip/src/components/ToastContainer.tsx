import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ToastContainer: React.FC = () => {
  const { toasts, dismissToast } = useApp();
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-50 flex flex-col gap-2 w-80 max-w-[calc(100vw-2rem)] no-print">
      {toasts.map((t) => {
        const Icon =
          t.type === 'success'
            ? CheckCircle2
            : t.type === 'error' || t.type === 'warning'
              ? AlertCircle
              : Info;
        const borderClass =
          t.type === 'success'
            ? 'border-emerald-500/40'
            : t.type === 'error'
              ? 'border-rose-500/40'
              : t.type === 'warning'
                ? 'border-amber-500/40'
                : 'border-violet-500/40';
        const iconClass =
          t.type === 'success'
            ? 'text-emerald-400'
            : t.type === 'error'
              ? 'text-rose-400'
              : t.type === 'warning'
                ? 'text-amber-400'
                : 'text-violet-400';

        return (
          <div
            key={t.id}
            className={`flex items-start gap-2.5 rounded-xl glass-elevated border ${borderClass} px-3.5 py-3 text-xs text-slate-100 shadow-xl`}
          >
            <Icon className={`h-4 w-4 shrink-0 mt-0.5 ${iconClass}`} />
            <span className="flex-1 leading-relaxed">{t.title}</span>
            <button
              type="button"
              onClick={() => dismissToast(t.id)}
              aria-label="Dismiss notification"
              className="text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
