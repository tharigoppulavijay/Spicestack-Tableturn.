import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Minus, Plus, ShoppingBag, Trash2, X, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency } from '../utils/format';
import { DishImage } from './DishImage';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    updateCartQuantity,
    removeFromCart,
    updateCartNotes,
    clearCart,
    cartTotals,
    settings,
  } = useApp();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isCartOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsCartOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isCartOpen, setIsCartOpen]);

  if (!isCartOpen) return null;

  const currency = settings?.currency || '₹';

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end no-print"
      role="dialog"
      aria-modal="true"
      aria-labelledby="cart-drawer-title"
    >
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-sm"
        onClick={() => setIsCartOpen(false)}
      />
      <aside className="relative z-10 flex h-full w-full max-w-md flex-col bg-[#0b1022] border-l border-white/10 shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="h-5 w-5 text-violet-400" />
            <h2 id="cart-drawer-title" className="font-display text-lg font-semibold text-white">
              Pre-Order Cart
            </h2>
          </div>
          <button
            type="button"
            onClick={() => setIsCartOpen(false)}
            aria-label="Close pre-order cart"
            className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <ShoppingBag className="h-10 w-10 text-slate-600 mb-3" />
              <p className="text-base font-medium text-slate-200">Your pre-order cart is empty</p>
              <p className="mt-1 text-sm text-slate-400 max-w-xs">
                Add dishes from our digital menu so the kitchen fires them right before your arrival.
              </p>
              <button
                type="button"
                onClick={() => {
                  setIsCartOpen(false);
                  navigate('/menu');
                }}
                className="mt-5 rounded-lg bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-500 cursor-pointer"
              >
                Explore Digital Menu
              </button>
            </div>
          ) : (
            cart.map((entry) => (
              <div
                key={entry.menuItem.id}
                className="rounded-xl border border-white/10 bg-white/[0.03] p-4 space-y-3"
              >
                <div className="flex gap-3.5">
                  <DishImage
                    src={entry.menuItem.image}
                    alt={entry.menuItem.name}
                    className="h-16 w-20 rounded-lg object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-semibold text-white truncate">
                        {entry.menuItem.name}
                      </h3>
                      <button
                        type="button"
                        onClick={() => removeFromCart(entry.menuItem.id)}
                        aria-label={`Remove ${entry.menuItem.name}`}
                        className="text-slate-500 hover:text-rose-400 cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5 tabular-nums">
                      {formatCurrency(entry.menuItem.price, currency)} · {entry.menuItem.preparation_time} min prep
                    </p>
                    <div className="mt-2.5 flex items-center justify-between">
                      <div className="inline-flex items-center rounded-lg border border-white/10 bg-[#070913]">
                        <button
                          type="button"
                          onClick={() => updateCartQuantity(entry.menuItem.id, entry.quantity - 1)}
                          className="p-1.5 text-slate-300 hover:text-white cursor-pointer"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="px-2.5 text-xs font-mono font-semibold text-white tabular-nums">
                          {entry.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateCartQuantity(entry.menuItem.id, entry.quantity + 1)}
                          className="p-1.5 text-slate-300 hover:text-white cursor-pointer"
                          aria-label="Increase quantity"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <span className="text-sm font-semibold text-white tabular-nums">
                        {formatCurrency(entry.menuItem.price * entry.quantity, currency)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-2 pt-1">
                  <input
                    type="text"
                    aria-label={`Customization notes for ${entry.menuItem.name}`}
                    value={entry.customizationNotes}
                    onChange={(e) =>
                      updateCartNotes(entry.menuItem.id, e.target.value, entry.allergyNotes)
                    }
                    placeholder="Customization (e.g., Less spicy, sauce on side)"
                    className="w-full rounded-lg border border-white/10 bg-[#070913] px-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
                  />
                  <input
                    type="text"
                    aria-label={`Allergy notes for ${entry.menuItem.name}`}
                    value={entry.allergyNotes}
                    onChange={(e) =>
                      updateCartNotes(entry.menuItem.id, entry.customizationNotes, e.target.value)
                    }
                    placeholder="Allergies / dietary exclusions (e.g., Nut-free)"
                    className="w-full rounded-lg border border-white/10 bg-[#070913] px-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div className="border-t border-white/10 bg-[#080b18] px-6 py-5 space-y-4">
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-slate-400">
                <span>Item Subtotal</span>
                <span className="tabular-nums text-slate-200">
                  {formatCurrency(cartTotals.subtotal, currency)}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>GST ({settings?.gst_percentage ?? 5}%)</span>
                <span className="tabular-nums text-slate-200">
                  {formatCurrency(cartTotals.gst, currency)}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Service Charge ({settings?.service_charge_percentage ?? 10}%)</span>
                <span className="tabular-nums text-slate-200">
                  {formatCurrency(cartTotals.serviceCharge, currency)}
                </span>
              </div>
              <div className="flex justify-between border-t border-white/10 pt-2.5 text-base font-semibold text-white">
                <span>Estimated Total</span>
                <span className="tabular-nums text-amber-300">
                  {formatCurrency(cartTotals.total, currency)}
                </span>
              </div>
            </div>

            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={clearCart}
                className="rounded-lg border border-white/10 px-3.5 py-2.5 text-xs font-medium text-slate-300 hover:bg-white/5 cursor-pointer"
              >
                Clear
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsCartOpen(false);
                  navigate('/reserve');
                }}
                className="flex-1 inline-flex items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-violet-600 to-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:from-violet-500 hover:to-indigo-500 cursor-pointer"
              >
                <span>Reserve Table & Attach Order</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
};
