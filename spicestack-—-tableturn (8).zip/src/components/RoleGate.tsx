import React from 'react';
import { ShieldAlert, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { UserRole } from '../types';

interface RoleGateProps {
  allowedRoles: UserRole[];
  children: React.ReactNode;
  recommendedRole: UserRole;
  portalTitle: string;
}

export const RoleGate: React.FC<RoleGateProps> = ({
  allowedRoles,
  children,
  recommendedRole,
  portalTitle,
}) => {
  const { user, demoEnabled, switchRole, setIsAuthModalOpen } = useApp();

  if (!user || !allowedRoles.includes(user.role)) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20">
        <div className="glass-elevated rounded-2xl border border-amber-500/30 p-8 text-center space-y-5">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/15 text-amber-300">
            <ShieldAlert className="h-6 w-6" />
          </div>
          <div className="space-y-2">
            <h1 className="font-display text-2xl font-bold text-white">
              {portalTitle} — Role Authorization Required
            </h1>
            <p className="text-sm text-slate-300">
              Your current session role is <span className="font-semibold text-amber-300 capitalize">{user?.role || 'guest'}</span>.
              Backend API permissions restrict this workspace to{' '}
              <span className="font-semibold text-white capitalize">{allowedRoles.join(' or ')}</span> accounts.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsAuthModalOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              Sign In with Credentials
            </button>
            {demoEnabled && (
              <button
                type="button"
                onClick={() => switchRole(recommendedRole)}
                className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white hover:bg-violet-500 transition-colors cursor-pointer"
              >
                <span>Switch to Demo {recommendedRole.charAt(0).toUpperCase() + recommendedRole.slice(1)} Account</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
