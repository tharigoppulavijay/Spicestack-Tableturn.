import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { BarChart3, Grid2x2, UtensilsCrossed, PackageCheck, Settings } from 'lucide-react';
import { RoleGate } from '../components/RoleGate';

const NAV_ITEMS = [
  { label: 'Overview & Analytics', to: '/admin', icon: BarChart3 },
  { label: 'Table Management', to: '/admin/tables', icon: Grid2x2 },
  { label: 'Food Menu & Categories', to: '/admin/menu', icon: UtensilsCrossed },
  { label: 'Inventory & Stock', to: '/admin/inventory', icon: PackageCheck },
  { label: 'Restaurant Settings', to: '/admin/settings', icon: Settings },
];

export const AdminLayout: React.FC = () => {
  const location = useLocation();

  return (
    <RoleGate
      allowedRoles={['manager']}
      recommendedRole="manager"
      portalTitle="Manager Control Suite"
    >
      <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <aside className="lg:w-64 shrink-0">
            <div className="glass-panel rounded-2xl p-3 lg:sticky lg:top-24 space-y-1">
              <div className="px-3 py-2 text-xs font-mono text-amber-300 uppercase tracking-wider">
                Manager Workspace
              </div>
              <nav className="flex lg:flex-col gap-1 overflow-x-auto pb-1 lg:pb-0">
                {NAV_ITEMS.map((item) => {
                  const active = location.pathname === item.to;
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      className={`flex items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                        active
                          ? 'bg-violet-600 text-white'
                          : 'text-slate-300 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </nav>
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1 min-w-0">
            <Outlet />
          </div>
        </div>
      </div>
    </RoleGate>
  );
};
