import type {
  AnalyticsOverview,
  Category,
  ClockState,
  KitchenTicket,
  MenuItem,
  Reservation,
  RestaurantSettings,
  RestaurantTable,
  SMSLog,
  User,
  UserRole,
} from '../types';

const TOKEN_KEY = 'spicestack_auth_token';
const DEFAULT_TIMEOUT_MS = 12_000;
const UPLOAD_TIMEOUT_MS = 20_000;
const MAX_SAFE_GET_RETRIES = 2;
const RETRYABLE_STATUSES = new Set([502, 503, 504]);

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string | null): void {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

function createIdempotencyKey(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `idem-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function request<T>(
  path: string,
  options: RequestInit & { timeoutMs?: number } = {}
): Promise<T> {
  const { timeoutMs = DEFAULT_TIMEOUT_MS, ...fetchOptions } = options;
  const method = (fetchOptions.method || 'GET').toUpperCase();
  const isSafeGet = method === 'GET';
  const maxAttempts = isSafeGet ? MAX_SAFE_GET_RETRIES + 1 : 1;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const token = getStoredToken();
      const headers: Record<string, string> = {
        ...(fetchOptions.headers as Record<string, string>),
      };
      if (!(fetchOptions.body instanceof FormData) && !headers['Content-Type']) {
        headers['Content-Type'] = 'application/json';
      }
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const res = await fetch(`/api${path}`, {
        ...fetchOptions,
        headers,
        signal: controller.signal,
      });
      clearTimeout(timer);

      if (isSafeGet && RETRYABLE_STATUSES.has(res.status) && attempt < maxAttempts) {
        await sleep(200 * 2 ** (attempt - 1));
        continue;
      }

      const rawText = await res.text();
      let parsed: Record<string, unknown> | null = null;
      if (rawText) {
        try {
          parsed = JSON.parse(rawText) as Record<string, unknown>;
        } catch {
          parsed = null;
        }
      }

      if (!res.ok) {
        const msg =
          parsed && typeof parsed.error === 'string'
            ? parsed.error
            : `Request failed (${res.status})`;
        throw new Error(msg);
      }

      if (parsed === null || typeof parsed !== 'object') {
        if (isSafeGet && attempt < maxAttempts) {
          await sleep(200 * 2 ** (attempt - 1));
          continue;
        }
        throw new Error('Received an invalid response from the server.');
      }

      return parsed as T;
    } catch (err) {
      clearTimeout(timer);
      const isAbort = err instanceof DOMException && err.name === 'AbortError';
      const isNetworkError = err instanceof TypeError;

      if (isSafeGet && (isAbort || isNetworkError) && attempt < maxAttempts) {
        await sleep(200 * 2 ** (attempt - 1));
        continue;
      }

      if (isAbort) {
        throw new Error('Request timed out. Please check your connection and try again.', {
          cause: err,
        });
      }
      if (isNetworkError) {
        throw new Error('Network connection interrupted. Please try again.', { cause: err });
      }
      throw err;
    }
  }

  throw new Error('Request failed after retries.');
}

export const api = {
  // Health
  getHealth: () =>
    request<{
      status: string;
      readiness: string;
      database: string;
      demoAuthEnabled?: boolean;
      timestamp: string;
    }>('/health'),

  // Auth
  getDemoUsers: () => request<{ demoEnabled?: boolean; users: User[] }>('/auth/demo-users'),
  register: (payload: { name: string; email: string; password: string; phone?: string }) =>
    request<{ user: User; token: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  login: (payload: { email: string; password: string }) =>
    request<{ user: User; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  loginDemo: (role: UserRole) =>
    request<{ user: User; token: string }>('/auth/login-demo', {
      method: 'POST',
      body: JSON.stringify({ role }),
    }),
  getMe: () => request<{ user: User | null; demoEnabled?: boolean }>('/auth/me'),

  // Settings & Clock
  getSettings: () => request<{ settings: RestaurantSettings; clock: ClockState }>('/settings'),
  updateSettings: (payload: Partial<RestaurantSettings>) =>
    request<{ settings: RestaurantSettings }>('/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  updateClock: (payload: { mode?: 'simulated' | 'live'; time?: string; date?: string; advanceMinutes?: number }) =>
    request<{ clock: ClockState }>('/clock', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Upload
  uploadImage: (file: File) => {
    const fd = new FormData();
    fd.append('image', file);
    return request<{ url: string }>('/upload', {
      method: 'POST',
      body: fd,
      timeoutMs: UPLOAD_TIMEOUT_MS,
    });
  },

  // Tables
  getTables: (params?: { date?: string; time?: string; partySize?: number }) => {
    const qs = new URLSearchParams();
    if (params?.date) qs.set('date', params.date);
    if (params?.time) qs.set('time', params.time);
    if (params?.partySize) qs.set('partySize', String(params.partySize));
    const query = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ tables: RestaurantTable[] }>(`/tables${query}`);
  },
  createTable: (payload: Partial<RestaurantTable>) =>
    request<{ table: RestaurantTable }>('/admin/tables', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateTable: (id: number, payload: Partial<RestaurantTable>) =>
    request<{ table: RestaurantTable }>(`/admin/tables/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteTable: (id: number) =>
    request<{ success: boolean }>(`/admin/tables/${id}`, { method: 'DELETE' }),

  // Categories
  getCategories: () => request<{ categories: Category[] }>('/categories'),
  createCategory: (name: string) =>
    request<{ category: Category }>('/admin/categories', {
      method: 'POST',
      body: JSON.stringify({ name }),
    }),
  updateCategory: (id: number, payload: Partial<Category>) =>
    request<{ category: Category }>(`/admin/categories/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteCategory: (id: number) =>
    request<{ success: boolean }>(`/admin/categories/${id}`, { method: 'DELETE' }),

  // Menu Items
  getMenu: () => request<{ items: MenuItem[] }>('/menu'),
  createMenuItem: (payload: Partial<MenuItem>) =>
    request<{ item: MenuItem }>('/admin/menu', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateMenuItem: (id: number, payload: Partial<MenuItem>) =>
    request<{ item: MenuItem }>(`/admin/menu/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteMenuItem: (id: number) =>
    request<{ success: boolean }>(`/admin/menu/${id}`, { method: 'DELETE' }),

  // Reservations
  getReservations: (params?: {
    date?: string;
    code?: string;
    phone?: string;
    search?: string;
    includeArchived?: boolean;
  }) => {
    const qs = new URLSearchParams();
    if (params?.date) qs.set('date', params.date);
    if (params?.code) qs.set('code', params.code);
    if (params?.phone) qs.set('phone', params.phone);
    if (params?.search) qs.set('search', params.search);
    if (params?.includeArchived) qs.set('includeArchived', 'true');
    const query = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ reservations: Reservation[]; clock: ClockState }>(`/reservations${query}`);
  },
  createReservation: (payload: {
    customer_name: string;
    phone: string;
    email?: string;
    date: string;
    arrival_time: string;
    party_size: number;
    table_id?: number | null;
    auto_allocate?: boolean;
    special_requests?: string;
    items: Array<{ menu_item_id: number; quantity: number; customization_notes?: string; allergy_notes?: string }>;
  }) =>
    request<{ reservation: Reservation; smsLog: SMSLog }>('/reservations', {
      method: 'POST',
      headers: { 'Idempotency-Key': createIdempotencyKey() },
      body: JSON.stringify(payload),
    }),
  modifyReservation: (
    id: number,
    payload: { arrival_time?: string; party_size?: number; special_requests?: string }
  ) =>
    request<{ reservation: Reservation }>(`/reservations/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),
  cancelReservation: (id: number) =>
    request<{ success: boolean }>(`/reservations/${id}/cancel`, {
      method: 'POST',
      headers: { 'Idempotency-Key': createIdempotencyKey() },
    }),
  clearOrderHistory: () =>
    request<{ success: boolean }>('/reservations/clear-history', { method: 'POST' }),
  checkInReservation: (id: number) =>
    request<{ success: boolean }>(`/staff/reservations/${id}/check-in`, { method: 'POST' }),
  updateReservationStaff: (id: number, payload: { status?: string; arrival_time?: string; table_id?: number }) =>
    request<{ success: boolean }>(`/staff/reservations/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  // Kitchen
  getKitchenTickets: () => request<{ tickets: KitchenTicket[]; clock: ClockState }>('/kitchen/tickets'),
  updateKitchenTicket: (id: number, payload: { status?: string; priority?: string }) =>
    request<{ ticket: KitchenTicket }>(`/kitchen/tickets/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  // Analytics & SMS
  getAnalytics: (range: 'today' | '7d' | '30d') => request<AnalyticsOverview>(`/admin/analytics?range=${range}`),
  getSmsLogs: () => request<{ logs: SMSLog[] }>('/sms-logs'),
};
