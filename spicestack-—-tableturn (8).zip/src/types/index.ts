export type UserRole = 'customer' | 'hostess' | 'kitchen' | 'manager';

export interface User {
  id: number;
  name: string;
  email: string;
  role: UserRole;
  phone: string;
}

export type TableStatus =
  | 'Available'
  | 'Reserved'
  | 'Occupied'
  | 'Cleaning'
  | 'Maintenance'
  | 'Disabled';

export interface RestaurantTable {
  id: number;
  table_number: string;
  capacity: number;
  type: string;
  section: string;
  description: string;
  status: TableStatus;
  is_active: number;
  pos_x: number;
  pos_y: number;
  is_available_for_slot?: boolean;
  conflict_reason?: string | null;
  estimated_turn_time?: string | null;
  minutes_remaining?: number | null;
}

export interface Category {
  id: number;
  name: string;
  display_order: number;
  item_count?: number;
}

export type DietaryType = 'Veg' | 'Non-Veg' | 'Vegan';
export type SpicyLevel = 'Mild' | 'Medium' | 'Hot' | 'Extra Hot';

export interface MenuItem {
  id: number;
  name: string;
  description: string;
  image: string;
  price: number;
  category_id: number;
  category_name?: string;
  dietary_type: DietaryType;
  spicy_level: SpicyLevel;
  preparation_time: number;
  is_chef_special: number;
  is_popular: number;
  allergy_info: string;
  customization_options: string[];
  availability: number;
  stock_quantity: number;
  daily_limit: number;
  is_deleted: number;
}

export type ReservationStatus =
  | 'Confirmed'
  | 'Checked In'
  | 'Seated'
  | 'Completed'
  | 'Cancelled'
  | 'No Show';

export interface PreOrder {
  id: number;
  reservation_id: number;
  menu_item_id: number | null;
  item_name_snapshot: string;
  price_snapshot: number;
  prep_time_snapshot: number;
  quantity: number;
  customization_notes: string;
  allergy_notes: string;
}

export type TicketStatus = 'Pending' | 'Cooking' | 'Ready' | 'Served';
export type TicketPriority = 'Normal' | 'High' | 'Urgent';

export interface KitchenTicket {
  id: number;
  reservation_id: number;
  pre_order_id: number | null;
  item_name: string;
  quantity: number;
  table_number: string;
  booking_code: string;
  customer_name?: string;
  arrival_time?: string;
  reservation_date?: string;
  reservation_status?: ReservationStatus;
  target_prep_start: string;
  preparation_time: number;
  status: TicketStatus;
  priority: TicketPriority;
  allergies: string;
  notes: string;
  started_at: string | null;
  ready_at: string | null;
  // Computed runtime fields from Arrival-Synchronized Kitchen Engine
  minutes_until_arrival?: number;
  minutes_until_fire?: number;
  should_fire_now?: boolean;
  is_overdue?: boolean;
  fire_alert_message?: string | null;
  cooking_remaining_minutes?: number | null;
}

export interface Reservation {
  id: number;
  booking_code: string;
  user_id?: number | null;
  customer_name: string;
  phone: string;
  email: string;
  date: string;
  arrival_time: string;
  party_size: number;
  table_id: number | null;
  table_number?: string;
  table_section?: string;
  table_capacity?: number;
  status: ReservationStatus;
  checked_in_at: string | null;
  seated_at: string | null;
  completed_at: string | null;
  special_requests: string;
  subtotal: number;
  gst_amount: number;
  service_charge_amount: number;
  total_amount: number;
  is_archived_by_customer?: number;
  created_at: string;
  pre_orders?: PreOrder[];
  tickets?: KitchenTicket[];
  customer_order_stage?: string;
}

export interface RestaurantSettings {
  id: number;
  restaurant_name: string;
  logo_url: string;
  address: string;
  phone: string;
  email: string;
  opening_hours: string;
  dining_duration: number;
  gst_percentage: number;
  service_charge_percentage: number;
  currency: string;
  slot_interval_minutes: number;
  max_advance_days: number;
  clock_mode: 'simulated' | 'live';
  simulated_time: string;
}

export interface ClockState {
  mode: 'simulated' | 'live';
  current_iso: string;
  current_date: string;
  current_time: string;
  display_time: string;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  customizationNotes: string;
  allergyNotes: string;
}

export interface SMSLog {
  id: number;
  reservation_id: number;
  phone: string;
  message: string;
  calendar_link: string;
  created_at: string;
}

export interface AnalyticsOverview {
  range: 'today' | '7d' | '30d';
  kpis: {
    totalReservations: number;
    completedReservations: number;
    cancelledReservations: number;
    todayGuests: number;
    availableTables: number;
    occupiedTables: number;
    totalActiveTables: number;
    occupancyPercentage: number;
    avgDiningDuration: number | null;
    avgTurnaroundMinutes: number | null;
    totalPreOrders: number;
    totalRevenue: number;
    onTimePrepRate: number | null;
    avgPrepTimeMinutes: number | null;
  };
  reservationsByHour: Array<{ hour: string; bookings: number; guests: number }>;
  occupancyTrends: Array<{ label: string; occupancy: number; turnaround: number | null }>;
  popularDishes: Array<{ name: string; orders: number; revenue: number }>;
  prepPerformance: Array<{ category: string; targetPrep: number; actualPrep: number | null }>;
  dailyBookingTrends: Array<{ date: string; reservations: number; revenue: number }>;
  tableUtilization: Array<{ table: string; bookings: number; capacity: number }>;
}
