import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { io } from 'socket.io-client';
import { api, getStoredToken, setStoredToken } from '../services/api';
import { calculateOrderBill } from '../utils/billing';
import type {
  CartItem,
  ClockState,
  MenuItem,
  RestaurantSettings,
  User,
  UserRole,
} from '../types';

export interface ToastMessage {
  id: string;
  title: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

interface AppContextValue {
  user: User | null;
  demoUsers: User[];
  demoEnabled: boolean;
  switchRole: (role: UserRole) => Promise<void>;
  login: (email: string, password: string) => Promise<User>;
  register: (payload: { name: string; email: string; password: string; phone?: string }) => Promise<User>;
  logout: () => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  settings: RestaurantSettings | null;
  clock: ClockState | null;
  refreshSettings: () => Promise<void>;
  advanceClock: (minutes: number) => Promise<void>;
  setClockTime: (timeHHMM: string) => Promise<void>;
  setClockLive: () => Promise<void>;
  cart: CartItem[];
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  addToCart: (menuItem: MenuItem, quantity?: number, customizationNotes?: string, allergyNotes?: string) => void;
  removeFromCart: (menuItemId: number) => void;
  updateCartQuantity: (menuItemId: number, quantity: number) => void;
  updateCartNotes: (menuItemId: number, customizationNotes: string, allergyNotes: string) => void;
  clearCart: () => void;
  cartTotals: {
    itemCount: number;
    subtotal: number;
    gst: number;
    serviceCharge: number;
    total: number;
  };
  syncVersion: number;
  socketConnected: boolean;
  toasts: ToastMessage[];
  showToast: (title: string, type?: ToastMessage['type']) => void;
  dismissToast: (id: string) => void;
  recentBookingCodes: string[];
  addRecentBookingCode: (code: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const CART_STORAGE_KEY = 'spicestack_cart_v1';
const BOOKINGS_STORAGE_KEY = 'spicestack_recent_bookings';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [demoUsers, setDemoUsers] = useState<User[]>([]);
  const [demoEnabled, setDemoEnabled] = useState(true);
  const [settings, setSettings] = useState<RestaurantSettings | null>(null);
  const [clock, setClock] = useState<ClockState | null>(null);
  const [syncVersion, setSyncVersion] = useState(0);
  const [socketConnected, setSocketConnected] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const raw = localStorage.getItem(CART_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as CartItem[]) : [];
    } catch {
      return [];
    }
  });

  const [recentBookingCodes, setRecentBookingCodes] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(BOOKINGS_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as string[]) : ['SS-4102', 'SS-4101'];
    } catch {
      return ['SS-4102', 'SS-4101'];
    }
  });

  useEffect(() => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(recentBookingCodes));
  }, [recentBookingCodes]);

  const showToast = useCallback((title: string, type: ToastMessage['type'] = 'info') => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-3), { id, title, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const refreshSettings = useCallback(async () => {
    try {
      const data = await api.getSettings();
      setSettings(data.settings);
      setClock(data.clock);
    } catch (err) {
      console.error('Failed to fetch settings:', err);
    }
  }, []);

  const switchRole = useCallback(
    async (role: UserRole) => {
      if (!demoEnabled) {
        showToast('Demo quick-switch is disabled in production mode. Please sign in.', 'warning');
        setIsAuthModalOpen(true);
        return;
      }
      try {
        const res = await api.loginDemo(role);
        setStoredToken(res.token);
        setUser(res.user);
        setSyncVersion((v) => v + 1);
        showToast(`Switched active role to ${res.user.name} (${res.user.role})`, 'success');
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Role switch failed', 'error');
      }
    },
    [demoEnabled, showToast]
  );

  const login = useCallback(
    async (email: string, password: string) => {
      const res = await api.login({ email, password });
      setStoredToken(res.token);
      setUser(res.user);
      setSyncVersion((v) => v + 1);
      showToast(`Signed in as ${res.user.name}`, 'success');
      return res.user;
    },
    [showToast]
  );

  const register = useCallback(
    async (payload: { name: string; email: string; password: string; phone?: string }) => {
      const res = await api.register(payload);
      setStoredToken(res.token);
      setUser(res.user);
      setSyncVersion((v) => v + 1);
      showToast(`Welcome to SpiceStack, ${res.user.name}!`, 'success');
      return res.user;
    },
    [showToast]
  );

  const logout = useCallback(() => {
    setStoredToken(null);
    setUser(null);
    setSyncVersion((v) => v + 1);
    showToast('Signed out of your account', 'info');
  }, [showToast]);

  // Initial bootstrap: demo policy, current session (default to customer only when demo enabled), settings
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const [demoPayload] = await Promise.all([api.getDemoUsers(), refreshSettings()]);
        if (!mounted) return;
        const isDemoOn = demoPayload.demoEnabled !== false;
        setDemoEnabled(isDemoOn);
        setDemoUsers(demoPayload.users || []);

        const token = getStoredToken();
        if (token) {
          const me = await api.getMe();
          if (me.user && mounted) {
            setUser(me.user);
            return;
          }
          setStoredToken(null);
        }

        if (isDemoOn && mounted) {
          const defaultRes = await api.loginDemo('customer');
          if (!mounted) return;
          setStoredToken(defaultRes.token);
          setUser(defaultRes.user);
        }
      } catch (err) {
        console.error('Bootstrap error:', err);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [refreshSettings]);

  // Real-time Socket.IO connection + polling fallback
  useEffect(() => {
    const socket = io({ transports: ['websocket', 'polling'] });
    socket.on('connect', () => setSocketConnected(true));
    socket.on('disconnect', () => setSocketConnected(false));
    socket.on('state:sync', () => {
      setSyncVersion((v) => v + 1);
      refreshSettings();
    });
    socket.on('clock:updated', (nextClock: ClockState) => {
      setClock(nextClock);
      setSyncVersion((v) => v + 1);
    });
    socket.on('settings:updated', (nextSettings: RestaurantSettings) => {
      setSettings(nextSettings);
      setSyncVersion((v) => v + 1);
    });

    const pollInterval = setInterval(() => {
      setSyncVersion((v) => v + 1);
      refreshSettings();
    }, 10000);

    return () => {
      socket.disconnect();
      clearInterval(pollInterval);
    };
  }, [refreshSettings]);

  const advanceClock = useCallback(
    async (minutes: number) => {
      try {
        const res = await api.updateClock({ advanceMinutes: minutes });
        setClock(res.clock);
        setSyncVersion((v) => v + 1);
        showToast(`Simulated clock set to ${res.clock.display_time}`, 'info');
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Unable to adjust clock', 'error');
      }
    },
    [showToast]
  );

  const setClockTime = useCallback(
    async (timeHHMM: string) => {
      try {
        const res = await api.updateClock({ time: timeHHMM });
        setClock(res.clock);
        setSyncVersion((v) => v + 1);
        showToast(`Simulated clock jumped to ${res.clock.display_time}`, 'info');
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Unable to set clock', 'error');
      }
    },
    [showToast]
  );

  const setClockLive = useCallback(async () => {
    try {
      const res = await api.updateClock({ mode: 'live' });
      setClock(res.clock);
      setSyncVersion((v) => v + 1);
      showToast('Clock synced to live local time', 'info');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Unable to switch clock mode', 'error');
    }
  }, [showToast]);

  const addToCart = useCallback(
    (menuItem: MenuItem, quantity = 1, customizationNotes = '', allergyNotes = '') => {
      if (menuItem.availability !== 1 || menuItem.stock_quantity <= 0) {
        showToast(`${menuItem.name} is currently Sold Out`, 'warning');
        return;
      }
      setCart((prev) => {
        const existing = prev.find((c) => c.menuItem.id === menuItem.id);
        if (existing) {
          const nextQty = Math.min(menuItem.stock_quantity, existing.quantity + quantity);
          return prev.map((c) =>
            c.menuItem.id === menuItem.id
              ? {
                  ...c,
                  menuItem,
                  quantity: nextQty,
                  customizationNotes: customizationNotes || c.customizationNotes,
                  allergyNotes: allergyNotes || c.allergyNotes,
                }
              : c
          );
        }
        return [...prev, { menuItem, quantity, customizationNotes, allergyNotes }];
      });
      showToast(`Added ${menuItem.name} to pre-order`, 'success');
    },
    [showToast]
  );

  const removeFromCart = useCallback((menuItemId: number) => {
    setCart((prev) => prev.filter((c) => c.menuItem.id !== menuItemId));
  }, []);

  const updateCartQuantity = useCallback((menuItemId: number, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((c) => c.menuItem.id !== menuItemId));
      return;
    }
    setCart((prev) =>
      prev.map((c) =>
        c.menuItem.id === menuItemId
          ? { ...c, quantity: Math.min(c.menuItem.stock_quantity || 99, quantity) }
          : c
      )
    );
  }, []);

  const updateCartNotes = useCallback(
    (menuItemId: number, customizationNotes: string, allergyNotes: string) => {
      setCart((prev) =>
        prev.map((c) =>
          c.menuItem.id === menuItemId ? { ...c, customizationNotes, allergyNotes } : c
        )
      );
    },
    []
  );

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const addRecentBookingCode = useCallback((code: string) => {
    setRecentBookingCodes((prev) => [code, ...prev.filter((c) => c !== code)].slice(0, 12));
  }, []);

  const cartTotals = useMemo(() => {
    const gstPct = settings?.gst_percentage ?? 5;
    const svcPct = settings?.service_charge_percentage ?? 10;
    const bill = calculateOrderBill(
      cart.map((item) => ({ price: item.menuItem.price, quantity: item.quantity })),
      gstPct,
      svcPct
    );
    const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    return {
      itemCount,
      subtotal: bill.subtotal,
      gst: bill.gstAmount,
      serviceCharge: bill.serviceChargeAmount,
      total: bill.totalAmount,
    };
  }, [cart, settings]);

  return (
    <AppContext.Provider
      value={{
        user,
        demoUsers,
        demoEnabled,
        switchRole,
        login,
        register,
        logout,
        isAuthModalOpen,
        setIsAuthModalOpen,
        settings,
        clock,
        refreshSettings,
        advanceClock,
        setClockTime,
        setClockLive,
        cart,
        isCartOpen,
        setIsCartOpen,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        updateCartNotes,
        clearCart,
        cartTotals,
        syncVersion,
        socketConnected,
        toasts,
        showToast,
        dismissToast,
        recentBookingCodes,
        addRecentBookingCode,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
