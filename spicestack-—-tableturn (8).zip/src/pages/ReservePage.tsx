import React, { useEffect, useMemo, useState } from 'react';
import { Calendar, Clock, Users, Check, Plus, ShoppingBag, ArrowRight, Sparkles, UserCheck } from 'lucide-react';
import { api } from '../services/api';
import { useApp } from '../context/AppContext';
import type { MenuItem, Reservation, RestaurantTable, SMSLog } from '../types';
import { formatCurrency, formatTime12h, generateTimeSlots } from '../utils/format';
import { BookingPassModal } from '../components/BookingPassModal';

export const ReservePage: React.FC = () => {
  const {
    user,
    setIsAuthModalOpen,
    settings,
    clock,
    cart,
    cartTotals,
    addToCart,
    clearCart,
    setIsCartOpen,
    showToast,
    syncVersion,
    addRecentBookingCode,
  } = useApp();

  const today = clock?.current_date || new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [time, setTime] = useState('20:00');
  const [partySize, setPartySize] = useState(4);
  const [tables, setTables] = useState<RestaurantTable[]>([]);
  const [autoAllocate, setAutoAllocate] = useState(false);
  const [selectedTableId, setSelectedTableId] = useState<number | null>(null);
  const [quickDishes, setQuickDishes] = useState<MenuItem[]>([]);

  const [customerName, setCustomerName] = useState(user?.role === 'customer' ? user.name : 'Aarav Sharma');
  const [phone, setPhone] = useState(user?.phone || '+91 98450 11223');
  const [email, setEmail] = useState(user?.role === 'customer' ? user.email : 'customer@spicestack.io');
  const [specialRequests, setSpecialRequests] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [confirmedModal, setConfirmedModal] = useState<{
    reservation: Reservation;
    smsLog?: SMSLog | null;
  } | null>(null);

  const currency = settings?.currency || '₹';

  useEffect(() => {
    if (user && user.role === 'customer') {
      setCustomerName(user.name);
      if (user.phone) setPhone(user.phone);
      setEmail(user.email);
    }
  }, [user]);

  useEffect(() => {
    if (clock?.current_date && date < clock.current_date) {
      setDate(clock.current_date);
    }
  }, [clock?.current_date, date]);

  const timeSlots = useMemo(
    () => generateTimeSlots(settings?.opening_hours || '11:00 - 23:30', settings?.slot_interval_minutes || 30),
    [settings?.opening_hours, settings?.slot_interval_minutes]
  );

  useEffect(() => {
    api
      .getTables({ date, time, partySize })
      .then((res) => {
        const fetched = Array.isArray(res?.tables) ? res.tables : [];
        setTables(fetched);
        setSelectedTableId((prev) => {
          const valid = fetched.find((t) => t.id === prev && t.is_available_for_slot);
          if (valid) return valid.id;
          const table4 = fetched.find((t) => t.table_number === 'Table 4' && t.is_available_for_slot);
          if (table4) return table4.id;
          const firstOpen = fetched.find((t) => t.is_available_for_slot);
          return firstOpen ? firstOpen.id : null;
        });
      })
      .catch(console.error);
  }, [date, time, partySize, syncVersion]);

  useEffect(() => {
    api
      .getMenu()
      .then((res) => {
        const items = Array.isArray(res?.items) ? res.items : [];
        const available = items.filter((i) => i.availability === 1 && i.stock_quantity > 0);
        const sorted = [...available].sort((a, b) =>
          a.name === 'Chicken Biryani' ? -1 : b.name === 'Chicken Biryani' ? 1 : 0
        );
        setQuickDishes(sorted.slice(0, 4));
      })
      .catch(console.error);
  }, [syncVersion]);

  const hasAvailableTable = tables.some((t) => t.is_available_for_slot);

  const handleConfirmBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    if (!autoAllocate && !selectedTableId) {
      showToast('Please select an available table or enable Auto-Assign Best Table', 'warning');
      return;
    }
    setSubmitting(true);
    try {
      const payload = {
        customer_name: customerName,
        phone,
        email,
        date,
        arrival_time: time,
        party_size: partySize,
        table_id: autoAllocate ? null : selectedTableId,
        auto_allocate: autoAllocate,
        special_requests: specialRequests,
        items: cart.map((c) => ({
          menu_item_id: c.menuItem.id,
          quantity: c.quantity,
          customization_notes: c.customizationNotes,
          allergy_notes: c.allergyNotes,
        })),
      };
      const res = await api.createReservation(payload);
      addRecentBookingCode(res.reservation.booking_code);
      clearCart();
      setConfirmedModal({ reservation: res.reservation, smsLog: res.smsLog });
      showToast(
        `Reservation ${res.reservation.booking_code} confirmed (${res.reservation.table_number})!`,
        'success'
      );
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to create reservation', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-white/10 pb-6 mb-8">
        <div>
          <p className="text-xs font-mono text-violet-300 uppercase tracking-wider">
            {settings?.dining_duration || 90}-Minute Overlap-Protected Slots
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white mt-1">
            Reserve Your Table & Sync Pre-Order
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            Tables are loaded live from restaurant inventory. Any pre-ordered dishes automatically schedule kitchen fire tickets based on your arrival time.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsAuthModalOpen(true)}
          className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-white hover:bg-white/10 cursor-pointer self-start sm:self-auto shrink-0"
        >
          <UserCheck className="h-3.5 w-3.5 text-violet-300" />
          <span>{user ? `${user.name}` : 'Sign In / Create Account'}</span>
        </button>
      </div>

      <form onSubmit={handleConfirmBooking} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Slot & Table Selector */}
        <div className="lg:col-span-7 space-y-6">
          {/* Date / Time / Party Size */}
          <div className="glass-panel rounded-2xl p-6 space-y-5">
            <h2 className="font-display text-lg font-semibold text-white">
              1. Choose Date, Time & Party Size
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label htmlFor="reserve-date" className="flex items-center gap-1.5 text-xs font-medium text-slate-300 mb-1.5">
                  <Calendar className="h-3.5 w-3.5 text-violet-400" />
                  Date
                </label>
                <input
                  id="reserve-date"
                  type="date"
                  value={date}
                  min={today}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white font-mono focus:border-violet-500 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="reserve-time" className="flex items-center gap-1.5 text-xs font-medium text-slate-300 mb-1.5">
                  <Clock className="h-3.5 w-3.5 text-amber-400" />
                  Arrival Time
                </label>
                <select
                  id="reserve-time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white font-mono focus:border-violet-500 focus:outline-none"
                >
                  {timeSlots.map((slot) => (
                    <option key={slot} value={slot}>
                      {formatTime12h(slot)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="reserve-party-size" className="flex items-center gap-1.5 text-xs font-medium text-slate-300 mb-1.5">
                  <Users className="h-3.5 w-3.5 text-cyan-400" />
                  Party Size
                </label>
                <select
                  id="reserve-party-size"
                  value={partySize}
                  onChange={(e) => setPartySize(Number(e.target.value))}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white font-mono focus:border-violet-500 focus:outline-none"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12].map((n) => (
                    <option key={n} value={n}>
                      {n} {n === 1 ? 'Guest' : 'Guests'}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Dynamic Available Tables */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-lg font-semibold text-white">
                2. Select an Available Table
              </h2>
              <span className="text-xs text-slate-400 tabular-nums">
                {tables.filter((t) => t.is_available_for_slot).length} of {tables.length} tables fit your slot
              </span>
            </div>

            <button
              type="button"
              disabled={!hasAvailableTable}
              onClick={() => setAutoAllocate((prev) => !prev)}
              className={`w-full text-left rounded-xl p-4 border transition-all flex items-center justify-between gap-3 ${
                autoAllocate
                  ? 'border-cyan-400 bg-cyan-500/15 shadow-lg shadow-cyan-950/30 cursor-pointer'
                  : hasAvailableTable
                    ? 'border-white/10 bg-white/[0.03] hover:border-white/25 cursor-pointer'
                    : 'border-white/5 bg-white/[0.01] opacity-50 cursor-not-allowed'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500/15 text-cyan-300 shrink-0">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">
                    Auto-Assign Best Suitable Table
                  </div>
                  <div className="text-xs text-slate-400">
                    Automatically picks the optimal available table sized for {partySize}{' '}
                    {partySize === 1 ? 'guest' : 'guests'}
                  </div>
                </div>
              </div>
              <span className={`text-xs font-mono font-semibold shrink-0 ${autoAllocate ? 'text-cyan-300' : 'text-slate-400'}`}>
                {autoAllocate ? 'Active' : 'Use Auto'}
              </span>
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {tables.map((t) => {
                const available = Boolean(t.is_available_for_slot);
                const selected = !autoAllocate && selectedTableId === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    disabled={!available}
                    onClick={() => {
                      setAutoAllocate(false);
                      setSelectedTableId(t.id);
                    }}
                    className={`text-left rounded-xl p-4 border transition-all ${
                      selected
                        ? 'border-violet-400 bg-violet-600/20 shadow-lg shadow-violet-900/20 cursor-pointer'
                        : available
                          ? 'border-white/10 bg-white/[0.03] hover:border-white/25 cursor-pointer'
                          : 'border-white/5 bg-white/[0.01] opacity-50 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-display text-base font-bold text-white">
                        {t.table_number}
                      </span>
                      <span
                        className={`text-xs font-mono font-semibold tabular-nums ${
                          selected
                            ? 'text-violet-200'
                            : available
                              ? 'text-emerald-300'
                              : 'text-rose-300'
                        }`}
                      >
                        {selected ? 'Selected' : available ? 'Available' : 'Unavailable'}
                      </span>
                    </div>
                    <div className="mt-1 text-xs text-slate-400">
                      Up to {t.capacity} guests · {t.type} · {t.section}
                    </div>
                    {!available && t.conflict_reason && (
                      <div className="mt-2 text-[11px] text-amber-300/90">
                        {t.conflict_reason}
                      </div>
                    )}
                    {available && t.estimated_turn_time && (
                      <div className="mt-2 text-[11px] text-cyan-300">
                        Current party finishes ~{t.estimated_turn_time}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: Guest Details + Pre-Order Summary */}
        <div className="lg:col-span-5 space-y-6">
          {/* Quick Pre-Order Attach */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold text-white">
                3. Attached Pre-Order
              </h2>
              <button
                type="button"
                onClick={() => setIsCartOpen(true)}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-violet-300 hover:text-violet-200 cursor-pointer"
              >
                <ShoppingBag className="h-3.5 w-3.5" />
                <span>Edit Cart ({cartTotals.itemCount})</span>
              </button>
            </div>

            {cart.length === 0 ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-400">
                  No dishes attached yet. Quick-add popular dishes below so they are fired right before {formatTime12h(time)}:
                </p>
                <div className="space-y-2">
                  {quickDishes.map((dish) => (
                    <div
                      key={dish.id}
                      className="flex items-center justify-between rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="text-xs font-semibold text-white truncate">{dish.name}</div>
                        <div className="text-[11px] text-slate-400 tabular-nums">
                          {formatCurrency(dish.price, currency)} · {dish.preparation_time}m prep
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => addToCart(dish)}
                        className="inline-flex items-center gap-1 rounded-lg bg-violet-600/80 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer shrink-0"
                      >
                        <Plus className="h-3 w-3" />
                        Add
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {cart.map((c) => (
                  <div
                    key={c.menuItem.id}
                    className="flex items-center justify-between text-xs border-b border-white/10 pb-2"
                  >
                    <div>
                      <span className="font-semibold text-white">
                        {c.quantity}x {c.menuItem.name}
                      </span>
                      <span className="ml-1.5 text-slate-400 tabular-nums">
                        ({c.menuItem.preparation_time}m prep)
                      </span>
                    </div>
                    <span className="font-mono text-slate-200 tabular-nums">
                      {formatCurrency(c.menuItem.price * c.quantity, currency)}
                    </span>
                  </div>
                ))}

                <div className="space-y-1 text-xs pt-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Subtotal</span>
                    <span className="tabular-nums">{formatCurrency(cartTotals.subtotal, currency)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>GST ({settings?.gst_percentage ?? 5}%)</span>
                    <span className="tabular-nums">{formatCurrency(cartTotals.gst, currency)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Service Charge ({settings?.service_charge_percentage ?? 10}%)</span>
                    <span className="tabular-nums">{formatCurrency(cartTotals.serviceCharge, currency)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-white pt-1.5">
                    <span>Final Payable</span>
                    <span className="font-mono text-amber-300 tabular-nums">
                      {formatCurrency(cartTotals.total, currency)}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Guest Contact Form */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <h2 className="font-display text-lg font-semibold text-white">
              4. Guest Details & Confirmation
            </h2>
            <div className="space-y-3">
              <div>
                <label htmlFor="guest-full-name" className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
                <input
                  id="guest-full-name"
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="guest-phone" className="block text-xs font-medium text-slate-300 mb-1">Phone Number</label>
                  <input
                    id="guest-phone"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="guest-email" className="block text-xs font-medium text-slate-300 mb-1">Email</label>
                  <input
                    id="guest-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="guest-special-requests" className="block text-xs font-medium text-slate-300 mb-1">
                  Table Allergies / Occasion Notes
                </label>
                <input
                  id="guest-special-requests"
                  type="text"
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="e.g., Nut allergy at table, birthday dessert candle"
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting || (!autoAllocate && !selectedTableId)}
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-6 py-3.5 text-sm font-semibold text-white hover:from-violet-500 hover:to-indigo-500 disabled:opacity-50 transition-all cursor-pointer"
            >
              <Check className="h-4 w-4" />
              <span>
                {submitting ? 'Locking Table & Scheduling Kitchen...' : 'Confirm Reservation'}
              </span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </form>

      {confirmedModal && (
        <BookingPassModal
          reservation={confirmedModal.reservation}
          smsLog={confirmedModal.smsLog}
          currency={currency}
          gstPct={settings?.gst_percentage}
          svcPct={settings?.service_charge_percentage}
          onClose={() => setConfirmedModal(null)}
        />
      )}
    </div>
  );
};
