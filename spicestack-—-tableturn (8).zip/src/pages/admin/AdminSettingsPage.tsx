import React, { useEffect, useState } from 'react';
import { Save } from 'lucide-react';
import { api } from '../../services/api';
import { useApp } from '../../context/AppContext';
import type { RestaurantSettings } from '../../types';

export const AdminSettingsPage: React.FC = () => {
  const { settings, refreshSettings, showToast } = useApp();
  const [form, setForm] = useState<Partial<RestaurantSettings>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings) {
      setForm(settings);
    }
  }, [settings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.updateSettings({
        restaurant_name: form.restaurant_name,
        logo_url: form.logo_url,
        address: form.address,
        phone: form.phone,
        email: form.email,
        opening_hours: form.opening_hours,
        dining_duration: Number(form.dining_duration),
        gst_percentage: Number(form.gst_percentage),
        service_charge_percentage: Number(form.service_charge_percentage),
        currency: form.currency,
        slot_interval_minutes: Number(form.slot_interval_minutes),
        max_advance_days: Number(form.max_advance_days),
      });
      await refreshSettings();
      showToast('Restaurant settings saved & applied to all calculations', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to save settings', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-white/10 pb-6">
        <p className="text-xs font-mono text-cyan-300 uppercase tracking-wider">
          Global Configuration
        </p>
        <h1 className="font-display text-3xl font-bold text-white mt-1">
          Restaurant & Billing Settings
        </h1>
        <p className="mt-1 text-sm text-slate-400">
          Changes to GST, service charge, currency, and dining slot durations immediately apply across customer carts, reservations, and turn-time estimates.
        </p>
      </div>

      <form onSubmit={handleSave} className="glass-panel rounded-2xl p-6 sm:p-8 space-y-6 max-w-4xl">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label htmlFor="settings-name" className="block text-xs font-medium text-slate-300 mb-1.5">Restaurant Name</label>
            <input
              id="settings-name"
              type="text"
              required
              value={form.restaurant_name || ''}
              onChange={(e) => setForm({ ...form, restaurant_name: e.target.value })}
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
            />
          </div>
          <div>
            <label htmlFor="settings-logo" className="block text-xs font-medium text-slate-300 mb-1.5">Logo URL (optional)</label>
            <input
              id="settings-logo"
              type="text"
              value={form.logo_url || ''}
              onChange={(e) => setForm({ ...form, logo_url: e.target.value })}
              placeholder="https://..."
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
            />
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="settings-address" className="block text-xs font-medium text-slate-300 mb-1.5">Address</label>
            <input
              id="settings-address"
              type="text"
              value={form.address || ''}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
            />
          </div>
          <div>
            <label htmlFor="settings-phone" className="block text-xs font-medium text-slate-300 mb-1.5">Contact Phone</label>
            <input
              id="settings-phone"
              type="text"
              value={form.phone || ''}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
            />
          </div>
          <div>
            <label htmlFor="settings-email" className="block text-xs font-medium text-slate-300 mb-1.5">Contact Email</label>
            <input
              id="settings-email"
              type="email"
              value={form.email || ''}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="border-t border-white/10 pt-6 grid grid-cols-1 sm:grid-cols-3 gap-5">
          <div>
            <label htmlFor="settings-hours" className="block text-xs font-medium text-slate-300 mb-1.5">Opening Hours</label>
            <input
              id="settings-hours"
              type="text"
              value={form.opening_hours || ''}
              onChange={(e) => setForm({ ...form, opening_hours: e.target.value })}
              placeholder="11:00 - 23:30"
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm font-mono text-white"
            />
          </div>
          <div>
            <label htmlFor="settings-duration" className="block text-xs font-medium text-slate-300 mb-1.5">Dining Duration (min)</label>
            <input
              id="settings-duration"
              type="number"
              min={30}
              max={240}
              value={form.dining_duration ?? 90}
              onChange={(e) => setForm({ ...form, dining_duration: Number(e.target.value) })}
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm font-mono text-white"
            />
          </div>
          <div>
            <label htmlFor="settings-interval" className="block text-xs font-medium text-slate-300 mb-1.5">Slot Interval (min)</label>
            <select
              id="settings-interval"
              value={form.slot_interval_minutes ?? 30}
              onChange={(e) => setForm({ ...form, slot_interval_minutes: Number(e.target.value) })}
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm font-mono text-white"
            >
              <option value={15}>15 min</option>
              <option value={30}>30 min</option>
              <option value={45}>45 min</option>
              <option value={60}>60 min</option>
            </select>
          </div>

          <div>
            <label htmlFor="settings-gst" className="block text-xs font-medium text-slate-300 mb-1.5">GST Percentage (%)</label>
            <input
              id="settings-gst"
              type="number"
              step="0.5"
              min={0}
              max={30}
              value={form.gst_percentage ?? 5}
              onChange={(e) => setForm({ ...form, gst_percentage: Number(e.target.value) })}
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm font-mono text-white"
            />
          </div>
          <div>
            <label htmlFor="settings-svc" className="block text-xs font-medium text-slate-300 mb-1.5">Service Charge (%)</label>
            <input
              id="settings-svc"
              type="number"
              step="0.5"
              min={0}
              max={30}
              value={form.service_charge_percentage ?? 10}
              onChange={(e) =>
                setForm({ ...form, service_charge_percentage: Number(e.target.value) })
              }
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm font-mono text-white"
            />
          </div>
          <div>
            <label htmlFor="settings-currency" className="block text-xs font-medium text-slate-300 mb-1.5">Currency Symbol</label>
            <select
              id="settings-currency"
              value={form.currency || '₹'}
              onChange={(e) => setForm({ ...form, currency: e.target.value })}
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm font-mono text-white"
            >
              <option value="₹">₹ (INR)</option>
              <option value="$">$ (USD)</option>
              <option value="€">€ (EUR)</option>
              <option value="£">£ (GBP)</option>
            </select>
          </div>

          <div>
            <label htmlFor="settings-max-days" className="block text-xs font-medium text-slate-300 mb-1.5">
              Max Advance Booking (days)
            </label>
            <input
              id="settings-max-days"
              type="number"
              min={1}
              max={365}
              value={form.max_advance_days ?? 30}
              onChange={(e) => setForm({ ...form, max_advance_days: Number(e.target.value) })}
              className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm font-mono text-white"
            />
          </div>
        </div>

        <div className="pt-4 border-t border-white/10 flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-6 py-3 text-sm font-semibold text-white hover:bg-violet-500 disabled:opacity-50 cursor-pointer"
          >
            <Save className="h-4 w-4" />
            <span>{saving ? 'Saving...' : 'Save Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
