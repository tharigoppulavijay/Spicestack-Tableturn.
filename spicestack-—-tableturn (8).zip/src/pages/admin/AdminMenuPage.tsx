import React, { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Upload, FolderPlus, ArrowUp, ArrowDown, X } from 'lucide-react';
import { api } from '../../services/api';
import { useApp } from '../../context/AppContext';
import type { Category, DietaryType, MenuItem, SpicyLevel } from '../../types';
import { formatCurrency } from '../../utils/format';
import { DishImage } from '../../components/DishImage';

const GALLERY_PRESETS = [
  { label: 'Biryani', url: '/src/assets/images/dish_chicken_biryani_1795006342681.jpg' },
  { label: 'Curry & Naan', url: '/src/assets/images/dish_butter_chicken_1795006343077.jpg' },
  { label: 'Risotto', url: '/src/assets/images/dish_truffle_risotto_1795006343336.jpg' },
  { label: 'Tandoori', url: '/src/assets/images/dish_tandoori_platter_1795006343862.jpg' },
  { label: 'Lamb Rack', url: '/src/assets/images/dish_lamb_chops_1795006346047.jpg' },
  { label: 'Dessert', url: '/src/assets/images/dish_gulab_tiramisu_1795006345869.jpg' },
  { label: 'Beverage', url: '/src/assets/images/dish_craft_beverage_1795006345099.jpg' },
];

export const AdminMenuPage: React.FC = () => {
  const { settings, syncVersion, showToast } = useApp();
  const [items, setItems] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCatFilter, setSelectedCatFilter] = useState<number | 'all'>('all');
  const [dishModalOpen, setDishModalOpen] = useState(false);
  const [catModalOpen, setCatModalOpen] = useState(false);
  const [editingDish, setEditingDish] = useState<MenuItem | null>(null);
  const [confirmDeleteDish, setConfirmDeleteDish] = useState<MenuItem | null>(null);

  // Dish Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState(GALLERY_PRESETS[0].url);
  const [price, setPrice] = useState(480);
  const [categoryId, setCategoryId] = useState<number>(1);
  const [dietaryType, setDietaryType] = useState<DietaryType>('Veg');
  const [spicyLevel, setSpicyLevel] = useState<SpicyLevel>('Medium');
  const [prepTime, setPrepTime] = useState(15);
  const [isChefSpecial, setIsChefSpecial] = useState(false);
  const [isPopular, setIsPopular] = useState(false);
  const [allergyInfo, setAllergyInfo] = useState('');
  const [customizationsText, setCustomizationsText] = useState('');
  const [availability, setAvailability] = useState(true);
  const [stockQty, setStockQty] = useState(25);
  const [uploading, setUploading] = useState(false);
  const [savingDish, setSavingDish] = useState(false);

  // Category Form State
  const [newCatName, setNewCatName] = useState('');
  const [editingCatId, setEditingCatId] = useState<number | null>(null);
  const [editingCatName, setEditingCatName] = useState('');

  const currency = settings?.currency || '₹';

  const loadData = async () => {
    const [menuRes, catRes] = await Promise.all([api.getMenu(), api.getCategories()]);
    setItems(Array.isArray(menuRes?.items) ? menuRes.items : []);
    setCategories(Array.isArray(catRes?.categories) ? catRes.categories : []);
  };

  useEffect(() => {
    loadData().catch(console.error);
  }, [syncVersion]);

  useEffect(() => {
    if (!dishModalOpen && !catModalOpen && !confirmDeleteDish) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setDishModalOpen(false);
        setCatModalOpen(false);
        setConfirmDeleteDish(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [dishModalOpen, catModalOpen, confirmDeleteDish]);

  const openAddDish = () => {
    setEditingDish(null);
    setName('');
    setDescription('');
    setImage(GALLERY_PRESETS[1].url);
    setPrice(480);
    setCategoryId(categories[0]?.id || 1);
    setDietaryType('Veg');
    setSpicyLevel('Medium');
    setPrepTime(15);
    setIsChefSpecial(false);
    setIsPopular(false);
    setAllergyInfo('');
    setCustomizationsText('Extra Spice, Sauce on Side');
    setAvailability(true);
    setStockQty(25);
    setDishModalOpen(true);
  };

  const openEditDish = (dish: MenuItem) => {
    setEditingDish(dish);
    setName(dish.name);
    setDescription(dish.description);
    setImage(dish.image);
    setPrice(dish.price);
    setCategoryId(dish.category_id);
    setDietaryType(dish.dietary_type);
    setSpicyLevel(dish.spicy_level);
    setPrepTime(dish.preparation_time);
    setIsChefSpecial(dish.is_chef_special === 1);
    setIsPopular(dish.is_popular === 1);
    setAllergyInfo(dish.allergy_info);
    setCustomizationsText((dish.customization_options || []).join(', '));
    setAvailability(dish.availability === 1);
    setStockQty(dish.stock_quantity);
    setDishModalOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const res = await api.uploadImage(file);
      setImage(res.url);
      showToast('Food photograph uploaded', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Upload failed', 'error');
    } finally {
      setUploading(false);
    }
  };

  const handleSaveDish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (savingDish) return;
    setSavingDish(true);
    const payload = {
      name,
      description,
      image,
      price: Number(price),
      category_id: Number(categoryId),
      dietary_type: dietaryType,
      spicy_level: spicyLevel,
      preparation_time: Number(prepTime),
      is_chef_special: isChefSpecial ? 1 : 0,
      is_popular: isPopular ? 1 : 0,
      allergy_info: allergyInfo,
      customization_options: customizationsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
      availability: availability ? 1 : 0,
      stock_quantity: Number(stockQty),
    };

    try {
      if (editingDish) {
        await api.updateMenuItem(editingDish.id, payload);
        showToast(`${name} updated & synced to customer menu`, 'success');
      } else {
        await api.createMenuItem(payload);
        showToast(`${name} added to live digital menu`, 'success');
      }
      setDishModalOpen(false);
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to save dish', 'error');
    } finally {
      setSavingDish(false);
    }
  };

  const handleDeleteDish = async () => {
    if (!confirmDeleteDish) return;
    try {
      await api.deleteMenuItem(confirmDeleteDish.id);
      showToast(`${confirmDeleteDish.name} removed (historical orders preserved)`, 'info');
      setConfirmDeleteDish(null);
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Delete failed', 'error');
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    try {
      await api.createCategory(newCatName.trim());
      setNewCatName('');
      showToast('Category added', 'success');
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to create category', 'error');
    }
  };

  const handleRenameCategory = async (id: number) => {
    if (!editingCatName.trim()) return;
    try {
      await api.updateCategory(id, { name: editingCatName.trim() });
      setEditingCatId(null);
      showToast('Category renamed', 'success');
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Rename failed', 'error');
    }
  };

  const handleMoveCategory = async (idx: number, direction: -1 | 1) => {
    const swapIdx = idx + direction;
    if (swapIdx < 0 || swapIdx >= categories.length) return;
    const a = categories[idx];
    const b = categories[swapIdx];
    try {
      await Promise.all([
        api.updateCategory(a.id, { display_order: b.display_order }),
        api.updateCategory(b.id, { display_order: a.display_order }),
      ]);
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to reorder category', 'error');
    }
  };

  const handleDeleteCategory = async (cat: Category) => {
    try {
      await api.deleteCategory(cat.id);
      showToast(`Category "${cat.name}" deleted`, 'info');
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Cannot delete category', 'error');
    }
  };

  const visibleItems =
    selectedCatFilter === 'all'
      ? items
      : items.filter((i) => i.category_id === selectedCatFilter);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <p className="text-xs font-mono text-violet-300 uppercase tracking-wider">
            Live Catalog Synchronization
          </p>
          <h1 className="font-display text-3xl font-bold text-white mt-1">
            Food Menu Management ({items.length} Dishes)
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Updates reflect immediately on the customer menu while historical pre-order price snapshots stay intact.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => setCatModalOpen(true)}
            className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-xs font-semibold text-white hover:bg-white/10 cursor-pointer"
          >
            <FolderPlus className="h-4 w-4 text-amber-300" />
            Manage Categories
          </button>
          <button
            type="button"
            onClick={openAddDish}
            className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-5 py-2.5 text-xs font-semibold text-white hover:from-violet-500 hover:to-indigo-500 cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            Add Food Item
          </button>
        </div>
      </div>

      {/* Category Filter Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setSelectedCatFilter('all')}
          className={`rounded-lg px-3.5 py-2 text-xs font-semibold whitespace-nowrap cursor-pointer ${
            selectedCatFilter === 'all'
              ? 'bg-white text-slate-950'
              : 'border border-white/10 bg-white/5 text-slate-300'
          }`}
        >
          All ({items.length})
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setSelectedCatFilter(c.id)}
            className={`rounded-lg px-3.5 py-2 text-xs font-semibold whitespace-nowrap cursor-pointer ${
              selectedCatFilter === c.id
                ? 'bg-white text-slate-950'
                : 'border border-white/10 bg-white/5 text-slate-300'
            }`}
          >
            {c.name} ({c.item_count || 0})
          </button>
        ))}
      </div>

      {/* Dishes Table */}
      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/10 bg-white/[0.03] text-xs text-slate-400">
              <tr>
                <th className="px-5 py-3.5 font-medium">Dish</th>
                <th className="px-5 py-3.5 font-medium">Category & Diet</th>
                <th className="px-5 py-3.5 font-medium">Prep Time</th>
                <th className="px-5 py-3.5 font-medium">Price</th>
                <th className="px-5 py-3.5 font-medium">Availability</th>
                <th className="px-5 py-3.5 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {visibleItems.map((dish) => {
                const soldOut = dish.availability !== 1 || dish.stock_quantity <= 0;
                return (
                  <tr key={dish.id} className="hover:bg-white/[0.02]">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <DishImage
                          src={dish.image}
                          alt={dish.name}
                          className="h-11 w-14 rounded-lg object-cover shrink-0"
                        />
                        <div>
                          <div className="font-semibold text-white">{dish.name}</div>
                          <div className="text-xs text-slate-400 line-clamp-1 max-w-xs">
                            {dish.description}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-xs text-slate-300">
                      <div>{dish.category_name}</div>
                      <div className="text-slate-400">
                        {dish.dietary_type} · {dish.spicy_level}
                      </div>
                    </td>
                    <td className="px-5 py-3.5 font-mono text-xs text-slate-200 tabular-nums">
                      {dish.preparation_time} min
                    </td>
                    <td className="px-5 py-3.5 font-mono text-sm font-semibold text-amber-300 tabular-nums">
                      {formatCurrency(dish.price, currency)}
                    </td>
                    <td className="px-5 py-3.5 text-xs">
                      {soldOut ? (
                        <span className="font-semibold text-rose-300">Sold Out</span>
                      ) : (
                        <span className="font-semibold text-emerald-300 tabular-nums">
                          Available ({dish.stock_quantity})
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openEditDish(dish)}
                          aria-label={`Edit ${dish.name}`}
                          className="rounded-lg border border-white/10 bg-white/5 p-2 text-slate-300 hover:bg-white/10 cursor-pointer"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteDish(dish)}
                          aria-label={`Delete ${dish.name}`}
                          className="rounded-lg border border-rose-500/20 bg-rose-500/10 p-2 text-rose-300 hover:bg-rose-500/20 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Food Item Modal */}
      {dishModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="admin-dish-modal-title"
        >
          <form
            onSubmit={handleSaveDish}
            className="w-full max-w-2xl rounded-2xl glass-elevated border border-white/15 p-6 space-y-4 my-8"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h2 id="admin-dish-modal-title" className="font-display text-lg font-bold text-white">
                {editingDish ? `Edit ${editingDish.name}` : 'Add New Food Item'}
              </h2>
              <button
                type="button"
                aria-label="Close food item dialog"
                onClick={() => setDishModalOpen(false)}
                className="rounded-lg p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="dish-name-input" className="block text-xs font-medium text-slate-300 mb-1">Dish Name</label>
                <input
                  id="dish-name-input"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Truffle Malai Kofta"
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="dish-category-select" className="block text-xs font-medium text-slate-300 mb-1">Category</label>
                <select
                  id="dish-category-select"
                  value={categoryId}
                  onChange={(e) => setCategoryId(Number(e.target.value))}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:outline-none"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="dish-desc-input" className="block text-xs font-medium text-slate-300 mb-1">Description</label>
              <textarea
                id="dish-desc-input"
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:border-violet-500 focus:outline-none"
              />
            </div>

            {/* Food Photo Upload + Preset Picker */}
            <div className="space-y-2 rounded-xl border border-white/10 bg-white/[0.02] p-3.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-300">Food Photograph</span>
                <label className="inline-flex items-center gap-1.5 rounded-lg bg-violet-600/80 px-3 py-1.5 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer">
                  <Upload className="h-3.5 w-3.5" />
                  <span>{uploading ? 'Uploading...' : 'Upload Photo'}</span>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
              </div>
              <div className="flex items-center gap-2 overflow-x-auto pt-1">
                {GALLERY_PRESETS.map((p) => (
                  <button
                    key={p.url}
                    type="button"
                    onClick={() => setImage(p.url)}
                    className={`shrink-0 rounded-lg border p-1 transition-all cursor-pointer ${
                      image === p.url ? 'border-violet-400 bg-violet-600/20' : 'border-white/10'
                    }`}
                  >
                    <img src={p.url} alt={p.label} className="h-10 w-14 rounded object-cover" />
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label htmlFor="dish-price-input" className="block text-xs font-medium text-slate-300 mb-1">Price ({currency})</label>
                <input
                  id="dish-price-input"
                  type="number"
                  min={0}
                  required
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm font-mono text-white"
                />
              </div>
              <div>
                <label htmlFor="dish-prep-input" className="block text-xs font-medium text-slate-300 mb-1">Prep Time (min)</label>
                <input
                  id="dish-prep-input"
                  type="number"
                  min={1}
                  required
                  value={prepTime}
                  onChange={(e) => setPrepTime(Number(e.target.value))}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm font-mono text-white"
                />
              </div>
              <div>
                <label htmlFor="dish-diet-select" className="block text-xs font-medium text-slate-300 mb-1">Dietary</label>
                <select
                  id="dish-diet-select"
                  value={dietaryType}
                  onChange={(e) => setDietaryType(e.target.value as DietaryType)}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white"
                >
                  <option value="Veg">Veg</option>
                  <option value="Non-Veg">Non-Veg</option>
                  <option value="Vegan">Vegan</option>
                </select>
              </div>
              <div>
                <label htmlFor="dish-spice-select" className="block text-xs font-medium text-slate-300 mb-1">Spice Level</label>
                <select
                  id="dish-spice-select"
                  value={spicyLevel}
                  onChange={(e) => setSpicyLevel(e.target.value as SpicyLevel)}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white"
                >
                  <option value="Mild">Mild</option>
                  <option value="Medium">Medium</option>
                  <option value="Hot">Hot</option>
                  <option value="Extra Hot">Extra Hot</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label htmlFor="dish-allergy-input" className="block text-xs font-medium text-slate-300 mb-1">Allergy Info</label>
                <input
                  id="dish-allergy-input"
                  type="text"
                  value={allergyInfo}
                  onChange={(e) => setAllergyInfo(e.target.value)}
                  placeholder="Dairy, Nuts"
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white"
                />
              </div>
              <div>
                <label htmlFor="dish-custom-input" className="block text-xs font-medium text-slate-300 mb-1">Customization Options</label>
                <input
                  id="dish-custom-input"
                  type="text"
                  value={customizationsText}
                  onChange={(e) => setCustomizationsText(e.target.value)}
                  placeholder="Comma separated"
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white"
                />
              </div>
              <div>
                <label htmlFor="dish-stock-input" className="block text-xs font-medium text-slate-300 mb-1">Initial Stock</label>
                <input
                  id="dish-stock-input"
                  type="number"
                  min={0}
                  value={stockQty}
                  onChange={(e) => setStockQty(Number(e.target.value))}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm font-mono text-white"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-5 pt-1 text-xs text-slate-300">
              <label className="inline-flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isChefSpecial}
                  onChange={(e) => setIsChefSpecial(e.target.checked)}
                />
                Chef's Special
              </label>
              <label className="inline-flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isPopular}
                  onChange={(e) => setIsPopular(e.target.checked)}
                />
                Popular Dish
              </label>
              <label className="inline-flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={availability}
                  onChange={(e) => setAvailability(e.target.checked)}
                />
                Available for Ordering
              </label>
            </div>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setDishModalOpen(false)}
                className="rounded-xl border border-white/10 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-white/5 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingDish}
                className="rounded-xl bg-violet-600 px-5 py-2 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer disabled:opacity-50"
              >
                {savingDish ? 'Saving...' : editingDish ? 'Update Food Item' : 'Publish Food Item'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Confirm Delete Dish Modal */}
      {confirmDeleteDish && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-dish-title"
        >
          <div className="w-full max-w-md rounded-2xl glass-elevated border border-rose-500/30 p-6 space-y-4">
            <h3 id="delete-dish-title" className="font-display text-lg font-bold text-white">
              Remove "{confirmDeleteDish.name}"?
            </h3>
            <p className="text-sm text-slate-300">
              This removes the dish from the live customer menu while safely preserving all existing pre-orders and historical billing records.
            </p>
            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteDish(null)}
                className="rounded-xl border border-white/10 px-4 py-2 text-xs font-medium text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteDish}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-500 cursor-pointer"
              >
                Remove Dish
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manage Categories Modal */}
      {catModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="manage-categories-title"
        >
          <div className="w-full max-w-lg rounded-2xl glass-elevated border border-white/15 p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h2 id="manage-categories-title" className="font-display text-lg font-bold text-white">
                Manage Menu Categories
              </h2>
              <button
                type="button"
                aria-label="Close categories dialog"
                onClick={() => setCatModalOpen(false)}
                className="rounded-lg p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleAddCategory} className="flex gap-2">
              <input
                type="text"
                aria-label="New category name"
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                placeholder="New category name (e.g., Wood-Fired Breads)"
                className="flex-1 rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2 text-sm text-white focus:border-violet-500 focus:outline-none"
              />
              <button
                type="submit"
                className="rounded-xl bg-violet-600 px-4 py-2 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer"
              >
                Add
              </button>
            </form>

            <div className="space-y-2 max-h-72 overflow-y-auto">
              {categories.map((cat, idx) => (
                <div
                  key={cat.id}
                  className="flex items-center justify-between rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5"
                >
                  {editingCatId === cat.id ? (
                    <div className="flex items-center gap-2 flex-1 mr-2">
                      <input
                        type="text"
                        aria-label={`Rename ${cat.name}`}
                        value={editingCatName}
                        onChange={(e) => setEditingCatName(e.target.value)}
                        className="flex-1 rounded-lg border border-violet-500 bg-black px-2.5 py-1 text-xs text-white"
                      />
                      <button
                        type="button"
                        onClick={() => handleRenameCategory(cat.id)}
                        className="text-xs font-semibold text-emerald-300 cursor-pointer"
                      >
                        Save
                      </button>
                    </div>
                  ) : (
                    <div>
                      <span className="text-sm font-medium text-white">{cat.name}</span>
                      <span className="ml-2 text-xs text-slate-400">
                        ({cat.item_count || 0} dishes)
                      </span>
                    </div>
                  )}

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleMoveCategory(idx, -1)}
                      aria-label={`Move ${cat.name} up`}
                      className="p-1.5 text-slate-400 hover:text-white cursor-pointer"
                      title="Move Up"
                    >
                      <ArrowUp className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleMoveCategory(idx, 1)}
                      aria-label={`Move ${cat.name} down`}
                      className="p-1.5 text-slate-400 hover:text-white cursor-pointer"
                      title="Move Down"
                    >
                      <ArrowDown className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingCatId(cat.id);
                        setEditingCatName(cat.name);
                      }}
                      aria-label={`Rename ${cat.name}`}
                      className="p-1.5 text-slate-400 hover:text-white cursor-pointer"
                      title="Rename"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteCategory(cat)}
                      aria-label={`Delete ${cat.name}`}
                      className="p-1.5 text-rose-400 hover:text-rose-300 cursor-pointer"
                      title="Delete Unused Category"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
