import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, Minus, Plus, Search } from 'lucide-react';
import { api } from '../../services/api';
import { useApp } from '../../context/AppContext';
import type { MenuItem } from '../../types';

export const AdminInventoryPage: React.FC = () => {
  const { syncVersion, showToast } = useApp();
  const [items, setItems] = useState<MenuItem[]>([]);
  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'low' | 'soldout'>('all');
  const [limitDrafts, setLimitDrafts] = useState<Record<number, string>>({});

  const loadMenu = async () => {
    const res = await api.getMenu();
    setItems(Array.isArray(res?.items) ? res.items : []);
  };

  useEffect(() => {
    loadMenu().catch(console.error);
  }, [syncVersion]);

  const handleAdjustStock = async (item: MenuItem, delta: number) => {
    const nextStock = Math.max(0, item.stock_quantity + delta);
    const nextAvail = nextStock > 0 ? 1 : 0;
    try {
      await api.updateMenuItem(item.id, {
        stock_quantity: nextStock,
        availability: nextAvail,
      });
      loadMenu();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Stock update failed', 'error');
    }
  };

  const handleToggleSoldOut = async (item: MenuItem) => {
    const currentlySoldOut = item.availability !== 1 || item.stock_quantity <= 0;
    try {
      await api.updateMenuItem(item.id, {
        availability: currentlySoldOut ? 1 : 0,
        stock_quantity: currentlySoldOut ? Math.max(15, item.stock_quantity || 15) : item.stock_quantity,
      });
      showToast(
        currentlySoldOut
          ? `${item.name} restored to customer menu`
          : `${item.name} marked Sold Out (existing pre-orders preserved)`,
        currentlySoldOut ? 'success' : 'warning'
      );
      loadMenu();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Update failed', 'error');
    }
  };

  const commitDailyLimit = async (item: MenuItem) => {
    const raw = limitDrafts[item.id];
    if (raw === undefined) return;
    const parsed = Number(raw);
    setLimitDrafts((prev) => {
      const next = { ...prev };
      delete next[item.id];
      return next;
    });
    if (!Number.isFinite(parsed) || parsed < 1 || parsed === item.daily_limit) return;
    try {
      await api.updateMenuItem(item.id, { daily_limit: Math.round(parsed) });
      loadMenu();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Limit update failed', 'error');
    }
  };

  const lowStockCount = items.filter((i) => i.availability === 1 && i.stock_quantity > 0 && i.stock_quantity <= 8).length;
  const soldOutCount = items.filter((i) => i.availability !== 1 || i.stock_quantity <= 0).length;

  const filtered = items.filter((i) => {
    const isSoldOut = i.availability !== 1 || i.stock_quantity <= 0;
    const isLow = i.availability === 1 && i.stock_quantity > 0 && i.stock_quantity <= 8;
    if (filterMode === 'low' && !isLow) return false;
    if (filterMode === 'soldout' && !isSoldOut) return false;
    if (search.trim() && !i.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <p className="text-xs font-mono text-amber-300 uppercase tracking-wider">
            Kitchen Stock Synchronization
          </p>
          <h1 className="font-display text-3xl font-bold text-white mt-1">
            Inventory & Availability Control
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Mark dishes Sold Out to immediately disable new customer orders without altering already-confirmed reservations.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs tabular-nums">
          <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-3.5 py-2 text-amber-200">
            {lowStockCount} Low Stock
          </div>
          <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-3.5 py-2 text-rose-200">
            {soldOutCount} Sold Out
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            aria-label="Filter inventory dishes"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter dishes..."
            className="w-full rounded-xl border border-white/10 bg-[#0d1224] pl-10 pr-4 py-2 text-sm text-white focus:border-violet-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-1 rounded-xl bg-[#0d1224] p-1 border border-white/10 w-fit">
          {(
            [
              { id: 'all', label: `All (${items.length})` },
              { id: 'low', label: `Low Stock (${lowStockCount})` },
              { id: 'soldout', label: `Sold Out (${soldOutCount})` },
            ] as const
          ).map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilterMode(f.id)}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold cursor-pointer ${
                filterMode === f.id ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Inventory Table */}
      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/10 bg-white/[0.03] text-xs text-slate-400">
              <tr>
                <th className="px-5 py-3.5 font-medium">Dish</th>
                <th className="px-5 py-3.5 font-medium">Category</th>
                <th className="px-5 py-3.5 font-medium">Live Stock</th>
                <th className="px-5 py-3.5 font-medium">Daily Limit</th>
                <th className="px-5 py-3.5 font-medium">Status</th>
                <th className="px-5 py-3.5 font-medium text-right">Control</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {filtered.map((item) => {
                const soldOut = item.availability !== 1 || item.stock_quantity <= 0;
                const low = !soldOut && item.stock_quantity <= 8;
                return (
                  <tr key={item.id} className="hover:bg-white/[0.02]">
                    <td className="px-5 py-3.5 font-semibold text-white">
                      {item.name}
                    </td>
                    <td className="px-5 py-3.5 text-xs text-slate-400">
                      {item.category_name}
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="inline-flex items-center gap-2 rounded-lg border border-white/10 bg-[#070913] px-2 py-1">
                        <button
                          type="button"
                          onClick={() => handleAdjustStock(item, -1)}
                          className="p-1 text-slate-300 hover:text-white cursor-pointer"
                          aria-label="Decrease stock"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-8 text-center font-mono text-xs font-bold text-white tabular-nums">
                          {item.stock_quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleAdjustStock(item, 1)}
                          className="p-1 text-slate-300 hover:text-white cursor-pointer"
                          aria-label="Increase stock"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <input
                        type="number"
                        aria-label={`Daily limit for ${item.name}`}
                        min={1}
                        value={limitDrafts[item.id] ?? String(item.daily_limit)}
                        onChange={(e) =>
                          setLimitDrafts((prev) => ({ ...prev, [item.id]: e.target.value }))
                        }
                        onBlur={() => commitDailyLimit(item)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.currentTarget.blur();
                          }
                        }}
                        className="w-16 rounded-lg border border-white/10 bg-[#070913] px-2 py-1 text-center font-mono text-xs text-slate-200"
                      />
                    </td>
                    <td className="px-5 py-3.5 text-xs">
                      {soldOut ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-rose-300">
                          <AlertTriangle className="h-3.5 w-3.5" />
                          Sold Out
                        </span>
                      ) : low ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-amber-300">
                          <AlertTriangle className="h-3.5 w-3.5" />
                          Low Stock
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 font-semibold text-emerald-300">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          In Stock
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        type="button"
                        onClick={() => handleToggleSoldOut(item)}
                        className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                          soldOut
                            ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                            : 'border border-rose-500/35 bg-rose-500/15 text-rose-200 hover:bg-rose-500/25'
                        }`}
                      >
                        {soldOut ? 'Restore Availability' : 'Mark Sold Out'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
