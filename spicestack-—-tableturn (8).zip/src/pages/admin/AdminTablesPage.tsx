import React, { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Power, X } from 'lucide-react';
import { api } from '../../services/api';
import { useApp } from '../../context/AppContext';
import type { RestaurantTable, TableStatus } from '../../types';

const TABLE_TYPES = ['Window Booth', 'Main Dining', 'Chef Counter', 'Terrace Alcove', 'Private Alcove', 'Royal Booth'];
const TABLE_STATUSES: TableStatus[] = ['Available', 'Reserved', 'Occupied', 'Cleaning', 'Maintenance', 'Disabled'];

export const AdminTablesPage: React.FC = () => {
  const { syncVersion, showToast } = useApp();
  const [tables, setTables] = useState<RestaurantTable[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<RestaurantTable | null>(null);
  const [saving, setSaving] = useState(false);

  const [tableNumber, setTableNumber] = useState('');
  const [capacity, setCapacity] = useState(4);
  const [type, setType] = useState('Main Dining');
  const [section, setSection] = useState('Center Lounge');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<TableStatus>('Available');

  const loadTables = async () => {
    try {
      const res = await api.getTables();
      setTables(Array.isArray(res?.tables) ? res.tables : []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTables();
  }, [syncVersion]);

  useEffect(() => {
    if (!modalOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setModalOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [modalOpen]);

  const openAddModal = () => {
    setEditing(null);
    const nextNum = tables.length + 1;
    setTableNumber(`Table ${nextNum}`);
    setCapacity(4);
    setType('Main Dining');
    setSection('Center Lounge');
    setDescription('');
    setStatus('Available');
    setModalOpen(true);
  };

  const openEditModal = (t: RestaurantTable) => {
    setEditing(t);
    setTableNumber(t.table_number);
    setCapacity(t.capacity);
    setType(t.type);
    setSection(t.section);
    setDescription(t.description);
    setStatus(t.status);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    try {
      if (editing) {
        await api.updateTable(editing.id, {
          table_number: tableNumber,
          capacity: Number(capacity),
          type,
          section,
          description,
          status,
          is_active: status === 'Disabled' ? 0 : 1,
        });
        showToast(`${tableNumber} updated across all portals`, 'success');
      } else {
        await api.createTable({
          table_number: tableNumber,
          capacity: Number(capacity),
          type,
          section,
          description,
          status,
        });
        showToast(`${tableNumber} (${capacity} seats) added and live in reservation engine`, 'success');
      }
      setModalOpen(false);
      loadTables();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to save table', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleActive = async (t: RestaurantTable) => {
    const nextActive = t.is_active === 1 ? 0 : 1;
    try {
      await api.updateTable(t.id, {
        is_active: nextActive,
        status: nextActive === 0 ? 'Disabled' : 'Available',
      });
      showToast(
        `${t.table_number} ${nextActive === 1 ? 'enabled' : 'disabled'} for bookings`,
        'info'
      );
      loadTables();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Update failed', 'error');
    }
  };

  const handleDelete = async (t: RestaurantTable) => {
    try {
      await api.deleteTable(t.id);
      showToast(`${t.table_number} deleted`, 'success');
      loadTables();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Cannot delete table', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <p className="text-xs font-mono text-amber-300 uppercase tracking-wider">
            Dynamic Table Allocator
          </p>
          <h1 className="font-display text-3xl font-bold text-white mt-1">
            Table Management ({tables.length} Tables)
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Adding, editing, or disabling tables immediately updates guest booking slots, hostess floor layouts, and analytics.
          </p>
        </div>

        <button
          type="button"
          onClick={openAddModal}
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-5 py-3 text-xs font-semibold text-white hover:from-violet-500 hover:to-indigo-500 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          Add New Table
        </button>
      </div>

      {loading ? (
        <div className="glass-panel rounded-2xl h-64 animate-pulse" />
      ) : (
        <div className="glass-panel rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-white/10 bg-white/[0.03] text-xs text-slate-400">
                <tr>
                  <th className="px-5 py-3.5 font-medium">Table</th>
                  <th className="px-5 py-3.5 font-medium">Capacity</th>
                  <th className="px-5 py-3.5 font-medium">Type & Section</th>
                  <th className="px-5 py-3.5 font-medium">Status</th>
                  <th className="px-5 py-3.5 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {tables.map((t) => (
                  <tr key={t.id} className="hover:bg-white/[0.02]">
                    <td className="px-5 py-4">
                      <div className="font-display font-bold text-white">{t.table_number}</div>
                      {t.description && (
                        <div className="text-xs text-slate-400 mt-0.5">{t.description}</div>
                      )}
                    </td>
                    <td className="px-5 py-4 font-mono text-slate-200 tabular-nums">
                      {t.capacity} seats
                    </td>
                    <td className="px-5 py-4 text-xs text-slate-300">
                      <div>{t.type}</div>
                      <div className="text-slate-400">{t.section}</div>
                    </td>
                    <td className="px-5 py-4">
                      <span
                        className={`text-xs font-semibold ${
                          t.status === 'Available'
                            ? 'text-emerald-300'
                            : t.status === 'Reserved'
                              ? 'text-amber-300'
                              : t.status === 'Occupied'
                                ? 'text-violet-300'
                                : t.status === 'Disabled'
                                  ? 'text-slate-500'
                                  : 'text-cyan-300'
                        }`}
                      >
                        {t.status}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleToggleActive(t)}
                          title={t.is_active === 1 ? 'Disable Table' : 'Enable Table'}
                          aria-label={t.is_active === 1 ? `Disable ${t.table_number}` : `Enable ${t.table_number}`}
                          className="rounded-lg border border-white/10 bg-white/5 p-2 text-slate-300 hover:bg-white/10 cursor-pointer"
                        >
                          <Power className={`h-3.5 w-3.5 ${t.is_active === 1 ? 'text-emerald-400' : 'text-slate-500'}`} />
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditModal(t)}
                          aria-label={`Edit ${t.table_number}`}
                          className="rounded-lg border border-white/10 bg-white/5 p-2 text-slate-300 hover:bg-white/10 cursor-pointer"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(t)}
                          aria-label={`Delete ${t.table_number}`}
                          className="rounded-lg border border-rose-500/20 bg-rose-500/10 p-2 text-rose-300 hover:bg-rose-500/20 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="admin-table-modal-title"
        >
          <form
            onSubmit={handleSave}
            className="w-full max-w-lg rounded-2xl glass-elevated border border-white/15 p-6 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h2 id="admin-table-modal-title" className="font-display text-lg font-bold text-white">
                {editing ? `Edit ${editing.table_number}` : 'Add New Restaurant Table'}
              </h2>
              <button
                type="button"
                aria-label="Close table dialog"
                onClick={() => setModalOpen(false)}
                className="rounded-lg p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="admin-table-number" className="block text-xs font-medium text-slate-300 mb-1">Table Name / Number</label>
                <input
                  id="admin-table-number"
                  type="text"
                  required
                  value={tableNumber}
                  onChange={(e) => setTableNumber(e.target.value)}
                  placeholder="e.g., Table 9"
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:border-violet-500 focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="admin-table-capacity" className="block text-xs font-medium text-slate-300 mb-1">Seating Capacity</label>
                <input
                  id="admin-table-capacity"
                  type="number"
                  min={1}
                  max={24}
                  required
                  value={capacity}
                  onChange={(e) => setCapacity(Number(e.target.value))}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white font-mono focus:border-violet-500 focus:outline-none"
                />
                <div className="mt-1.5 flex gap-1.5">
                  {[2, 4, 6, 8].map((sz) => (
                    <button
                      key={sz}
                      type="button"
                      onClick={() => setCapacity(sz)}
                      className={`rounded px-2 py-0.5 text-[11px] font-mono cursor-pointer ${
                        capacity === sz ? 'bg-violet-600 text-white' : 'bg-white/5 text-slate-400'
                      }`}
                    >
                      {sz}p
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="admin-table-type" className="block text-xs font-medium text-slate-300 mb-1">Table Type</label>
                <select
                  id="admin-table-type"
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:outline-none"
                >
                  {TABLE_TYPES.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="admin-table-section" className="block text-xs font-medium text-slate-300 mb-1">Section / Location</label>
                <input
                  id="admin-table-section"
                  type="text"
                  value={section}
                  onChange={(e) => setSection(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="admin-table-status" className="block text-xs font-medium text-slate-300 mb-1">Initial Status</label>
                <select
                  id="admin-table-status"
                  value={status}
                  onChange={(e) => setStatus(e.target.value as TableStatus)}
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:outline-none"
                >
                  {TABLE_STATUSES.map((st) => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="admin-table-desc" className="block text-xs font-medium text-slate-300 mb-1">Optional Description</label>
                <input
                  id="admin-table-desc"
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Corner booth near patio"
                  className="w-full rounded-xl border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="rounded-xl border border-white/10 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-white/5 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="rounded-xl bg-violet-600 px-5 py-2 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer disabled:opacity-50"
              >
                {saving ? 'Saving...' : editing ? 'Save Changes' : 'Create Table'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
