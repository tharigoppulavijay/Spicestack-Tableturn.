import React, { useCallback, useEffect, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { api } from '../../services/api';
import { useApp } from '../../context/AppContext';
import type { AnalyticsOverview } from '../../types';
import { formatCurrency } from '../../utils/format';

export const AdminOverviewPage: React.FC = () => {
  const { settings, syncVersion } = useApp();
  const [range, setRange] = useState<'today' | '7d' | '30d'>('7d');
  const [data, setData] = useState<AnalyticsOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const currency = settings?.currency || '₹';

  const loadAnalytics = useCallback((activeRange: 'today' | '7d' | '30d' = range) => {
    setLoading(true);
    setError(null);
    api
      .getAnalytics(activeRange)
      .then((res) => setData(res))
      .catch((err) => {
        setError(err instanceof Error ? err.message : 'Unable to load analytics');
      })
      .finally(() => setLoading(false));
  }, [range]);

  useEffect(() => {
    loadAnalytics(range);
  }, [loadAnalytics, range, syncVersion]);

  const kpis = data?.kpis;
  const hasTurnaroundSeries = Boolean(data?.occupancyTrends.some((d) => d.turnaround !== null));

  return (
    <div className="space-y-8">
      {/* Header + Date Filter */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <p className="text-xs font-mono text-violet-300 uppercase tracking-wider">
            Real-Time Operations Intelligence
          </p>
          <h1 className="font-display text-3xl font-bold text-white mt-1">
            Manager Analytics Overview
          </h1>
        </div>

        <div className="flex items-center gap-1 rounded-xl bg-[#0d1224] p-1 border border-white/10 w-fit">
          {(
            [
              { id: 'today', label: 'Today' },
              { id: '7d', label: 'Last 7 Days' },
              { id: '30d', label: 'Last 30 Days' },
            ] as const
          ).map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setRange(opt.id)}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold cursor-pointer transition-colors ${
                range === opt.id ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Grid */}
      {error && !data ? (
        <div className="glass-panel rounded-2xl p-8 text-center space-y-3 border border-rose-500/25">
          <p className="text-sm font-medium text-rose-200">{error}</p>
          <button
            type="button"
            onClick={() => loadAnalytics(range)}
            className="rounded-xl bg-violet-600 px-4 py-2 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer"
          >
            Retry Analytics
          </button>
        </div>
      ) : loading && !data ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
            <div key={n} className="glass-panel rounded-2xl h-24 animate-pulse" />
          ))}
        </div>
      ) : kpis ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="glass-panel rounded-2xl p-5">
            <div className="text-xs text-slate-400">Total Reservations</div>
            <div className="mt-1.5 font-display text-2xl font-bold text-white tabular-nums">
              {kpis.totalReservations}
            </div>
            <div className="mt-1 text-[11px] text-violet-300 tabular-nums">
              {kpis.completedReservations} completed · {kpis.cancelledReservations} cancelled
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-5">
            <div className="text-xs text-slate-400">Pre-Order Revenue</div>
            <div className="mt-1.5 font-display text-2xl font-bold text-white tabular-nums">
              {formatCurrency(kpis.totalRevenue, currency)}
            </div>
            <div className="mt-1 text-[11px] text-slate-400 tabular-nums">
              {kpis.todayGuests} scheduled covers today
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-5">
            <div className="text-xs text-slate-400">Floor Occupancy</div>
            <div className="mt-1.5 font-display text-2xl font-bold text-amber-300 tabular-nums">
              {kpis.occupancyPercentage}%
            </div>
            <div className="mt-1 text-[11px] text-slate-400 tabular-nums">
              {kpis.occupiedTables} occupied · {kpis.availableTables} available of {kpis.totalActiveTables}
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-5">
            <div className="text-xs text-slate-400">Avg Turnaround</div>
            <div className="mt-1.5 font-display text-2xl font-bold text-cyan-300 tabular-nums">
              {kpis.avgTurnaroundMinutes !== null ? `${kpis.avgTurnaroundMinutes} min` : 'No logs yet'}
            </div>
            <div className="mt-1 text-[11px] text-slate-400 tabular-nums">
              Avg dining:{' '}
              {kpis.avgDiningDuration !== null ? `${kpis.avgDiningDuration} min` : 'Pending completion'}
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-5">
            <div className="text-xs text-slate-400">Total Pre-Orders</div>
            <div className="mt-1.5 font-display text-2xl font-bold text-white tabular-nums">
              {kpis.totalPreOrders} dishes
            </div>
            <div className="mt-1 text-[11px] text-emerald-300">Arrival-synced tickets</div>
          </div>

          <div className="glass-panel rounded-2xl p-5">
            <div className="text-xs text-slate-400">Kitchen On-Time Rate</div>
            <div className="mt-1.5 font-display text-2xl font-bold text-emerald-300 tabular-nums">
              {kpis.onTimePrepRate !== null ? `${kpis.onTimePrepRate}%` : 'Awaiting ready logs'}
            </div>
            <div className="mt-1 text-[11px] text-slate-400 tabular-nums">
              Avg dish prep:{' '}
              {kpis.avgPrepTimeMinutes !== null ? `${kpis.avgPrepTimeMinutes} min` : '—'}
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-5">
            <div className="text-xs text-slate-400">Available Tables</div>
            <div className="mt-1.5 font-display text-2xl font-bold text-white tabular-nums">
              {kpis.availableTables}
            </div>
            <div className="mt-1 text-[11px] text-slate-400">Ready for immediate walk-ins</div>
          </div>

          <div className="glass-panel rounded-2xl p-5">
            <div className="text-xs text-slate-400">Occupied Tables</div>
            <div className="mt-1.5 font-display text-2xl font-bold text-white tabular-nums">
              {kpis.occupiedTables}
            </div>
            <div className="mt-1 text-[11px] text-slate-400">Active dining parties</div>
          </div>
        </div>
      ) : null}

      {/* Charts Grid */}
      {data && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Reservations by Hour */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Reservations by Hour
              </h2>
              <p className="text-xs text-slate-400">Peak dining demand across service hours</p>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <BarChart data={data.reservationsByHour}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="hour" stroke="#94a3b8" fontSize={11} />
                  <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0b1022',
                      borderColor: 'rgba(255,255,255,0.12)',
                      borderRadius: '12px',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="bookings" name="Reservations" fill="#7c3aed" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Table Occupancy Trends */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Table Occupancy Trends
              </h2>
              <p className="text-xs text-slate-400">Hourly floor utilization (%)</p>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <AreaChart data={data.occupancyTrends}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="label" stroke="#94a3b8" fontSize={11} />
                  <YAxis stroke="#94a3b8" fontSize={11} unit="%" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0b1022',
                      borderColor: 'rgba(255,255,255,0.12)',
                      borderRadius: '12px',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="occupancy"
                    name="Occupancy %"
                    stroke="#06b6d4"
                    fill="rgba(6,182,212,0.22)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Popular Dishes */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Most Pre-Ordered Dishes
              </h2>
              <p className="text-xs text-slate-400">Units ordered across selected timeframe</p>
            </div>
            <div className="h-64">
              {data.popularDishes.length === 0 ? (
                <div className="h-full flex items-center justify-center text-xs text-slate-400">
                  No pre-orders recorded in this timeframe.
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                  <BarChart data={data.popularDishes} layout="vertical" margin={{ left: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis type="number" stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                    <YAxis
                      type="category"
                      dataKey="name"
                      stroke="#cbd5e1"
                      fontSize={11}
                      width={140}
                      tickFormatter={(v: string) => (v.length > 20 ? `${v.slice(0, 18)}…` : v)}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0b1022',
                        borderColor: 'rgba(255,255,255,0.12)',
                        borderRadius: '12px',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="orders" name="Portions" fill="#f59e0b" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Average Preparation Times */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Average Preparation Time by Category
              </h2>
              <p className="text-xs text-slate-400">Target vs actual kitchen completion (minutes)</p>
            </div>
            <div className="h-64">
              {data.prepPerformance.length === 0 ? (
                <div className="h-full flex items-center justify-center text-xs text-slate-400">
                  No kitchen ticket preparation data in this timeframe.
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                  <BarChart data={data.prepPerformance}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="category" stroke="#94a3b8" fontSize={11} />
                    <YAxis stroke="#94a3b8" fontSize={11} unit="m" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0b1022',
                        borderColor: 'rgba(255,255,255,0.12)',
                        borderRadius: '12px',
                        fontSize: '12px',
                      }}
                    />
                    <Bar dataKey="targetPrep" name="Target (min)" fill="#6366f1" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="actualPrep" name="Actual (min)" fill="#10b981" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Daily Booking Trends */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Daily Booking Trends
              </h2>
              <p className="text-xs text-slate-400">Reservation volume over time</p>
            </div>
            <div className="h-64">
              {data.dailyBookingTrends.length === 0 ? (
                <div className="h-full flex items-center justify-center text-xs text-slate-400">
                  No bookings recorded in this timeframe.
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                  <AreaChart data={data.dailyBookingTrends}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} />
                    <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0b1022',
                        borderColor: 'rgba(255,255,255,0.12)',
                        borderRadius: '12px',
                        fontSize: '12px',
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="reservations"
                      name="Bookings"
                      stroke="#a855f7"
                      fill="rgba(168,85,247,0.2)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Table Turnaround */}
          <div className="glass-panel rounded-2xl p-6 space-y-4">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Table Turnaround Velocity
              </h2>
              <p className="text-xs text-slate-400">
                Completed party turnaround from check-in to completion (minutes)
              </p>
            </div>
            <div className="h-64">
              {!hasTurnaroundSeries ? (
                <div className="h-full flex items-center justify-center text-xs text-slate-400 text-center px-4">
                  No completed party check-in → completion logs recorded in this range yet.
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                  <LineChart data={data.occupancyTrends}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="label" stroke="#94a3b8" fontSize={11} />
                    <YAxis stroke="#94a3b8" fontSize={11} unit="m" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0b1022',
                        borderColor: 'rgba(255,255,255,0.12)',
                        borderRadius: '12px',
                        fontSize: '12px',
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="turnaround"
                      name="Turnaround (min)"
                      stroke="#f59e0b"
                      strokeWidth={2.5}
                      dot={{ r: 3 }}
                      connectNulls
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Table Utilization */}
          <div className="glass-panel rounded-2xl p-6 space-y-4 lg:col-span-2">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Table Utilization Breakdown
              </h2>
              <p className="text-xs text-slate-400">
                Confirmed and completed bookings assigned per dining table
              </p>
            </div>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                <BarChart data={data.tableUtilization}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="table" stroke="#94a3b8" fontSize={11} />
                  <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0b1022',
                      borderColor: 'rgba(255,255,255,0.12)',
                      borderRadius: '12px',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="bookings" name="Bookings" fill="#ec4899" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
