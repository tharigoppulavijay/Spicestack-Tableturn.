import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  QrCode,
  Search,
  Clock,
  CheckCircle2,
  ChefHat,
  Utensils,
  Edit3,
  XCircle,
  Trash2,
  UserCheck,
  X,
} from 'lucide-react';
import { api } from '../services/api';
import { useApp } from '../context/AppContext';
import type { Reservation } from '../types';
import { formatCurrency, formatIsoTime12h, formatTime12h, generateTimeSlots } from '../utils/format';
import { BookingPassModal } from '../components/BookingPassModal';

const STAGES = [
  'Order Confirmed',
  'Waiting for Preparation',
  'Cooking',
  'Ready / Plated',
  'Served',
];

function getStageBanner(stage?: string): { headline: string; tone: string } {
  switch (stage) {
    case 'Cooking':
      return {
        headline: 'Food Being Prepared for Your Arrival!',
        tone: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10',
      };
    case 'Ready / Plated':
      return {
        headline: 'Your Food Is Ready!',
        tone: 'text-cyan-300 border-cyan-500/30 bg-cyan-500/10',
      };
    case 'Served':
      return {
        headline: 'Served at Your Table — Enjoy Your Meal',
        tone: 'text-violet-300 border-violet-500/30 bg-violet-500/10',
      };
    case 'Waiting for Preparation':
      return {
        headline: 'Kitchen Fire Window Active — Queued Next',
        tone: 'text-amber-300 border-amber-500/30 bg-amber-500/10',
      };
    default:
      return {
        headline: 'Order Confirmed & Scheduled with Kitchen',
        tone: 'text-slate-200 border-white/10 bg-white/5',
      };
  }
}

export const MyReservationsPage: React.FC = () => {
  const { user, setIsAuthModalOpen, settings, clock, syncVersion, recentBookingCodes, showToast } = useApp();
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [tab, setTab] = useState<'upcoming' | 'past'>('upcoming');
  const [activePass, setActivePass] = useState<Reservation | null>(null);
  const [editingRes, setEditingRes] = useState<Reservation | null>(null);
  const [editTime, setEditTime] = useState('20:00');
  const [editPartySize, setEditPartySize] = useState(2);
  const [editRequests, setEditRequests] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);
  const [confirmCancelId, setConfirmCancelId] = useState<number | null>(null);
  const [confirmClearHistory, setConfirmClearHistory] = useState(false);

  const currency = settings?.currency || '₹';

  const timeSlots = useMemo(
    () => generateTimeSlots(settings?.opening_hours || '11:00 - 23:30', settings?.slot_interval_minutes || 30),
    [settings?.opening_hours, settings?.slot_interval_minutes]
  );

  const fetchReservations = useCallback(async () => {
    const trimmed = searchQuery.trim();
    const isExactCode = /^SS-\d{3,6}$/i.test(trimmed);
    try {
      const data = await api.getReservations(
        isExactCode
          ? { code: trimmed.toUpperCase() }
          : trimmed
            ? { search: trimmed }
            : undefined
      );
      setReservations(Array.isArray(data?.reservations) ? data.reservations : []);
    } catch (err) {
      console.error(err);
    }
  }, [searchQuery]);

  useEffect(() => {
    fetchReservations();
  }, [fetchReservations, syncVersion, user?.id]);

  useEffect(() => {
    if (!editingRes) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setEditingRes(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [editingRes]);

  const filtered = reservations.filter((r) => {
    const isUpcoming = r.status !== 'Completed' && r.status !== 'Cancelled' && r.status !== 'No Show';
    if (searchQuery.trim()) return true;
    return tab === 'upcoming' ? isUpcoming : !isUpcoming;
  });

  const sorted = [...filtered].sort((a, b) => {
    const aRecent = recentBookingCodes.indexOf(a.booking_code);
    const bRecent = recentBookingCodes.indexOf(b.booking_code);
    if (aRecent !== -1 && bRecent === -1) return -1;
    if (bRecent !== -1 && aRecent === -1) return 1;
    if (aRecent !== -1 && bRecent !== -1) return aRecent - bRecent;
    return b.id - a.id;
  });

  const pastCount = reservations.filter(
    (r) => r.status === 'Completed' || r.status === 'Cancelled' || r.status === 'No Show'
  ).length;

  const openEditModal = (res: Reservation) => {
    setEditingRes(res);
    setEditTime(res.arrival_time);
    setEditPartySize(res.party_size);
    setEditRequests(res.special_requests || '');
  };

  const handleSaveModify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRes) return;
    setSavingEdit(true);
    try {
      await api.modifyReservation(editingRes.id, {
        arrival_time: editTime,
        party_size: editPartySize,
        special_requests: editRequests,
      });
      showToast(`Reservation ${editingRes.booking_code} updated & kitchen schedule synced`, 'success');
      setEditingRes(null);
      fetchReservations();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Unable to modify reservation', 'error');
    } finally {
      setSavingEdit(false);
    }
  };

  const handleCancelReservation = async (res: Reservation) => {
    try {
      await api.cancelReservation(res.id);
      setConfirmCancelId(null);
      showToast(`Reservation ${res.booking_code} cancelled and pre-order stock restored`, 'info');
      fetchReservations();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Cancellation failed', 'error');
    }
  };

  const handleClearHistory = async () => {
    try {
      await api.clearOrderHistory();
      setConfirmClearHistory(false);
      showToast('Past order history cleared from your view', 'info');
      fetchReservations();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to clear history', 'error');
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <p className="text-xs font-mono text-cyan-300 uppercase tracking-wider">
            Live Guest Tracker · Kitchen Clock {clock?.display_time || '7:25 PM'}
          </p>
          <h1 className="font-display text-3xl font-bold text-white mt-1">
            My Reservations & Preparation Tracker
          </h1>
          <p className="mt-1.5 text-sm text-slate-400">
            Track real-time kitchen ticket progress, modify arrival times, or view your QR pass.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              aria-label="Search reservations by dish, guest name, or booking code"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search dish, name, or SS-4102"
              className="w-64 rounded-xl border border-white/10 bg-[#0d1224] pl-9 pr-3 py-2 text-xs text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
            />
          </div>
          <button
            type="button"
            onClick={() => setIsAuthModalOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-3.5 py-2 text-xs font-semibold text-white hover:bg-white/10 cursor-pointer"
          >
            <UserCheck className="h-3.5 w-3.5 text-violet-300" />
            <span>{user ? user.name : 'Sign In'}</span>
          </button>
          <Link
            to="/reserve"
            className="rounded-xl bg-violet-600 px-4 py-2 text-xs font-semibold text-white hover:bg-violet-500 whitespace-nowrap"
          >
            New Booking
          </Link>
        </div>
      </div>

      {!user && (
        <div className="glass-panel rounded-2xl border border-violet-500/25 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="text-sm text-slate-300">
            Sign in to view your personal booking history, or enter a confirmation code (e.g.{' '}
            <span className="font-mono text-amber-300">SS-4102</span>) in the search box above.
          </div>
          <button
            type="button"
            onClick={() => setIsAuthModalOpen(true)}
            className="rounded-xl bg-violet-600 px-4 py-2 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer shrink-0 self-start sm:self-auto"
          >
            Sign In / Create Account
          </button>
        </div>
      )}

      {/* Tabs + Clear Order History */}
      {!searchQuery.trim() && (
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 p-1 rounded-xl bg-[#0d1224] border border-white/10 w-fit">
            <button
              type="button"
              onClick={() => setTab('upcoming')}
              className={`rounded-lg px-4 py-2 text-xs font-semibold cursor-pointer transition-colors ${
                tab === 'upcoming' ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Upcoming & Active
            </button>
            <button
              type="button"
              onClick={() => setTab('past')}
              className={`rounded-lg px-4 py-2 text-xs font-semibold cursor-pointer transition-colors ${
                tab === 'past' ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Previous Reservations ({pastCount})
            </button>
          </div>

          {tab === 'past' && pastCount > 0 && user && (
            confirmClearHistory ? (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleClearHistory}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-rose-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-rose-500 cursor-pointer"
                >
                  Confirm Clear Past History
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClearHistory(false)}
                  className="rounded-xl border border-white/10 px-3 py-2 text-xs text-slate-300 hover:bg-white/5 cursor-pointer"
                >
                  Keep
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmClearHistory(true)}
                className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3.5 py-2 text-xs font-medium text-slate-300 hover:text-rose-300 hover:border-rose-500/30 cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Clear Order History
              </button>
            )
          )}
        </div>
      )}

      {sorted.length === 0 ? (
        <div className="glass-panel rounded-2xl p-12 text-center">
          <Utensils className="h-9 w-9 text-slate-500 mx-auto mb-3" />
          <p className="text-base font-semibold text-white">No matching reservations found</p>
          <p className="mt-1 text-sm text-slate-400">
            Reserve a table and attach dishes to watch live kitchen preparation updates here.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {sorted.map((res) => {
            const stageBanner = getStageBanner(res.customer_order_stage);
            const activeStageIdx = Math.max(0, STAGES.indexOf(res.customer_order_stage || 'Order Confirmed'));
            const preOrders = res.pre_orders || [];
            const tickets = res.tickets || [];
            const isCancelled = res.status === 'Cancelled' || res.status === 'No Show';
            const canModify = res.status === 'Confirmed';
            const canCancel = res.status === 'Confirmed' || res.status === 'Checked In';

            return (
              <div key={res.id} className="glass-panel rounded-2xl p-6 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span className="font-mono font-bold text-amber-300">{res.booking_code}</span>
                      <span>·</span>
                      <span className="text-white font-semibold">{res.table_number || 'Pending Table'}</span>
                      <span>·</span>
                      <span>{res.party_size} Guests</span>
                      <span>·</span>
                      <span className="tabular-nums">
                        {res.date} at {formatTime12h(res.arrival_time)}
                      </span>
                      <span>·</span>
                      <span
                        className={`font-semibold ${
                          isCancelled ? 'text-rose-300' : 'text-violet-300'
                        }`}
                      >
                        {res.status}
                      </span>
                    </div>
                    <h2 className="font-display text-xl font-bold text-white">
                      {res.customer_name}
                    </h2>
                    {res.special_requests && (
                      <p className="text-xs text-slate-400">Note: {res.special_requests}</p>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
                    {canModify && (
                      <button
                        type="button"
                        onClick={() => openEditModal(res)}
                        className="inline-flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-white/10 cursor-pointer"
                      >
                        <Edit3 className="h-3.5 w-3.5 text-amber-300" />
                        <span>Modify</span>
                      </button>
                    )}

                    {canCancel && (
                      confirmCancelId === res.id ? (
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleCancelReservation(res)}
                            className="rounded-xl bg-rose-600 px-3 py-2 text-xs font-semibold text-white hover:bg-rose-500 cursor-pointer"
                          >
                            Confirm Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmCancelId(null)}
                            className="rounded-xl border border-white/10 px-2.5 py-2 text-xs text-slate-300 hover:bg-white/5 cursor-pointer"
                          >
                            Keep
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmCancelId(res.id)}
                          className="inline-flex items-center gap-1.5 rounded-xl border border-rose-500/25 bg-rose-500/10 px-3 py-2 text-xs font-medium text-rose-300 hover:bg-rose-500/20 cursor-pointer"
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          <span>Cancel</span>
                        </button>
                      )
                    )}

                    <button
                      type="button"
                      onClick={() => setActivePass(res)}
                      className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-white hover:bg-white/10 cursor-pointer"
                    >
                      <QrCode className="h-4 w-4 text-violet-300" />
                      <span>QR Pass & Split Bill</span>
                    </button>
                  </div>
                </div>

                {/* Live Kitchen Sync Banner */}
                {preOrders.length > 0 && !isCancelled && (
                  <div className={`rounded-xl border px-4 py-3 flex items-center justify-between gap-3 ${stageBanner.tone}`}>
                    <div className="flex items-center gap-2.5 text-sm font-semibold">
                      <ChefHat className="h-4 w-4 shrink-0" />
                      <span>{stageBanner.headline}</span>
                    </div>
                    <span className="text-xs font-mono tabular-nums opacity-85">
                      {tickets.filter((t) => t.status === 'Ready' || t.status === 'Served').length}/{tickets.length} dishes ready
                    </span>
                  </div>
                )}

                {/* 5-Stage Progress Stepper */}
                {preOrders.length > 0 && !isCancelled && (
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {STAGES.map((stage, idx) => {
                      const reached = idx <= activeStageIdx;
                      return (
                        <div
                          key={stage}
                          className={`rounded-lg px-3 py-2 border text-xs transition-colors ${
                            reached
                              ? 'border-violet-500/40 bg-violet-600/20 text-white font-semibold'
                              : 'border-white/5 bg-white/[0.02] text-slate-500'
                          }`}
                        >
                          <div className="flex items-center gap-1.5">
                            <CheckCircle2
                              className={`h-3.5 w-3.5 shrink-0 ${
                                reached ? 'text-violet-300' : 'text-slate-600'
                              }`}
                            />
                            <span className="truncate">{stage}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Ordered Dishes & Ticket Timings */}
                {preOrders.length > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                    {preOrders.map((po) => {
                      const matchingTicket = tickets.find((t) => t.pre_order_id === po.id);
                      return (
                        <div
                          key={po.id}
                          className="flex items-center justify-between rounded-xl border border-white/10 bg-[#070913] px-4 py-3"
                        >
                          <div>
                            <div className="text-sm font-semibold text-white">
                              {po.quantity}x {po.item_name_snapshot}
                            </div>
                            <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2 tabular-nums">
                              <Clock className="h-3 w-3 text-amber-400" />
                              <span>
                                Scheduled Prep: {matchingTicket ? formatIsoTime12h(matchingTicket.target_prep_start) : `${po.prep_time_snapshot}m before`}
                              </span>
                            </div>
                          </div>
                          <div className="text-right">
                            <span
                              className={`text-xs font-semibold ${
                                isCancelled
                                  ? 'text-rose-300'
                                  : matchingTicket?.status === 'Ready' || matchingTicket?.status === 'Served'
                                    ? 'text-cyan-300'
                                    : matchingTicket?.status === 'Cooking'
                                      ? 'text-emerald-300'
                                      : 'text-amber-300'
                              }`}
                            >
                              {isCancelled
                                ? 'Cancelled'
                                : matchingTicket?.status === 'Ready'
                                  ? 'Ready / Plated'
                                  : matchingTicket?.status || 'Confirmed'}
                            </span>
                            <div className="text-xs font-mono text-slate-400 tabular-nums mt-0.5">
                              {formatCurrency(po.price_snapshot * po.quantity, currency)}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Modify Reservation Modal */}
      {editingRes && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="modify-reservation-title"
        >
          <form
            onSubmit={handleSaveModify}
            className="w-full max-w-md rounded-2xl glass-elevated border border-white/15 p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <p className="text-[11px] font-mono text-amber-300">{editingRes.booking_code}</p>
                <h2 id="modify-reservation-title" className="font-display text-lg font-bold text-white">Modify Reservation</h2>
              </div>
              <button
                type="button"
                aria-label="Close modify reservation dialog"
                onClick={() => setEditingRes(null)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div>
              <label htmlFor="edit-arrival-time" className="block text-xs font-medium text-slate-300 mb-1">Arrival Time</label>
              <select
                id="edit-arrival-time"
                value={editTime}
                onChange={(e) => setEditTime(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white font-mono focus:border-violet-500 focus:outline-none"
              >
                {timeSlots.map((slot) => (
                  <option key={slot} value={slot}>
                    {formatTime12h(slot)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="edit-party-size" className="block text-xs font-medium text-slate-300 mb-1">Party Size</label>
              <select
                id="edit-party-size"
                value={editPartySize}
                onChange={(e) => setEditPartySize(Number(e.target.value))}
                className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white font-mono focus:border-violet-500 focus:outline-none"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12].map((n) => (
                  <option key={n} value={n}>
                    {n} {n === 1 ? 'Guest' : 'Guests'}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="edit-special-requests" className="block text-xs font-medium text-slate-300 mb-1">Special Requests</label>
              <input
                id="edit-special-requests"
                type="text"
                value={editRequests}
                onChange={(e) => setEditRequests(e.target.value)}
                placeholder="Allergies or seating preference"
                className="w-full rounded-xl border border-white/10 bg-[#070913] px-3.5 py-2.5 text-sm text-white focus:border-violet-500 focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingRes(null)}
                className="rounded-xl border border-white/15 px-4 py-2 text-xs text-slate-300 hover:bg-white/5 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingEdit}
                className="rounded-xl bg-violet-600 px-5 py-2 text-xs font-semibold text-white hover:bg-violet-500 disabled:opacity-50 cursor-pointer"
              >
                {savingEdit ? 'Saving & Recalculating...' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      )}

      {activePass && (
        <BookingPassModal
          reservation={activePass}
          currency={currency}
          gstPct={settings?.gst_percentage}
          svcPct={settings?.service_charge_percentage}
          onClose={() => setActivePass(null)}
        />
      )}
    </div>
  );
};
