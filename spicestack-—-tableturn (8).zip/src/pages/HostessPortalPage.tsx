import React, { useCallback, useEffect, useRef, useState } from 'react';
import { UserCheck, Clock, CheckCircle2, Sparkles, RefreshCw, Search, XCircle } from 'lucide-react';
import { api } from '../services/api';
import { useApp } from '../context/AppContext';
import type { Reservation, RestaurantTable, TableStatus } from '../types';
import { formatTime12h, minutesToHHMM, timeToMinutes } from '../utils/format';
import { RoleGate } from '../components/RoleGate';

function addMinutes(hhmm: string, delta: number): string {
  return minutesToHHMM(timeToMinutes(hhmm) + delta);
}

const HostessContent: React.FC = () => {
  const { clock, syncVersion, showToast } = useApp();
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [tables, setTables] = useState<RestaurantTable[]>([]);
  const [selectedDate, setSelectedDate] = useState(
    clock?.current_date || new Date().toISOString().slice(0, 10)
  );
  const hasManualDateChange = useRef(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [confirmCancelId, setConfirmCancelId] = useState<number | null>(null);
  const [busyResId, setBusyResId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (clock?.current_date && !hasManualDateChange.current) {
      setSelectedDate(clock.current_date);
    }
  }, [clock?.current_date]);

  const loadData = useCallback(async () => {
    try {
      const [resData, tableData] = await Promise.all([
        api.getReservations({
          date: selectedDate,
          search: searchQuery.trim() || undefined,
        }),
        api.getTables({ date: selectedDate }),
      ]);
      setReservations(Array.isArray(resData?.reservations) ? resData.reservations : []);
      setTables(Array.isArray(tableData?.tables) ? tableData.tables : []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [selectedDate, searchQuery]);

  useEffect(() => {
    loadData();
  }, [loadData, syncVersion]);

  const handleCheckIn = async (res: Reservation) => {
    if (busyResId !== null) return;
    setBusyResId(res.id);
    try {
      await api.checkInReservation(res.id);
      showToast(
        `${res.customer_name} checked in — kitchen tickets promoted to Urgent!`,
        'success'
      );
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Check-in failed', 'error');
    } finally {
      setBusyResId(null);
    }
  };

  const handleStatusChange = async (res: Reservation, status: string) => {
    if (busyResId !== null) return;
    setBusyResId(res.id);
    try {
      await api.updateReservationStaff(res.id, { status });
      showToast(`Reservation ${res.booking_code} marked ${status}`, 'info');
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Update failed', 'error');
    } finally {
      setBusyResId(null);
    }
  };

  const handleCancelBooking = async (res: Reservation) => {
    if (busyResId !== null) return;
    setBusyResId(res.id);
    try {
      await api.cancelReservation(res.id);
      setConfirmCancelId(null);
      showToast(`Reservation ${res.booking_code} cancelled — table freed & stock restored`, 'info');
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Cancel failed', 'error');
    } finally {
      setBusyResId(null);
    }
  };

  const handleDelayArrival = async (res: Reservation, deltaMinutes: number) => {
    if (busyResId !== null) return;
    setBusyResId(res.id);
    const nextTime = addMinutes(res.arrival_time, deltaMinutes);
    try {
      await api.updateReservationStaff(res.id, { arrival_time: nextTime });
      showToast(
        `Arrival updated to ${formatTime12h(nextTime)} — kitchen schedule recalculated`,
        'info'
      );
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Reschedule failed', 'error');
    } finally {
      setBusyResId(null);
    }
  };

  const handleTableStatus = async (table: RestaurantTable, status: TableStatus) => {
    try {
      await api.updateTable(table.id, { status });
      showToast(`${table.table_number} status set to ${status}`, 'info');
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to update table', 'error');
    }
  };

  const handleReassignTable = async (resId: number, tableId: number) => {
    if (busyResId !== null) return;
    setBusyResId(resId);
    try {
      await api.updateReservationStaff(resId, { table_id: tableId });
      showToast('Table reassigned & kitchen tickets updated', 'success');
      loadData();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Reassignment failed', 'error');
    } finally {
      setBusyResId(null);
    }
  };

  const filteredReservations = reservations.filter(
    (r) => filterStatus === 'All' || r.status === filterStatus
  );

  const tableBadgeStyle = (status: TableStatus) => {
    switch (status) {
      case 'Available':
        return 'border-emerald-500/35 bg-emerald-500/10 text-emerald-300';
      case 'Reserved':
        return 'border-amber-500/35 bg-amber-500/10 text-amber-300';
      case 'Occupied':
        return 'border-violet-500/40 bg-violet-500/15 text-violet-200';
      case 'Cleaning':
        return 'border-cyan-500/35 bg-cyan-500/10 text-cyan-300';
      default:
        return 'border-white/10 bg-white/5 text-slate-400';
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <p className="text-xs font-mono text-amber-300 uppercase tracking-wider">
            Hostess & Floor Operations · Clock {clock?.display_time || '7:25 PM'}
          </p>
          <h1 className="font-display text-3xl font-bold text-white mt-1">
            Guest Check-In & Visual Floor Layout
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Check in arriving guests to immediately promote their kitchen tickets and monitor estimated table turn times.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="date"
            aria-label="Filter reservations by date"
            value={selectedDate}
            onChange={(e) => {
              hasManualDateChange.current = true;
              setSelectedDate(e.target.value);
            }}
            className="rounded-xl border border-white/10 bg-[#0d1224] px-3.5 py-2 text-xs font-mono text-white focus:border-violet-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={loadData}
            className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3.5 py-2 text-xs font-medium text-slate-200 hover:bg-white/10 cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </button>
        </div>
      </div>

      {/* Visual Floor Plan */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-white">
            Live Floor Seating & Turn-Time Estimator ({tables.length} Tables)
          </h2>
          <span className="text-xs text-slate-400 tabular-nums">
            {tables.filter((t) => t.status === 'Available').length} Available ·{' '}
            {tables.filter((t) => t.status === 'Occupied').length} Occupied
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {tables.map((t) => (
            <div
              key={t.id}
              className={`rounded-2xl border p-4 space-y-3 transition-all ${tableBadgeStyle(t.status)}`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-display text-base font-bold text-white">
                    {t.table_number}
                  </h3>
                  <p className="text-xs text-slate-300/80">
                    {t.capacity} Seats · {t.section}
                  </p>
                </div>
                <select
                  aria-label={`Set status for ${t.table_number}`}
                  value={t.status}
                  onChange={(e) => handleTableStatus(t, e.target.value as TableStatus)}
                  disabled={t.status === 'Disabled'}
                  className="rounded-lg border border-white/15 bg-[#070913]/80 px-2 py-1 text-xs font-semibold text-white focus:outline-none cursor-pointer"
                >
                  <option value="Available">Available</option>
                  <option value="Reserved">Reserved</option>
                  <option value="Occupied">Occupied</option>
                  <option value="Cleaning">Cleaning</option>
                  <option value="Maintenance">Maintenance</option>
                  {t.status === 'Disabled' && <option value="Disabled">Disabled</option>}
                </select>
              </div>

              {t.estimated_turn_time ? (
                <div className="flex items-center justify-between text-xs border-t border-white/10 pt-2.5 text-cyan-200 tabular-nums">
                  <span>Est. Free: {t.estimated_turn_time}</span>
                  <span className="font-mono font-semibold">~{t.minutes_remaining}m left</span>
                </div>
              ) : (
                <div className="text-xs border-t border-white/10 pt-2.5 text-slate-400">
                  {t.type}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Reservations Arrival Schedule */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-lg font-semibold text-white">
            Arrival Schedule ({filteredReservations.length})
          </h2>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                aria-label="Search reservations"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search guest, SS-code, or phone"
                className="w-56 rounded-xl border border-white/10 bg-[#0d1224] pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#0d1224] border border-white/10 overflow-x-auto">
              {['All', 'Confirmed', 'Checked In', 'Seated', 'Completed', 'Cancelled'].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setFilterStatus(st)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium cursor-pointer whitespace-nowrap ${
                    filterStatus === st ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>
        </div>

        {loading ? (
          <div className="glass-panel rounded-2xl h-48 animate-pulse" />
        ) : filteredReservations.length === 0 ? (
          <div className="glass-panel rounded-2xl p-10 text-center text-sm text-slate-400">
            No reservations found for {selectedDate}.
          </div>
        ) : (
          <div className="space-y-3">
            {filteredReservations.map((res) => (
              <div
                key={res.id}
                className="glass-panel rounded-2xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-5"
              >
                <div className="space-y-1.5 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                    <span className="font-mono font-bold text-amber-300">{res.booking_code}</span>
                    <span>·</span>
                    <span className="font-mono text-white font-semibold tabular-nums">
                      {formatTime12h(res.arrival_time)}
                    </span>
                    <span>·</span>
                    <span>{res.party_size} Guests</span>
                    <span>·</span>
                    <span
                      className={`font-semibold ${
                        res.status === 'Cancelled' || res.status === 'No Show'
                          ? 'text-rose-300'
                          : 'text-violet-300'
                      }`}
                    >
                      {res.status}
                    </span>
                    {res.special_requests && (
                      <>
                        <span>·</span>
                        <span className="text-amber-200">{res.special_requests}</span>
                      </>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <h3 className="font-display text-lg font-bold text-white">
                      {res.customer_name}
                    </h3>
                    <span className="text-xs text-slate-400 tabular-nums">{res.phone}</span>
                  </div>

                  {(res.pre_orders?.length || 0) > 0 && (
                    <div className="text-xs text-slate-300 pt-1">
                      <span className="text-slate-400">Pre-Order: </span>
                      {res.pre_orders!.map((p) => `${p.quantity}x ${p.item_name_snapshot}`).join(', ')}
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                  {/* Table reassign */}
                  <select
                    aria-label={`Assign table for ${res.booking_code}`}
                    value={res.table_id || ''}
                    disabled={res.status === 'Completed' || res.status === 'Cancelled' || busyResId === res.id}
                    onChange={(e) => handleReassignTable(res.id, Number(e.target.value))}
                    className="rounded-lg border border-white/10 bg-[#070913] px-2.5 py-2 text-xs text-white focus:outline-none cursor-pointer disabled:opacity-50"
                  >
                    {tables
                      .filter((t) => t.is_active === 1)
                      .map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.table_number} ({t.capacity}p)
                        </option>
                      ))}
                  </select>

                  {res.status === 'Confirmed' && (
                    <>
                      <button
                        type="button"
                        disabled={busyResId === res.id}
                        onClick={() => handleDelayArrival(res, 15)}
                        className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-white/10 cursor-pointer disabled:opacity-50"
                      >
                        <Clock className="h-3.5 w-3.5 text-amber-300" />
                        +15m Late
                      </button>

                      {confirmCancelId === res.id ? (
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            disabled={busyResId === res.id}
                            onClick={() => handleCancelBooking(res)}
                            className="rounded-lg bg-rose-600 px-3 py-2 text-xs font-semibold text-white hover:bg-rose-500 cursor-pointer disabled:opacity-50"
                          >
                            Confirm Cancel
                          </button>
                          <button
                            type="button"
                            disabled={busyResId === res.id}
                            onClick={() => setConfirmCancelId(null)}
                            className="rounded-lg border border-white/10 px-2.5 py-2 text-xs text-slate-300 hover:bg-white/5 cursor-pointer"
                          >
                            Keep
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          disabled={busyResId === res.id}
                          onClick={() => setConfirmCancelId(res.id)}
                          className="inline-flex items-center gap-1 rounded-lg border border-rose-500/25 bg-rose-500/10 px-3 py-2 text-xs font-medium text-rose-300 hover:bg-rose-500/20 cursor-pointer disabled:opacity-50"
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          Cancel
                        </button>
                      )}

                      <button
                        type="button"
                        disabled={busyResId === res.id}
                        onClick={() => handleCheckIn(res)}
                        className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-emerald-950/40 hover:from-emerald-500 hover:to-teal-500 cursor-pointer disabled:opacity-50"
                      >
                        <UserCheck className="h-4 w-4" />
                        {busyResId === res.id ? 'Checking In...' : 'GUEST ARRIVED — CHECK IN'}
                      </button>
                    </>
                  )}

                  {res.status === 'Checked In' && (
                    <button
                      type="button"
                      disabled={busyResId === res.id}
                      onClick={() => handleStatusChange(res, 'Seated')}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-violet-600 px-4 py-2 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer disabled:opacity-50"
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      Seat at Table
                    </button>
                  )}

                  {(res.status === 'Seated' || res.status === 'Checked In') && (
                    <button
                      type="button"
                      disabled={busyResId === res.id}
                      onClick={() => handleStatusChange(res, 'Completed')}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-cyan-500/30 bg-cyan-500/15 px-3.5 py-2 text-xs font-semibold text-cyan-200 hover:bg-cyan-500/25 cursor-pointer disabled:opacity-50"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Complete & Clear
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

export const HostessPortalPage: React.FC = () => (
  <RoleGate
    allowedRoles={['hostess', 'manager']}
    recommendedRole="hostess"
    portalTitle="Hostess & Staff Portal"
  >
    <HostessContent />
  </RoleGate>
);
