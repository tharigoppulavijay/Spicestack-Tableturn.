import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Clock, ShieldCheck, Utensils, CalendarCheck2 } from 'lucide-react';
import { api } from '../services/api';
import { useApp } from '../context/AppContext';
import type { MenuItem } from '../types';
import { formatCurrency } from '../utils/format';
import { DishImage } from '../components/DishImage';

const HERO_IMG = '/src/assets/images/hero_dining_table_1795006342659.jpg';

export const LandingPage: React.FC = () => {
  const { settings, addToCart, syncVersion } = useApp();
  const [featured, setFeatured] = useState<MenuItem[]>([]);
  const navigate = useNavigate();
  const currency = settings?.currency || '₹';

  useEffect(() => {
    api
      .getMenu()
      .then((data) => {
        const items = Array.isArray(data?.items) ? data.items : [];
        const specials = items.filter((i) => i.is_chef_special === 1 || i.is_popular === 1);
        setFeatured((specials.length > 0 ? specials : items).slice(0, 6));
      })
      .catch(console.error);
  }, [syncVersion]);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-white/10">
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_top_right,rgba(124,58,237,0.18),transparent_55%),radial-gradient(ellipse_at_bottom_left,rgba(245,158,11,0.12),transparent_50%)]" />

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
              <p className="text-xs font-medium tracking-wider uppercase text-amber-300">
                {settings?.restaurant_name || 'SpiceStack — TableTurn'} · Smart Hospitality
              </p>

              <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.5rem] font-extrabold tracking-tight text-white leading-[1.08] text-balance">
                Your Table. Your Time. Your Meal.
              </h1>

              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-xl">
                Reserve Smart. Arrive Hungry. Eat Without Waiting. Book your exact table slot, pre-order signature Indian and Continental dishes, and let our kitchen time every flame to your arrival minute.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  type="button"
                  onClick={() => navigate('/reserve')}
                  className="inline-flex items-center gap-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-violet-900/30 hover:from-violet-500 hover:to-indigo-500 transition-all cursor-pointer"
                >
                  <span>Reserve a Table</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
                <Link
                  to="/menu"
                  className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-6 py-3.5 text-sm font-semibold text-slate-100 hover:bg-white/10 transition-colors"
                >
                  Explore Menu
                </Link>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="relative h-72 sm:h-96 lg:h-full min-h-[340px] rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                <img
                  src={HERO_IMG}
                  alt="SpiceStack fine dining room with warm amber lighting and curated dishes"
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#070913]/90 via-[#070913]/25 to-transparent" />
                <div className="absolute bottom-5 left-5 right-5 flex flex-wrap items-end justify-between gap-4">
                  <div>
                    <p className="text-xs font-mono text-amber-300">ARRIVAL-SYNCHRONIZED ENGINE</p>
                    <p className="text-sm sm:text-base font-semibold text-white mt-0.5">
                      TargetPrepStart = GuestArrival − DishPrepTime
                    </p>
                  </div>
                  <span className="text-xs font-mono text-slate-300 tabular-nums">
                    {settings?.opening_hours || '11:00 - 23:30'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 4-column proof strip */}
          <div className="mt-14 grid grid-cols-2 lg:grid-cols-4 gap-4 border-t border-white/10 pt-10">
            <div className="glass-panel rounded-xl p-5">
              <div className="font-display text-2xl sm:text-3xl font-bold text-white tabular-nums">0 min</div>
              <div className="mt-1 text-xs text-slate-400">Table & kitchen wait on arrival</div>
            </div>
            <div className="glass-panel rounded-xl p-5">
              <div className="font-display text-2xl sm:text-3xl font-bold text-amber-300 tabular-nums">
                {settings?.dining_duration || 90} min
              </div>
              <div className="mt-1 text-xs text-slate-400">Overlap-protected table slots</div>
            </div>
            <div className="glass-panel rounded-xl p-5">
              <div className="font-display text-2xl sm:text-3xl font-bold text-violet-300 tabular-nums">28+</div>
              <div className="mt-1 text-xs text-slate-400">Indian & Continental dishes</div>
            </div>
            <div className="glass-panel rounded-xl p-5">
              <div className="font-display text-2xl sm:text-3xl font-bold text-cyan-300 tabular-nums">4 Portals</div>
              <div className="mt-1 text-xs text-slate-400">Guest, Hostess, Kitchen & Manager</div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 border-b border-white/10">
        <div className="max-w-2xl mb-10">
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
            How Arrival-Synchronized Dining Works
          </h2>
          <p className="mt-2 text-sm sm:text-base text-slate-400">
            Every course is fired strictly according to your arrival minute and dish preparation duration — never too early, never late.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass-panel rounded-2xl p-6 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-violet-300">01. RESERVE</span>
              <CalendarCheck2 className="h-5 w-5 text-violet-400" />
            </div>
            <h3 className="font-display text-lg font-semibold text-white">
              Lock Your Exact Table
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Choose your party size, date, and 90-minute slot. Our allocator prevents double bookings and lets you pick your preferred section.
            </p>
          </div>

          <div className="glass-panel rounded-2xl p-6 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-amber-300">02. PRE-ORDER</span>
              <Utensils className="h-5 w-5 text-amber-400" />
            </div>
            <h3 className="font-display text-lg font-semibold text-white">
              Customize Courses & Notes
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Select dishes, specify allergies or spice tweaks, and review automated GST and service charge calculations before arriving.
            </p>
          </div>

          <div className="glass-panel rounded-2xl p-6 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-cyan-300">03. SYNCHRONIZE</span>
              <Clock className="h-5 w-5 text-cyan-400" />
            </div>
            <h3 className="font-display text-lg font-semibold text-white">
              Kitchen Fires on Schedule
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              For an 8:00 PM table with 20-minute Chicken Biryani, the kitchen gets the fire alert at 7:40 PM — plating piping hot as you sit.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Dishes */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 border-b border-white/10">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-10">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Signature Culinary Selections
            </h2>
            <p className="mt-2 text-sm text-slate-400">
              Live from our kitchen inventory — add directly to your pre-order cart.
            </p>
          </div>
          <Link
            to="/menu"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-violet-300 hover:text-violet-200"
          >
            <span>View Full Menu</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featured.map((item) => {
            const soldOut = item.availability !== 1 || item.stock_quantity <= 0;
            return (
              <div
                key={item.id}
                className="glass-panel rounded-2xl overflow-hidden flex flex-col hover:border-white/20 transition-all"
              >
                <div className="aspect-[4/3] w-full overflow-hidden bg-slate-900 relative">
                  <DishImage
                    src={item.image}
                    alt={item.name}
                    className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                  {soldOut && (
                    <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                      <span className="font-display text-sm font-bold tracking-wider uppercase text-rose-300">
                        Sold Out
                      </span>
                    </div>
                  )}
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-1.5">
                    <div className="text-xs text-slate-400">
                      <span>{item.category_name}</span>
                      <span className="mx-1.5">·</span>
                      <span className="tabular-nums">{item.preparation_time} min prep</span>
                      <span className="mx-1.5">·</span>
                      <span className={item.dietary_type === 'Non-Veg' ? 'text-rose-300' : 'text-emerald-300'}>
                        {item.dietary_type}
                      </span>
                    </div>
                    <h3 className="font-display text-lg font-semibold text-white">
                      {item.name}
                    </h3>
                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/10">
                    <span className="font-mono text-base font-bold text-amber-300 tabular-nums">
                      {formatCurrency(item.price, currency)}
                    </span>
                    <button
                      type="button"
                      disabled={soldOut}
                      onClick={() => addToCart(item)}
                      className={`rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                        soldOut
                          ? 'bg-white/5 text-slate-500 cursor-not-allowed'
                          : 'bg-violet-600 text-white hover:bg-violet-500'
                      }`}
                    >
                      {soldOut ? 'Sold Out' : 'Add to Pre-Order'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Platform Portals */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="glass-elevated rounded-2xl p-8 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-3">
            <div className="inline-flex items-center gap-2 text-xs font-medium text-cyan-300">
              <ShieldCheck className="h-4 w-4" />
              <span>Unified Restaurant Operating System</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
              Connected Customer, Hostess, Kitchen & Manager Portals
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed max-w-2xl">
              Use the Demo Controls dock at the bottom right to switch roles instantly or advance the simulated clock to watch kitchen fire alerts and customer trackers synchronize in real time.
            </p>
          </div>
          <div className="lg:col-span-5 grid grid-cols-2 gap-3">
            <Link
              to="/reserve"
              className="rounded-xl border border-white/10 bg-white/5 p-4 hover:bg-white/10 transition-colors"
            >
              <div className="text-sm font-semibold text-white">Guest Booking</div>
              <div className="text-xs text-slate-400 mt-1">Tables & Pre-Order</div>
            </Link>
            <Link
              to="/staff"
              className="rounded-xl border border-white/10 bg-white/5 p-4 hover:bg-white/10 transition-colors"
            >
              <div className="text-sm font-semibold text-white">Hostess Desk</div>
              <div className="text-xs text-slate-400 mt-1">Floor & Check-In</div>
            </Link>
            <Link
              to="/kitchen"
              className="rounded-xl border border-white/10 bg-white/5 p-4 hover:bg-white/10 transition-colors"
            >
              <div className="text-sm font-semibold text-white">Kitchen KDS</div>
              <div className="text-xs text-slate-400 mt-1">Arrival Fire Engine</div>
            </Link>
            <Link
              to="/admin"
              className="rounded-xl border border-white/10 bg-white/5 p-4 hover:bg-white/10 transition-colors"
            >
              <div className="text-sm font-semibold text-white">Manager Suite</div>
              <div className="text-xs text-slate-400 mt-1">Analytics & Config</div>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 py-8 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            <span className="font-display font-semibold text-slate-200">
              {settings?.restaurant_name || 'SpiceStack — TableTurn'}
            </span>
            <span className="mx-2">·</span>
            <span>{settings?.address || '428 Indigo Boulevard, Culinary District'}</span>
          </div>
          <div className="flex items-center gap-5">
            <Link to="/menu" className="hover:text-white">Menu</Link>
            <Link to="/reserve" className="hover:text-white">Reserve</Link>
            <Link to="/my-reservations" className="hover:text-white">Track Order</Link>
            <span>{settings?.phone || '+91 80 4120 8899'}</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
