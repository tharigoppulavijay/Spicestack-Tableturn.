import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Clock,
  Flame,
  Maximize2,
  Minimize2,
  Play,
  Utensils,
} from 'lucide-react';
import { api } from '../services/api';
import { useApp } from '../context/AppContext';
import type { KitchenTicket, TicketPriority } from '../types';
import { formatIsoTime12h, formatTime12h } from '../utils/format';
import { RoleGate } from '../components/RoleGate';

const KitchenContent: React.FC = () => {
  const { clock, advanceClock, setClockTime, syncVersion, showToast } = useApp();
  const [tickets, setTickets] = useState<KitchenTicket[]>([]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [updatingTicketId, setUpdatingTicketId] = useState<number | null>(null);

  const loadTickets = async () => {
    try {
      const data = await api.getKitchenTickets();
      setTickets(Array.isArray(data?.tickets) ? data.tickets : []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTickets();
  }, [syncVersion]);

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {
      setIsFullscreen((v) => !v);
    }
  };

  const updateStatus = async (ticket: KitchenTicket, status: 'Cooking' | 'Ready' | 'Served') => {
    if (updatingTicketId === ticket.id) return;
    setUpdatingTicketId(ticket.id);
    try {
      await api.updateKitchenTicket(ticket.id, { status });
      showToast(
        `${ticket.item_name} (${ticket.table_number}) → ${status}`,
        status === 'Ready' ? 'success' : 'info'
      );
      await loadTickets();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to update ticket', 'error');
    } finally {
      setUpdatingTicketId(null);
    }
  };

  const cyclePriority = async (ticket: KitchenTicket) => {
    if (updatingTicketId === ticket.id) return;
    setUpdatingTicketId(ticket.id);
    const order: TicketPriority[] = ['Normal', 'High', 'Urgent'];
    const next = order[(order.indexOf(ticket.priority) + 1) % order.length];
    try {
      await api.updateKitchenTicket(ticket.id, { priority: next });
      await loadTickets();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed to update priority', 'error');
    } finally {
      setUpdatingTicketId(null);
    }
  };

  const pending = tickets.filter((t) => t.status === 'Pending');
  const cooking = tickets.filter((t) => t.status === 'Cooking');
  const ready = tickets.filter((t) => t.status === 'Ready');
  const overdueCount = tickets.filter((t) => t.is_overdue).length;

  const renderTicketCard = (t: KitchenTicket) => {
    const statusStyles =
      t.status === 'Pending'
        ? t.should_fire_now
          ? 'border-amber-400/70 bg-amber-950/30'
          : 'border-amber-500/30 bg-[#121629]'
        : t.status === 'Cooking'
          ? 'border-emerald-500/50 bg-emerald-950/25'
          : 'border-cyan-500/50 bg-cyan-950/25';

    const headerColor =
      t.status === 'Pending'
        ? 'text-amber-300'
        : t.status === 'Cooking'
          ? 'text-emerald-300'
          : 'text-cyan-300';

    return (
      <div
        key={t.id}
        className={`rounded-2xl border p-4 space-y-3 transition-all ${statusStyles}`}
      >
        {/* Top Row: Table, Code, Priority */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs">
            <span className="font-display text-sm font-bold text-white">
              {t.table_number}
            </span>
            <span className="text-slate-500">·</span>
            <span className="font-mono text-slate-300">{t.booking_code}</span>
          </div>

          <button
            type="button"
            onClick={() => cyclePriority(t)}
            title="Click to cycle priority"
            className={`rounded-md px-2 py-0.5 text-[11px] font-bold uppercase cursor-pointer ${
              t.priority === 'Urgent'
                ? 'bg-rose-500/25 text-rose-200 border border-rose-500/40'
                : t.priority === 'High'
                  ? 'bg-amber-500/20 text-amber-200 border border-amber-500/35'
                  : 'bg-white/5 text-slate-300 border border-white/10'
            }`}
          >
            {t.priority}
          </button>
        </div>

        {/* Fire Alert Banner */}
        {t.fire_alert_message && (
          <div
            className={`rounded-xl px-3 py-2 text-xs font-mono font-bold flex items-center gap-2 ${
              t.is_overdue
                ? 'bg-rose-600/30 border border-rose-400/50 text-rose-100'
                : 'bg-amber-500/25 border border-amber-400/50 text-amber-100'
            }`}
          >
            {t.is_overdue ? (
              <AlertTriangle className="h-4 w-4 text-rose-300 shrink-0" />
            ) : (
              <Flame className="h-4 w-4 text-amber-300 shrink-0" />
            )}
            <span>{t.fire_alert_message}</span>
          </div>
        )}

        {/* Dish Title & Quantity */}
        <div>
          <div className="flex items-baseline justify-between gap-2">
            <h3 className="font-display text-lg font-bold text-white">
              <span className={`font-mono mr-1.5 ${headerColor}`}>{t.quantity}x</span>
              {t.item_name}
            </h3>
            <span className="font-mono text-xs text-slate-300 tabular-nums shrink-0">
              {t.preparation_time}m prep
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Guest: {t.customer_name} · Arrival {formatTime12h(t.arrival_time || '')}
          </p>
        </div>

        {/* Countdown Metadata */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono border-t border-white/10 pt-2.5 tabular-nums">
          <span className="text-slate-300">
            Target Fire: {formatIsoTime12h(t.target_prep_start)}
          </span>
          {t.status === 'Pending' && (
            <span className={t.should_fire_now ? 'text-amber-300 font-bold' : 'text-slate-400'}>
              {(t.minutes_until_fire ?? 0) > 0
                ? `Fires in ${t.minutes_until_fire}m`
                : `Arrival in ${t.minutes_until_arrival}m`}
            </span>
          )}
          {t.status === 'Cooking' && (
            <span className="text-emerald-300 font-bold">
              {t.cooking_remaining_minutes}m cooking left
            </span>
          )}
          {t.status === 'Ready' && (
            <span className="text-cyan-300 font-bold">Plated & Ready</span>
          )}
        </div>

        {/* Special Instructions & Allergies */}
        {(t.notes || (t.allergies && t.allergies !== 'None')) && (
          <div className="rounded-lg bg-black/40 border border-white/10 p-2.5 space-y-1 text-xs">
            {t.allergies && t.allergies !== 'None' && (
              <div className="font-semibold text-rose-300">
                ALLERGY: {t.allergies}
              </div>
            )}
            {t.notes && <div className="text-amber-200">Note: {t.notes}</div>}
          </div>
        )}

        {/* Action Buttons */}
        <div className="pt-1 flex gap-2">
          {t.status === 'Pending' && (
            <button
              type="button"
              disabled={updatingTicketId === t.id}
              onClick={() => updateStatus(t, 'Cooking')}
              className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2.5 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-50 cursor-pointer"
            >
              <Play className="h-3.5 w-3.5" />
              {updatingTicketId === t.id ? 'Updating...' : 'Start Cooking'}
            </button>
          )}
          {t.status === 'Cooking' && (
            <button
              type="button"
              disabled={updatingTicketId === t.id}
              onClick={() => updateStatus(t, 'Ready')}
              className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-cyan-600 px-3 py-2.5 text-xs font-bold text-white hover:bg-cyan-500 disabled:opacity-50 cursor-pointer"
            >
              <CheckCircle2 className="h-3.5 w-3.5" />
              {updatingTicketId === t.id ? 'Updating...' : 'Mark Ready'}
            </button>
          )}
          {t.status === 'Ready' && (
            <button
              type="button"
              disabled={updatingTicketId === t.id}
              onClick={() => updateStatus(t, 'Served')}
              className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-3 py-2.5 text-xs font-bold text-white hover:bg-violet-500 disabled:opacity-50 cursor-pointer"
            >
              <Utensils className="h-3.5 w-3.5" />
              {updatingTicketId === t.id ? 'Updating...' : 'Mark Served'}
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#050710] text-slate-100">
      {/* Dedicated KDS Header */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#080b18]/95 backdrop-blur-xl px-4 sm:px-6 py-3.5">
        <div className="mx-auto max-w-[1600px] flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Link
              to="/"
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-white/10"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Exit KDS
            </Link>
            <div>
              <h1 className="font-display text-lg sm:text-xl font-bold text-white">
                Kitchen Display System
              </h1>
              <div className="text-xs text-slate-400 tabular-nums">
                {pending.length} Pending · {cooking.length} Cooking · {ready.length} Ready
                {overdueCount > 0 && (
                  <span className="ml-2 text-rose-300 font-semibold">
                    · {overdueCount} Overdue
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Integrated Clock & Demo Fire Controls */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-xs font-mono text-amber-200 tabular-nums">
              <Clock className="h-3.5 w-3.5 text-amber-400" />
              <span>{clock?.display_time || '7:25 PM'}</span>
            </div>
            <button
              type="button"
              onClick={() => setClockTime('19:40')}
              className="rounded-lg border border-amber-400/30 bg-amber-500/15 px-3 py-1.5 text-xs font-mono font-semibold text-amber-200 hover:bg-amber-500/25 cursor-pointer"
            >
              Jump 7:40 PM
            </button>
            <button
              type="button"
              onClick={() => advanceClock(5)}
              className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs font-mono text-slate-200 hover:bg-white/10 cursor-pointer"
            >
              +5m
            </button>
            <button
              type="button"
              onClick={() => advanceClock(15)}
              className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs font-mono text-slate-200 hover:bg-white/10 cursor-pointer"
            >
              +15m
            </button>
            <button
              type="button"
              onClick={toggleFullscreen}
              aria-label="Toggle fullscreen kitchen mode"
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-white/10 cursor-pointer"
            >
              {isFullscreen ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
              <span className="hidden sm:inline">{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* 3-Column KDS Board */}
      <main className="mx-auto max-w-[1600px] p-4 sm:p-6">
        {loading ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div key={n} className="h-96 rounded-2xl bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            {/* Yellow: Pending / Scheduled */}
            <section className="space-y-4">
              <div className="flex items-center justify-between border-b border-amber-500/30 pb-3">
                <h2 className="font-display text-base font-bold text-amber-300">
                  Pending & Scheduled
                </h2>
                <span className="font-mono text-xs font-bold text-amber-200 tabular-nums">
                  {pending.length}
                </span>
              </div>
              <div className="space-y-4">
                {pending.length === 0 ? (
                  <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-8 text-center text-xs text-slate-500">
                    No pending tickets
                  </div>
                ) : (
                  pending.map(renderTicketCard)
                )}
              </div>
            </section>

            {/* Green: Cooking */}
            <section className="space-y-4">
              <div className="flex items-center justify-between border-b border-emerald-500/30 pb-3">
                <h2 className="font-display text-base font-bold text-emerald-300">
                  Cooking on Line
                </h2>
                <span className="font-mono text-xs font-bold text-emerald-200 tabular-nums">
                  {cooking.length}
                </span>
              </div>
              <div className="space-y-4">
                {cooking.length === 0 ? (
                  <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-8 text-center text-xs text-slate-500">
                    No active cooking tickets
                  </div>
                ) : (
                  cooking.map(renderTicketCard)
                )}
              </div>
            </section>

            {/* Blue: Ready / Plated */}
            <section className="space-y-4">
              <div className="flex items-center justify-between border-b border-cyan-500/30 pb-3">
                <h2 className="font-display text-base font-bold text-cyan-300">
                  Plated / Ready for Pass
                </h2>
                <span className="font-mono text-xs font-bold text-cyan-200 tabular-nums">
                  {ready.length}
                </span>
              </div>
              <div className="space-y-4">
                {ready.length === 0 ? (
                  <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-8 text-center text-xs text-slate-500">
                    No plated tickets waiting
                  </div>
                ) : (
                  ready.map(renderTicketCard)
                )}
              </div>
            </section>
          </div>
        )}
      </main>
    </div>
  );
};

export const KitchenDisplayPage: React.FC = () => (
  <RoleGate
    allowedRoles={['kitchen', 'manager']}
    recommendedRole="kitchen"
    portalTitle="Kitchen Display System"
  >
    <KitchenContent />
  </RoleGate>
);
