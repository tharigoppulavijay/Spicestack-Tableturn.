import React, { useEffect, useMemo, useState } from 'react';
import { Search, ShoppingBag, SlidersHorizontal, Flame, Plus } from 'lucide-react';
import { api } from '../services/api';
import { useApp } from '../context/AppContext';
import type { Category, MenuItem } from '../types';
import { formatCurrency } from '../utils/format';
import { DishImage } from '../components/DishImage';

export const MenuPage: React.FC = () => {
  const { settings, addToCart, cartTotals, setIsCartOpen, syncVersion } = useApp();
  const [items, setItems] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [dietaryFilter, setDietaryFilter] = useState<string>('All');
  const [spiceFilter, setSpiceFilter] = useState<string>('All');
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'prep'>('featured');
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);
  const [customNote, setCustomNote] = useState('');
  const [allergyNote, setAllergyNote] = useState('');

  const currency = settings?.currency || '₹';

  useEffect(() => {
    if (!customizingItem) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setCustomizingItem(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [customizingItem]);

  useEffect(() => {
    let active = true;
    Promise.all([api.getMenu(), api.getCategories()])
      .then(([menuRes, catRes]) => {
        if (!active) return;
        setItems(Array.isArray(menuRes?.items) ? menuRes.items : []);
        setCategories(Array.isArray(catRes?.categories) ? catRes.categories : []);
      })
      .catch(console.error)
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [syncVersion]);

  const filteredItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = items.filter((item) => {
      if (selectedCategory !== 'All' && item.category_name !== selectedCategory) return false;
      if (dietaryFilter !== 'All' && item.dietary_type !== dietaryFilter) return false;
      if (spiceFilter !== 'All' && item.spicy_level !== spiceFilter) return false;
      if (
        q &&
        !item.name.toLowerCase().includes(q) &&
        !item.description.toLowerCase().includes(q) &&
        !(item.category_name || '').toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });

    if (sortBy === 'price-asc') return [...list].sort((a, b) => a.price - b.price);
    if (sortBy === 'price-desc') return [...list].sort((a, b) => b.price - a.price);
    if (sortBy === 'prep') return [...list].sort((a, b) => a.preparation_time - b.preparation_time);
    return list;
  }, [items, selectedCategory, dietaryFilter, spiceFilter, search, sortBy]);

  const handleConfirmCustomize = () => {
    if (!customizingItem) return;
    addToCart(customizingItem, 1, customNote, allergyNote);
    setCustomizingItem(null);
    setCustomNote('');
    setAllergyNote('');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-white/10 pb-8">
        <div>
          <p className="text-xs font-mono text-amber-300 uppercase tracking-wider">
            Live Synchronized Menu
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white mt-1">
            Digital Culinary Menu
          </h1>
          <p className="mt-2 text-sm text-slate-400 max-w-2xl">
            Pre-order your dishes for zero wait time. Every preparation duration is synced directly with the kitchen fire engine.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsCartOpen(true)}
          className="inline-flex items-center gap-2.5 rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white hover:bg-violet-500 transition-colors self-start md:self-auto cursor-pointer"
        >
          <ShoppingBag className="h-4 w-4" />
          <span className="tabular-nums">
            View Pre-Order ({cartTotals.itemCount}) · {formatCurrency(cartTotals.total, currency)}
          </span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="mt-6 space-y-4">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              aria-label="Search menu dishes"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search dishes, ingredients, or cuisine..."
              className="w-full rounded-xl border border-white/10 bg-[#0d1224] pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 rounded-xl bg-[#0d1224] p-1 border border-white/10">
              {['All', 'Veg', 'Non-Veg', 'Vegan'].map((diet) => (
                <button
                  key={diet}
                  type="button"
                  onClick={() => setDietaryFilter(diet)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer ${
                    dietaryFilter === diet
                      ? 'bg-violet-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {diet}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-[#0d1224] px-3 py-1.5">
              <Flame className="h-3.5 w-3.5 text-amber-400" />
              <select
                aria-label="Filter by spice level"
                value={spiceFilter}
                onChange={(e) => setSpiceFilter(e.target.value)}
                className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer"
              >
                <option value="All" className="bg-[#0d1224]">All Spice Levels</option>
                <option value="Mild" className="bg-[#0d1224]">Mild</option>
                <option value="Medium" className="bg-[#0d1224]">Medium</option>
                <option value="Hot" className="bg-[#0d1224]">Hot</option>
                <option value="Extra Hot" className="bg-[#0d1224]">Extra Hot</option>
              </select>
            </div>

            <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-[#0d1224] px-3 py-1.5">
              <SlidersHorizontal className="h-3.5 w-3.5 text-slate-400" />
              <select
                aria-label="Sort menu dishes"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer"
              >
                <option value="featured" className="bg-[#0d1224]">Featured Order</option>
                <option value="price-asc" className="bg-[#0d1224]">Price: Low to High</option>
                <option value="price-desc" className="bg-[#0d1224]">Price: High to Low</option>
                <option value="prep" className="bg-[#0d1224]">Fastest Prep Time</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            type="button"
            onClick={() => setSelectedCategory('All')}
            className={`rounded-lg px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              selectedCategory === 'All'
                ? 'bg-white text-slate-950'
                : 'border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            All Categories ({items.length})
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.name)}
              className={`rounded-lg px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                selectedCategory === cat.name
                  ? 'bg-white text-slate-950'
                  : 'border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Menu Grid */}
      {loading ? (
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div key={n} className="glass-panel rounded-2xl h-96 animate-pulse" />
          ))}
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="mt-12 glass-panel rounded-2xl p-12 text-center">
          <p className="text-lg font-semibold text-white">No dishes match your filters</p>
          <p className="mt-1 text-sm text-slate-400">Try clearing the search query or switching categories.</p>
          <button
            type="button"
            onClick={() => {
              setSelectedCategory('All');
              setDietaryFilter('All');
              setSpiceFilter('All');
              setSearch('');
            }}
            className="mt-4 rounded-lg bg-violet-600 px-4 py-2 text-xs font-semibold text-white cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => {
            const soldOut = item.availability !== 1 || item.stock_quantity <= 0;
            return (
              <div
                key={item.id}
                className="glass-panel rounded-2xl overflow-hidden flex flex-col justify-between hover:border-white/20 transition-all"
              >
                <div>
                  <div className="aspect-[4/3] w-full relative overflow-hidden bg-slate-900">
                    <DishImage
                      src={item.image}
                      alt={item.name}
                      className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                    {soldOut && (
                      <div className="absolute inset-0 bg-black/75 flex items-center justify-center">
                        <span className="rounded-lg border border-rose-500/40 bg-rose-950/80 px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider text-rose-200">
                          Sold Out
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="p-5 space-y-2">
                    {/* Clean unboxed metadata */}
                    <div className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs text-slate-400">
                      <span className="text-slate-300 font-medium">{item.category_name}</span>
                      <span>·</span>
                      <span className="tabular-nums">{item.preparation_time} min prep</span>
                      <span>·</span>
                      <span className={item.dietary_type === 'Non-Veg' ? 'text-rose-300' : 'text-emerald-300'}>
                        {item.dietary_type}
                      </span>
                      {(item.is_chef_special === 1 || item.is_popular === 1) && (
                        <>
                          <span>·</span>
                          <span className="text-amber-300 font-medium">
                            {item.is_chef_special === 1 ? "Chef's Special" : 'Popular'}
                          </span>
                        </>
                      )}
                    </div>

                    <h2 className="font-display text-lg font-semibold text-white">
                      {item.name}
                    </h2>
                    <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                      {item.description}
                    </p>

                    <div className="flex items-center gap-3 pt-1 text-[11px] text-slate-400">
                      <span className="inline-flex items-center gap-1">
                        <Flame className="h-3.5 w-3.5 text-amber-400" />
                        {item.spicy_level}
                      </span>
                      {item.allergy_info && item.allergy_info !== 'None' && (
                        <span>Allergens: {item.allergy_info}</span>
                      )}
                      {!soldOut && item.stock_quantity <= 6 && (
                        <span className="text-amber-300 tabular-nums">Only {item.stock_quantity} left</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="px-5 pb-5 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                  <span className="font-mono text-base font-bold text-white tabular-nums">
                    {formatCurrency(item.price, currency)}
                  </span>

                  <div className="flex items-center gap-2">
                    {!soldOut && (
                      <button
                        type="button"
                        onClick={() => setCustomizingItem(item)}
                        className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-2 text-xs font-medium text-slate-300 hover:bg-white/10 cursor-pointer"
                      >
                        Customize
                      </button>
                    )}
                    <button
                      type="button"
                      disabled={soldOut}
                      onClick={() => addToCart(item)}
                      className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                        soldOut
                          ? 'bg-white/5 text-slate-500 cursor-not-allowed'
                          : 'bg-violet-600 text-white hover:bg-violet-500'
                      }`}
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>{soldOut ? 'Sold Out' : 'Add'}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Customization Modal */}
      {customizingItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="customize-dish-title"
        >
          <div className="w-full max-w-md rounded-2xl glass-elevated border border-white/15 p-6 space-y-4">
            <h3 id="customize-dish-title" className="font-display text-lg font-bold text-white">
              Customize {customizingItem.name}
            </h3>
            {customizingItem.customization_options?.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-xs text-slate-400">Quick Options:</p>
                <div className="flex flex-wrap gap-2">
                  {customizingItem.customization_options.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() =>
                        setCustomNote((prev) => (prev ? `${prev}, ${opt}` : opt))
                      }
                      className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-slate-200 hover:bg-violet-600/30 cursor-pointer"
                    >
                      + {opt}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <div className="space-y-1.5">
              <label htmlFor="custom-prep-notes" className="text-xs font-medium text-slate-300">Preparation Instructions</label>
              <input
                id="custom-prep-notes"
                type="text"
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                placeholder="e.g., Less oil, extra chutney"
                className="w-full rounded-lg border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:border-violet-500 focus:outline-none"
              />
            </div>
            <div className="space-y-1.5">
              <label htmlFor="custom-allergy-notes" className="text-xs font-medium text-slate-300">Allergies / Exclusions</label>
              <input
                id="custom-allergy-notes"
                type="text"
                value={allergyNote}
                onChange={(e) => setAllergyNote(e.target.value)}
                placeholder="e.g., Peanut allergy, no dairy"
                className="w-full rounded-lg border border-white/10 bg-[#070913] px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setCustomizingItem(null)}
                className="rounded-lg border border-white/10 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-white/5 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmCustomize}
                className="rounded-lg bg-violet-600 px-4 py-2 text-xs font-semibold text-white hover:bg-violet-500 cursor-pointer"
              >
                Add to Pre-Order
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
