# SpiceStack — TableTurn

**Reserve Smart. Arrive Hungry. Eat Without Waiting.**

SpiceStack — TableTurn is a full-stack restaurant reservation, advance meal pre-ordering, and **Arrival-Synchronized Kitchen Display System (KDS)** platform. Built for synchronized hospitality operations across Customers, Hostesses/Floor Staff, Kitchen Chefs, and Restaurant Managers, it eliminates wait times after arrival while optimizing table occupancy and kitchen throughput.

---

## Architecture & Tech Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, React Router DOM, Recharts, Lucide Icons, QRCode.react, Socket.IO Client (`AbortController` timeouts, bounded safe-`GET` retries, and `Idempotency-Key` headers on booking mutations)
- **Backend**: Node.js, Express (`backend/app.ts` + `server.ts`), Socket.IO (real-time bidirectional sync + polling fallback), Multer (image upload MIME/extension filtering), Zod (`.strict()` request/query/param validation), Pino structured logging with secret/token redaction, bounded LRU/TTL sliding-window rate limiting, and bounded `Idempotency-Key` replay cache
- **Database**: SQLite (`better-sqlite3` in WAL mode with `busy_timeout = 5000`, `synchronous = NORMAL`, `foreign_keys = ON`, non-negative stock triggers/checks, `IMMEDIATE` transaction locking, and performance indexes)
- **Authentication & RBAC**: HMAC-SHA256 signed expiring bearer tokens (`timingSafeEqual`, `iss`/`iat`/`exp` verification), salted `scrypt` password hashing, strict role-based endpoint enforcement (`customer`, `hostess`, `kitchen`, `manager`), and strict production `AUTH_SECRET` + environment-aware demo authentication controls
- **Automated Testing**: Vitest + Supertest (`tests/billing.test.ts`, `tests/kitchenEngine.test.ts`, `tests/securityAndAuth.test.ts`, `tests/api.integration.test.ts`) running against an isolated temporary SQLite database via `DB_PATH`

### Key Directories & Files

- `server.ts` & `backend/app.ts` — Express + Socket.IO server entry point with graceful `SIGINT`/`SIGTERM` shutdown, security headers, CORS, centralized error handler, and Vite dev/production serving
- `backend/utils/logger.ts` — Structured Pino JSON logger with automatic redaction for tokens, passwords, secrets, and authorization headers
- `backend/database/db.ts` — SQLite schema initialization, foreign keys, integrity checks/triggers, health probe (`checkDatabaseHealth`), clean shutdown (`closeDatabase`), and query indexes
- `backend/database/seed.ts` — Seeds 8 initial dining tables, 6 categories, 28 Indian & Continental dishes, simulated service clock (`19:25`), and 14 days of timestamped historical reservations
- `backend/validation/schemas.ts` — Strict Zod schemas for auth, reservations, tables, menu, categories, inventory, kitchen tickets, settings, clock controls, billing/split-bill, and query/param validation
- `backend/services/kitchenEngine.ts` — Arrival-Synchronized Kitchen Engine (`TargetPrepStart = ArrivalTime - PrepTime`), midnight boundary support, opening-hours checks, automatic Urgent priority escalation, optimal table auto-allocation, overlap conflict detection, and stock restoration
- `backend/routes/api.ts` — REST API (`/api/health/*`, `/api/auth/*`, `/api/tables`, `/api/menu`, `/api/billing/*`, `/api/reservations/*`, `/api/staff/*`, `/api/kitchen/*`, `/api/admin/*`)
- `src/utils/billing.ts` — Shared client/server currency rounding, finite-number guards, discounts, GST/Service Charge calculation, and remainder-safe equal/itemized split-bill logic
- `src/pages/*` — Customer flows (`/`, `/menu`, `/reserve`, `/my-reservations`), Hostess Portal (`/staff`), Full-Screen Kitchen Display (`/kitchen`), and Manager Admin Suite (`/admin`, `/admin/tables`, `/admin/menu`, `/admin/inventory`, `/admin/settings`)

---

## Quick Start & Commands

1. **Install dependencies**
   ```bash
   npm install
   ```
2. **Run development server** (port `3000`)
   ```bash
   npm run dev
   ```
3. **Run automated unit, security & API integration tests**
   ```bash
   npm test
   ```
4. **Lint, Type-check & Build for production**
   ```bash
   npm run lint
   npm run typecheck
   npm run build
   ```
5. **Run in Production**
   `AUTH_SECRET` (at least 32 random characters, non-placeholder) is **required** when `NODE_ENV=production`; startup fails cleanly if missing or weak:
   ```bash
   NODE_ENV=production AUTH_SECRET="$(openssl rand -hex 32)" npm start
   ```
   Optional hackathon demo mode in production: set `HACKATHON_DEMO_MODE=true` (or `ALLOW_DEMO_AUTH=true`). By default, quick-switch demo login is disabled in `NODE_ENV=production`.

---

## Demo Roles, Simulated Integrations & Health Probes

- **Health & Readiness Endpoints**: `GET /api/health`, `GET /api/health/live`, `GET /api/health/ready` return sanitized database connectivity and readiness status without exposing internal paths or secrets.
- **Simulated SMS & Calendar Links**: Booking confirmations generate simulated SMS notification records (`sms_logs` tagged `[SIMULATED SMS]`) and Google Calendar event template URLs rather than dispatching live carrier SMS messages.
- **Demo Roles & Live Clock Walkthrough** (in development, test, or when `HACKATHON_DEMO_MODE=true`):
  - **Customer** (`Aarav Sharma`) — Browse menu, add pre-orders, reserve `Table 4` at `8:00 PM` (or use Auto-Assign), view QR Pass & Split Bill, track live cooking progress, modify/cancel bookings.
  - **Hostess** (`Elena Vance`, `/staff`) — Monitor floor turn-time estimates, search guests, adjust arrival times (`+15m Late`), cancel bookings, or click **GUEST ARRIVED — CHECK IN** to immediately promote pending tickets to `Urgent`.
  - **Kitchen Chef** (`Chef Vikram Rao`, `/kitchen`) — Full-screen Arrival-Synchronized KDS showing `TargetPrepStart`, live countdowns, allergy callouts, automatic `"FIRE DISH NOW"` alerts when the simulated clock advances to `7:40 PM` (`19:40`), and `Start Cooking` / `Mark Ready` / `Mark Served` actions.
  - **Manager** (`Maya Krishnan`, `/admin`) — Manage dynamic tables (`/admin/tables`), menu & categories (`/admin/menu`), stock inventory (`/admin/inventory`), tax/duration settings (`/admin/settings`), and timestamp-driven analytics (`/admin`).
