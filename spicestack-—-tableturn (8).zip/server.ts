import express from 'express';
import http from 'http';
import path from 'path';
import { Server as SocketIOServer } from 'socket.io';
import { createServer as createViteServer } from 'vite';
import { closeDatabase, initializeDatabase } from './backend/database/db.ts';
import { seedDatabaseIfEmpty } from './backend/database/seed.ts';
import { createApp } from './backend/app.ts';
import { isDemoAuthEnabled } from './backend/middleware/auth.ts';
import { logger } from './backend/utils/logger.ts';

async function startServer() {
  initializeDatabase();
  seedDatabaseIfEmpty();

  const httpServer = http.createServer();
  const allowedOrigin = process.env.APP_URL || true;
  const io = new SocketIOServer(httpServer, {
    cors: { origin: allowedOrigin, credentials: true },
  });

  const app = createApp(io, { enableSpaFallback: false });

  io.on('connection', (socket) => {
    socket.emit('connected', { status: 'synced' });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.on('request', app);

  const PORT = Number(process.env.PORT || 3000);
  httpServer.listen(PORT, '0.0.0.0', () => {
    logger.info(
      {
        port: PORT,
        nodeEnv: process.env.NODE_ENV || 'development',
        demoAuthEnabled: isDemoAuthEnabled(),
      },
      'SpiceStack — TableTurn server started'
    );
  });

  let shuttingDown = false;
  const shutdown = (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info({ signal }, 'Graceful shutdown initiated');

    const forceTimer = setTimeout(() => {
      logger.warn('Force closing after shutdown timeout');
      closeDatabase();
      process.exit(0);
    }, 5000);
    forceTimer.unref();

    io.close(() => {
      httpServer.close(() => {
        closeDatabase();
        process.exit(0);
      });
    });
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

startServer().catch((err) => {
  logger.fatal({ err }, 'Failed to start server');
  closeDatabase();
  process.exit(1);
});
