import crypto from 'crypto';
import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import type { Server as SocketIOServer } from 'socket.io';
import { checkDatabaseHealth, db } from '../database/db.ts';
import {
  attachUser,
  hashPassword,
  isDemoAuthEnabled,
  requireRole,
  signToken,
  verifyPassword,
  type AuthRequest,
} from '../middleware/auth.ts';
import { createRateLimiter, idempotencyMiddleware } from '../middleware/security.ts';
import { logger } from '../utils/logger.ts';
import {
  addDaysToDate,
  allocateBestTable,
  calculateTargetPrepStart,
  computeTicketRuntime,
  deriveCustomerOrderStage,
  formatDisplay12h,
  formatLocalDate,
  formatLocalTimeHHMM,
  getClockState,
  getSettings,
  getTablesWithAvailability,
  isWithinOpeningHours,
  minutesToHHMM,
  restoreStockForReservation,
  timeToMinutes,
} from '../services/kitchenEngine.ts';
import {
  analyticsQuerySchema,
  billCalculationSchema,
  clockUpdateSchema,
  createCategorySchema,
  createMenuItemSchema,
  createReservationSchema,
  createTableSchema,
  demoLoginSchema,
  idParamSchema,
  inventoryPatchSchema,
  kitchenTicketUpdateSchema,
  loginSchema,
  modifyReservationSchema,
  registerSchema,
  reservationsQuerySchema,
  splitBillSchema,
  staffReservationUpdateSchema,
  tablesQuerySchema,
  updateCategorySchema,
  updateMenuItemSchema,
  updateSettingsSchema,
  updateTableSchema,
  uploadMetadataSchema,
} from '../validation/schemas.ts';
import {
  calculateEqualSplit,
  calculateItemizedSplit,
  calculateOrderBill,
} from '../../src/utils/billing.ts';
import type {
  AnalyticsOverview,
  KitchenTicket,
  MenuItem,
  PreOrder,
  Reservation,
  RestaurantTable,
  TicketStatus,
  User,
} from '../../src/types/index.ts';

class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

const VALID_TICKET_TRANSITIONS: Record<TicketStatus, TicketStatus[]> = {
  Pending: ['Cooking'],
  Cooking: ['Ready'],
  Ready: ['Served'],
  Served: [],
};

function parsePositiveId(raw: string, label = 'ID'): number {
  const parsed = idParamSchema.safeParse({ id: raw });
  if (!parsed.success) {
    throw new HttpError(400, `Invalid ${label}`);
  }
  return parsed.data.id;
}

const uploadsDir = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const ALLOWED_IMAGE_MIME_TO_EXT: Record<string, string> = {
  'image/jpeg': '.jpg',
  'image/jpg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/gif': '.gif',
};

const ALLOWED_IMAGE_EXTENSIONS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif']);

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const ext = ALLOWED_IMAGE_MIME_TO_EXT[file.mimetype.toLowerCase()] || '.jpg';
    cb(null, `dish-${Date.now()}-${crypto.randomBytes(4).toString('hex')}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const mimeOk = Boolean(ALLOWED_IMAGE_MIME_TO_EXT[file.mimetype.toLowerCase()]);
    const ext = path.extname(file.originalname || '').toLowerCase();
    const extOk = !ext || ALLOWED_IMAGE_EXTENSIONS.has(ext);
    if (!mimeOk || !extOk) {
      cb(new HttpError(400, 'Only JPEG, PNG, WebP, and GIF image files are allowed'));
      return;
    }
    cb(null, true);
  },
});

interface DbUserRow extends User {
  password_hash: string;
}

export function createApiRouter(io?: SocketIOServer): express.Router {
  const router = express.Router();
  router.use(attachUser);

  // ==================== HEALTH & READINESS PROBES ====================
  router.get('/health/live', (_req, res) => {
    res.json({
      status: 'alive',
      timestamp: new Date().toISOString(),
    });
  });

  const handleReadiness = (_req: express.Request, res: express.Response) => {
    const dbHealth = checkDatabaseHealth();
    const ready = dbHealth.connected && dbHealth.tablesReady;
    const status = ready ? 200 : 503;
    res.status(status).json({
      status: ready ? 'ok' : 'unavailable',
      liveness: 'up',
      readiness: ready ? 'ready' : 'not_ready',
      database: dbHealth.connected ? (dbHealth.tablesReady ? 'connected' : 'initializing') : 'disconnected',
      demoAuthEnabled: isDemoAuthEnabled(),
      timestamp: new Date().toISOString(),
    });
  };

  router.get('/health', handleReadiness);
  router.get('/health/ready', handleReadiness);

  const authRateLimiter = createRateLimiter({
    windowMs: 60_000,
    max: Number(process.env.RATE_LIMIT_AUTH_MAX || 25),
    keyPrefix: 'auth',
    message: 'Too many authentication attempts. Please wait a minute and try again.',
  });

  const bookingRateLimiter = createRateLimiter({
    windowMs: 60_000,
    max: Number(process.env.RATE_LIMIT_BOOKING_MAX || 30),
    keyPrefix: 'booking',
    message: 'Too many reservation requests. Please wait a moment before trying again.',
  });

  const adminRateLimiter = createRateLimiter({
    windowMs: 60_000,
    max: Number(process.env.RATE_LIMIT_ADMIN_MAX || 60),
    keyPrefix: 'admin',
    message: 'Too many administrative/operational requests. Please slow down briefly.',
  });

  const broadcastSync = (event: string, payload?: unknown) => {
    if (!io) return;
    io.emit(event, payload || {});
    io.emit('state:sync', { event, timestamp: Date.now() });
  };

  // ==================== AUTH, REGISTRATION & DEMO ROLES ====================
  router.get('/auth/demo-users', (_req, res) => {
    if (!isDemoAuthEnabled()) {
      res.json({ demoEnabled: false, users: [] });
      return;
    }
    const users = db
      .prepare(
        "SELECT id, name, email, role, phone FROM users WHERE role IN ('customer', 'hostess', 'kitchen', 'manager') ORDER BY id ASC LIMIT 4"
      )
      .all() as User[];
    res.json({ demoEnabled: true, users });
  });

  router.post('/auth/register', authRateLimiter, (req: AuthRequest, res) => {
    const { name, email, password, phone } = registerSchema.parse(req.body);

    const normalizedEmail = email.toLowerCase();
    const existing = db.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(normalizedEmail);
    if (existing) {
      logger.warn({ requestId: req.requestId, reason: 'duplicate_email' }, 'Registration rejected');
      res.status(409).json({ error: 'An account with this email already exists' });
      return;
    }

    // Security: Always force role = 'customer' on public registration
    const info = db
      .prepare('INSERT INTO users (name, email, password_hash, role, phone) VALUES (?, ?, ?, ?, ?)')
      .run(name, normalizedEmail, hashPassword(password), 'customer', phone || '');

    const user: User = {
      id: Number(info.lastInsertRowid),
      name,
      email: normalizedEmail,
      role: 'customer',
      phone: phone || '',
    };
    const token = signToken(user);
    logger.info({ requestId: req.requestId, userId: user.id, role: user.role }, 'User registered');
    res.status(201).json({ user, token });
  });

  router.post('/auth/login', authRateLimiter, (req: AuthRequest, res) => {
    const { email, password } = loginSchema.parse(req.body);

    const row = db
      .prepare('SELECT * FROM users WHERE LOWER(email) = ?')
      .get(email.toLowerCase()) as DbUserRow | undefined;

    if (!row || !verifyPassword(password, row.password_hash)) {
      logger.warn({ requestId: req.requestId, reason: 'invalid_credentials' }, 'Login failed');
      res.status(401).json({ error: 'Invalid email or password' });
      return;
    }

    const user: User = {
      id: row.id,
      name: row.name,
      email: row.email,
      role: row.role,
      phone: row.phone,
    };
    const token = signToken(user);
    logger.info({ requestId: req.requestId, userId: user.id, role: user.role }, 'User logged in');
    res.json({ user, token });
  });

  router.post('/auth/login-demo', authRateLimiter, (req: AuthRequest, res) => {
    if (!isDemoAuthEnabled()) {
      logger.warn({ requestId: req.requestId }, 'Blocked demo login attempt in restricted environment');
      res.status(403).json({
        error: 'Demo quick-switch login is disabled in production. Sign in with registered credentials.',
      });
      return;
    }

    const { role } = demoLoginSchema.parse(req.body);
    const user = db
      .prepare('SELECT id, name, email, role, phone FROM users WHERE role = ? ORDER BY id ASC LIMIT 1')
      .get(role) as User | undefined;
    if (!user) {
      res.status(404).json({ error: 'Demo role not found' });
      return;
    }
    const token = signToken(user);
    logger.info({ requestId: req.requestId, userId: user.id, role: user.role }, 'Demo workspace activated');
    res.json({ user, token });
  });

  router.get('/auth/me', (req: AuthRequest, res) => {
    res.json({ user: req.user || null, demoEnabled: isDemoAuthEnabled() });
  });

  // ==================== SETTINGS & SIMULATED CLOCK ====================
  router.get('/settings', (_req, res) => {
    res.json({ settings: getSettings(), clock: getClockState() });
  });

  router.put('/admin/settings', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const body = updateSettingsSchema.parse(req.body);
    db.prepare(`
      UPDATE restaurant_settings SET
        restaurant_name = COALESCE(?, restaurant_name),
        logo_url = COALESCE(?, logo_url),
        address = COALESCE(?, address),
        phone = COALESCE(?, phone),
        email = COALESCE(?, email),
        opening_hours = COALESCE(?, opening_hours),
        dining_duration = COALESCE(?, dining_duration),
        gst_percentage = COALESCE(?, gst_percentage),
        service_charge_percentage = COALESCE(?, service_charge_percentage),
        currency = COALESCE(?, currency),
        slot_interval_minutes = COALESCE(?, slot_interval_minutes),
        max_advance_days = COALESCE(?, max_advance_days)
      WHERE id = 1
    `).run(
      body.restaurant_name ?? null,
      body.logo_url ?? null,
      body.address ?? null,
      body.phone ?? null,
      body.email ?? null,
      body.opening_hours ?? null,
      body.dining_duration ?? null,
      body.gst_percentage ?? null,
      body.service_charge_percentage ?? null,
      body.currency ?? null,
      body.slot_interval_minutes ?? null,
      body.max_advance_days ?? null
    );
    const settings = getSettings();
    broadcastSync('settings:updated', settings);
    res.json({ settings });
  });

  router.get('/clock', (_req, res) => {
    res.json({ clock: getClockState() });
  });

  router.post('/clock', adminRateLimiter, (req: AuthRequest, res) => {
    if (!isDemoAuthEnabled()) {
      if (!req.user) {
        res.status(401).json({ error: 'Authentication required to adjust service clock.' });
        return;
      }
      if (!['hostess', 'kitchen', 'manager'].includes(req.user.role)) {
        res.status(403).json({ error: 'Staff or manager privileges required to adjust service clock.' });
        return;
      }
    }

    const { mode, time, date, advanceMinutes } = clockUpdateSchema.parse(req.body);
    const current = getClockState();

    if (mode === 'live') {
      db.prepare("UPDATE restaurant_settings SET clock_mode = 'live' WHERE id = 1").run();
    } else if (typeof advanceMinutes === 'number') {
      const base = new Date(current.current_iso);
      const next = new Date(base.getTime() + advanceMinutes * 60_000);
      const nextIso = `${formatLocalDate(next)}T${formatLocalTimeHHMM(next)}:00`;
      db.prepare("UPDATE restaurant_settings SET clock_mode = 'simulated', simulated_time = ? WHERE id = 1").run(nextIso);
    } else if (time) {
      const targetDate = date || current.current_date;
      const nextIso = `${targetDate}T${time}:00`;
      db.prepare("UPDATE restaurant_settings SET clock_mode = 'simulated', simulated_time = ? WHERE id = 1").run(nextIso);
    }

    const updatedClock = getClockState();
    broadcastSync('clock:updated', updatedClock);
    res.json({ clock: updatedClock });
  });

  // ==================== BILLING CALCULATOR & SPLIT-BILL API ====================
  router.post('/billing/calculate', (req, res) => {
    const body = billCalculationSchema.parse(req.body);
    const settings = getSettings();
    const gstPct = body.gst_percentage ?? settings.gst_percentage;
    const svcPct = body.service_charge_percentage ?? settings.service_charge_percentage;
    const summary = calculateOrderBill(
      body.items,
      gstPct,
      svcPct,
      body.discount_percentage,
      body.discount_amount
    );
    res.json({
      bill: summary,
      rates: {
        gst_percentage: gstPct,
        service_charge_percentage: svcPct,
        currency: settings.currency,
      },
    });
  });

  router.post('/billing/split', (req, res) => {
    const body = splitBillSchema.parse(req.body);
    const settings = getSettings();
    if (body.mode === 'equal') {
      const equal = calculateEqualSplit(body.total_amount ?? 0, body.diners ?? 1);
      res.json({ mode: 'equal', equal });
      return;
    }
    const gstPct = body.gst_percentage ?? settings.gst_percentage;
    const svcPct = body.service_charge_percentage ?? settings.service_charge_percentage;
    const itemized = calculateItemizedSplit(
      body.items ?? [],
      body.selected_item_ids ?? [],
      gstPct,
      svcPct,
      body.total_amount
    );
    res.json({ mode: 'itemized', itemized });
  });

  // ==================== UPLOAD IMAGE ====================
  router.post('/upload', adminRateLimiter, requireRole(['manager']), upload.single('image'), (req, res) => {
    uploadMetadataSchema.parse(req.body || {});
    if (!req.file) {
      res.status(400).json({ error: 'No image file provided' });
      return;
    }
    res.json({ url: `/uploads/${req.file.filename}` });
  });

  // ==================== TABLES ====================
  router.get('/tables', (req, res) => {
    const { date, time, partySize } = tablesQuerySchema.parse(req.query);
    const tables = getTablesWithAvailability(date, time, partySize);
    res.json({ tables });
  });

  router.post('/admin/tables', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const { table_number, capacity, type, section, description, status } = createTableSchema.parse(req.body);
    try {
      const existingCount = (db.prepare('SELECT COUNT(*) as c FROM tables').get() as { c: number }).c;
      const pos_x = (existingCount % 4) + 1;
      const pos_y = Math.floor(existingCount / 4) + 1;
      const info = db
        .prepare(`
          INSERT INTO tables (table_number, capacity, type, section, description, status, is_active, pos_x, pos_y)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          table_number,
          capacity,
          type,
          section,
          description,
          status,
          status === 'Disabled' ? 0 : 1,
          pos_x,
          pos_y
        );
      const table = db.prepare('SELECT * FROM tables WHERE id = ?').get(info.lastInsertRowid) as RestaurantTable;
      broadcastSync('tables:updated', table);
      res.status(201).json({ table });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to create table';
      res.status(400).json({ error: msg.includes('UNIQUE') ? 'Table number already exists' : 'Failed to create table' });
    }
  });

  router.put('/admin/tables/:id', adminRateLimiter, requireRole(['manager', 'hostess']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'table ID');
    const body = updateTableSchema.parse(req.body);
    const existing = db.prepare('SELECT * FROM tables WHERE id = ?').get(id) as RestaurantTable | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Table not found' });
      return;
    }

    if ((req as AuthRequest).user?.role === 'hostess') {
      db.prepare('UPDATE tables SET status = COALESCE(?, status) WHERE id = ?').run(body.status ?? null, id);
    } else {
      const nextIsActive =
        typeof body.is_active === 'number'
          ? body.is_active
          : body.status === 'Disabled'
            ? 0
            : body.status
              ? 1
              : existing.is_active;

      const nextStatus =
        body.status ?? (nextIsActive === 0 ? 'Disabled' : existing.status === 'Disabled' ? 'Available' : existing.status);

      db.prepare(`
        UPDATE tables SET
          table_number = COALESCE(?, table_number),
          capacity = COALESCE(?, capacity),
          type = COALESCE(?, type),
          section = COALESCE(?, section),
          description = COALESCE(?, description),
          status = ?,
          is_active = ?
        WHERE id = ?
      `).run(
        body.table_number ?? null,
        body.capacity ?? null,
        body.type ?? null,
        body.section ?? null,
        body.description ?? null,
        nextStatus,
        nextIsActive,
        id
      );
    }

    const updated = db.prepare('SELECT * FROM tables WHERE id = ?').get(id) as RestaurantTable;
    broadcastSync('tables:updated', updated);
    res.json({ table: updated });
  });

  router.delete('/admin/tables/:id', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'table ID');
    const existing = db.prepare('SELECT id FROM tables WHERE id = ?').get(id);
    if (!existing) {
      res.status(404).json({ error: 'Table not found' });
      return;
    }
    const activeRes = db
      .prepare(
        `SELECT id, booking_code FROM reservations 
         WHERE table_id = ? AND status IN ('Confirmed', 'Checked In', 'Seated')`
      )
      .get(id) as { id: number; booking_code: string } | undefined;

    if (activeRes) {
      res.status(409).json({
        error: `Cannot delete table: active reservation ${activeRes.booking_code} is assigned to it. Reassign or complete that reservation first.`,
      });
      return;
    }

    db.prepare('DELETE FROM tables WHERE id = ?').run(id);
    broadcastSync('tables:updated', { deletedId: id });
    res.json({ success: true });
  });

  // ==================== CATEGORIES ====================
  router.get('/categories', (_req, res) => {
    const categories = db
      .prepare(`
        SELECT c.*, COUNT(CASE WHEN m.is_deleted = 0 THEN 1 END) as item_count
        FROM categories c
        LEFT JOIN menu_items m ON m.category_id = c.id
        GROUP BY c.id
        ORDER BY c.display_order ASC, c.id ASC
      `)
      .all();
    res.json({ categories });
  });

  router.post('/admin/categories', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const { name } = createCategorySchema.parse(req.body);
    const maxOrder = (db.prepare('SELECT COALESCE(MAX(display_order), 0) as m FROM categories').get() as { m: number }).m;
    try {
      const info = db.prepare('INSERT INTO categories (name, display_order) VALUES (?, ?)').run(name, maxOrder + 1);
      const category = db.prepare('SELECT * FROM categories WHERE id = ?').get(info.lastInsertRowid);
      broadcastSync('menu:updated', { category });
      res.status(201).json({ category });
    } catch {
      res.status(400).json({ error: 'Category already exists' });
    }
  });

  router.put('/admin/categories/:id', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'category ID');
    const { name, display_order } = updateCategorySchema.parse(req.body);
    const existing = db.prepare('SELECT id FROM categories WHERE id = ?').get(id);
    if (!existing) {
      res.status(404).json({ error: 'Category not found' });
      return;
    }
    db.prepare(
      'UPDATE categories SET name = COALESCE(?, name), display_order = COALESCE(?, display_order) WHERE id = ?'
    ).run(name ?? null, display_order ?? null, id);
    const category = db.prepare('SELECT * FROM categories WHERE id = ?').get(id);
    broadcastSync('menu:updated', { category });
    res.json({ category });
  });

  router.delete('/admin/categories/:id', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'category ID');
    const existing = db.prepare('SELECT id FROM categories WHERE id = ?').get(id);
    if (!existing) {
      res.status(404).json({ error: 'Category not found' });
      return;
    }
    const count = (
      db.prepare('SELECT COUNT(*) as c FROM menu_items WHERE category_id = ? AND is_deleted = 0').get(id) as { c: number }
    ).c;
    if (count > 0) {
      res.status(409).json({ error: `Cannot delete category with ${count} active menu items. Reassign items first.` });
      return;
    }
    db.prepare('DELETE FROM categories WHERE id = ?').run(id);
    broadcastSync('menu:updated', { deletedCategoryId: id });
    res.json({ success: true });
  });

  // ==================== MENU ITEMS & INVENTORY ====================
  router.get('/menu', (_req, res) => {
    const rows = db
      .prepare(`
        SELECT m.*, c.name as category_name
        FROM menu_items m
        JOIN categories c ON c.id = m.category_id
        WHERE m.is_deleted = 0
        ORDER BY c.display_order ASC, m.is_chef_special DESC, m.id ASC
      `)
      .all() as Array<MenuItem & { customization_options: string }>;

    const items: MenuItem[] = rows.map((r) => ({
      ...r,
      customization_options: (() => {
        try {
          return JSON.parse(r.customization_options || '[]');
        } catch {
          return [];
        }
      })(),
    }));
    res.json({ items });
  });

  router.post('/admin/menu', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const b = createMenuItemSchema.parse(req.body);
    const categoryExists = db.prepare('SELECT id FROM categories WHERE id = ?').get(b.category_id);
    if (!categoryExists) {
      res.status(400).json({ error: 'Selected category does not exist' });
      return;
    }

    const info = db
      .prepare(`
        INSERT INTO menu_items (
          name, description, image, price, category_id, dietary_type, spicy_level,
          preparation_time, is_chef_special, is_popular, allergy_info, customization_options,
          availability, stock_quantity, daily_limit, is_deleted
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
      `)
      .run(
        b.name,
        b.description,
        b.image || '/src/assets/images/dish_butter_chicken_1795006343077.jpg',
        b.price,
        b.category_id,
        b.dietary_type,
        b.spicy_level,
        b.preparation_time,
        b.is_chef_special ? 1 : 0,
        b.is_popular ? 1 : 0,
        b.allergy_info,
        JSON.stringify(b.customization_options),
        b.availability ? 1 : 0,
        b.stock_quantity,
        b.daily_limit
      );

    const created = db
      .prepare('SELECT m.*, c.name as category_name FROM menu_items m JOIN categories c ON c.id = m.category_id WHERE m.id = ?')
      .get(info.lastInsertRowid) as MenuItem & { customization_options: string };
    created.customization_options = JSON.parse((created.customization_options as unknown as string) || '[]');
    broadcastSync('menu:updated', created);
    res.status(201).json({ item: created });
  });

  router.put('/admin/menu/:id', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'menu item ID');
    const b = updateMenuItemSchema.parse(req.body);
    const existing = db.prepare('SELECT * FROM menu_items WHERE id = ? AND is_deleted = 0').get(id);
    if (!existing) {
      res.status(404).json({ error: 'Menu item not found' });
      return;
    }
    if (b.category_id !== undefined) {
      const cat = db.prepare('SELECT id FROM categories WHERE id = ?').get(b.category_id);
      if (!cat) {
        res.status(400).json({ error: 'Selected category does not exist' });
        return;
      }
    }

    db.prepare(`
      UPDATE menu_items SET
        name = COALESCE(?, name),
        description = COALESCE(?, description),
        image = COALESCE(?, image),
        price = COALESCE(?, price),
        category_id = COALESCE(?, category_id),
        dietary_type = COALESCE(?, dietary_type),
        spicy_level = COALESCE(?, spicy_level),
        preparation_time = COALESCE(?, preparation_time),
        is_chef_special = COALESCE(?, is_chef_special),
        is_popular = COALESCE(?, is_popular),
        allergy_info = COALESCE(?, allergy_info),
        customization_options = COALESCE(?, customization_options),
        availability = COALESCE(?, availability),
        stock_quantity = COALESCE(?, stock_quantity),
        daily_limit = COALESCE(?, daily_limit)
      WHERE id = ?
    `).run(
      b.name ?? null,
      b.description ?? null,
      b.image ?? null,
      b.price ?? null,
      b.category_id ?? null,
      b.dietary_type ?? null,
      b.spicy_level ?? null,
      b.preparation_time ?? null,
      b.is_chef_special !== undefined ? (b.is_chef_special ? 1 : 0) : null,
      b.is_popular !== undefined ? (b.is_popular ? 1 : 0) : null,
      b.allergy_info ?? null,
      b.customization_options !== undefined ? JSON.stringify(b.customization_options) : null,
      b.availability !== undefined ? (b.availability ? 1 : 0) : null,
      b.stock_quantity ?? null,
      b.daily_limit ?? null,
      id
    );

    const updated = db
      .prepare('SELECT m.*, c.name as category_name FROM menu_items m JOIN categories c ON c.id = m.category_id WHERE m.id = ?')
      .get(id) as MenuItem & { customization_options: string };
    updated.customization_options = JSON.parse((updated.customization_options as unknown as string) || '[]');
    broadcastSync('menu:updated', updated);
    res.json({ item: updated });
  });

  router.patch('/admin/inventory/:id', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'menu item ID');
    const b = inventoryPatchSchema.parse(req.body);
    const existing = db.prepare('SELECT * FROM menu_items WHERE id = ? AND is_deleted = 0').get(id) as MenuItem | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Menu item not found' });
      return;
    }

    const nextStock = b.stock_quantity ?? existing.stock_quantity;
    const nextAvail =
      b.availability !== undefined
        ? b.availability
          ? 1
          : 0
        : b.stock_quantity !== undefined
          ? nextStock > 0
            ? 1
            : 0
          : existing.availability;

    db.prepare(`
      UPDATE menu_items SET
        stock_quantity = ?,
        availability = ?,
        daily_limit = COALESCE(?, daily_limit)
      WHERE id = ?
    `).run(nextStock, nextAvail, b.daily_limit ?? null, id);

    const updated = db
      .prepare('SELECT m.*, c.name as category_name FROM menu_items m JOIN categories c ON c.id = m.category_id WHERE m.id = ?')
      .get(id) as MenuItem & { customization_options: string };
    updated.customization_options = JSON.parse((updated.customization_options as unknown as string) || '[]');
    broadcastSync('menu:updated', updated);
    res.json({ item: updated });
  });

  router.delete('/admin/menu/:id', adminRateLimiter, requireRole(['manager']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'menu item ID');
    const existing = db.prepare('SELECT id FROM menu_items WHERE id = ?').get(id);
    if (!existing) {
      res.status(404).json({ error: 'Menu item not found' });
      return;
    }
    db.prepare('UPDATE menu_items SET is_deleted = 1, availability = 0 WHERE id = ?').run(id);
    broadcastSync('menu:updated', { deletedId: id });
    res.json({ success: true });
  });

  // ==================== RESERVATIONS ====================
  function hydrateReservations(rows: Reservation[]): Reservation[] {
    const clock = getClockState();
    const getPreOrders = db.prepare('SELECT * FROM pre_orders WHERE reservation_id = ?');
    const getTickets = db.prepare('SELECT * FROM kitchen_tickets WHERE reservation_id = ?');

    return rows.map((r) => {
      const pre_orders = getPreOrders.all(r.id) as PreOrder[];
      const rawTickets = getTickets.all(r.id) as KitchenTicket[];
      const tickets = rawTickets.map((t) =>
        computeTicketRuntime(
          { ...t, reservation_date: r.date, arrival_time: r.arrival_time, reservation_status: r.status },
          clock
        )
      );
      return {
        ...r,
        pre_orders,
        tickets,
        customer_order_stage: deriveCustomerOrderStage(r, tickets),
      };
    });
  }

  router.get('/reservations', (req: AuthRequest, res) => {
    const parsedQuery = reservationsQuerySchema.parse(req.query);
    const date = parsedQuery.date ?? null;
    const code = parsedQuery.code ? parsedQuery.code.trim().toUpperCase() : null;
    const phone = parsedQuery.phone ? parsedQuery.phone.trim() : null;
    const search = parsedQuery.search ? parsedQuery.search.trim().toLowerCase() : null;
    const includeArchived = parsedQuery.includeArchived === 'true';

    const user = req.user;
    const isStaff = user && ['hostess', 'kitchen', 'manager'].includes(user.role);

    let query = `
      SELECT r.*, t.table_number, t.section as table_section, t.capacity as table_capacity
      FROM reservations r
      LEFT JOIN tables t ON t.id = r.table_id
    `;
    const params: unknown[] = [];
    const conditions: string[] = [];

    if (!isStaff) {
      if (code) {
        conditions.push('UPPER(r.booking_code) = ?');
        params.push(code);
        if (user) {
          conditions.push('(r.user_id = ? OR LOWER(r.email) = ? OR r.phone = ?)');
          params.push(user.id, user.email.toLowerCase(), user.phone);
        }
      } else if (user) {
        conditions.push('(r.user_id = ? OR LOWER(r.email) = ?)');
        params.push(user.id, user.email.toLowerCase());
        if (!includeArchived) {
          conditions.push('r.is_archived_by_customer = 0');
        }
      } else {
        res.json({ reservations: [], clock: getClockState() });
        return;
      }
    }

    if (date) {
      conditions.push('r.date = ?');
      params.push(date);
    }
    if (isStaff && code) {
      conditions.push('UPPER(r.booking_code) = ?');
      params.push(code);
    }
    if (isStaff && phone) {
      conditions.push('r.phone LIKE ?');
      params.push(`%${phone}%`);
    }
    if (search) {
      conditions.push(
        '(LOWER(r.customer_name) LIKE ? OR UPPER(r.booking_code) LIKE ? OR r.phone LIKE ? OR EXISTS (SELECT 1 FROM pre_orders po WHERE po.reservation_id = r.id AND LOWER(po.item_name_snapshot) LIKE ?))'
      );
      params.push(`%${search}%`, `%${search.toUpperCase()}%`, `%${search}%`, `%${search}%`);
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }
    query += ' ORDER BY r.date DESC, r.arrival_time ASC, r.id DESC';

    const rows = db.prepare(query).all(...params) as Reservation[];
    res.json({ reservations: hydrateReservations(rows), clock: getClockState() });
  });

  router.post('/reservations', bookingRateLimiter, idempotencyMiddleware(), (req: AuthRequest, res) => {
    const {
      customer_name,
      phone,
      email,
      date,
      arrival_time,
      party_size,
      table_id,
      auto_allocate,
      special_requests,
      items,
    } = createReservationSchema.parse(req.body);

    const settings = getSettings();
    const clock = getClockState();

    if (date < clock.current_date) {
      res.status(400).json({ error: 'Cannot reserve a date in the past' });
      return;
    }

    const maxDate = addDaysToDate(clock.current_date, settings.max_advance_days || 30);
    if (date > maxDate) {
      res.status(400).json({ error: `Reservations can only be made up to ${settings.max_advance_days} days in advance` });
      return;
    }

    if (!isWithinOpeningHours(arrival_time, settings.opening_hours)) {
      res.status(400).json({ error: `Selected arrival time must be within opening hours (${settings.opening_hours})` });
      return;
    }

    // Aggregate quantities per dish to guarantee stock checks handle duplicate dish entries cleanly
    const requestedTotals = new Map<number, number>();
    for (const item of items) {
      requestedTotals.set(item.menu_item_id, (requestedTotals.get(item.menu_item_id) || 0) + item.quantity);
    }

    const createBookingTx = db.transaction(() => {
      const duplicate = db
        .prepare(
          `SELECT id, booking_code FROM reservations
           WHERE date = ? AND arrival_time = ? AND phone = ?
             AND status IN ('Confirmed', 'Checked In', 'Seated')
           LIMIT 1`
        )
        .get(date, arrival_time, phone) as { id: number; booking_code: string } | undefined;

      if (duplicate) {
        throw new HttpError(
          409,
          `Duplicate reservation detected: ${duplicate.booking_code} is already active for ${phone} at ${formatDisplay12h(arrival_time)}`
        );
      }

      let chosenTable: RestaurantTable | undefined;

      if (auto_allocate) {
        chosenTable = allocateBestTable(date, arrival_time, party_size) || undefined;
        if (!chosenTable) {
          throw new HttpError(409, 'No suitable table is available for this party size and time slot');
        }
      } else {
        const availableTables = getTablesWithAvailability(date, arrival_time, party_size);
        chosenTable = availableTables.find((t) => t.id === Number(table_id));
        if (!chosenTable) {
          throw new HttpError(404, 'Selected table not found');
        }
        if (!chosenTable.is_available_for_slot) {
          throw new HttpError(409, chosenTable.conflict_reason || 'Selected table is no longer available for this slot');
        }
      }

      const resolvedItems: Array<{
        menuItem: MenuItem;
        quantity: number;
        customization_notes: string;
        allergy_notes: string;
      }> = [];

      const menuCache = new Map<number, MenuItem>();
      for (const [menuId, totalQty] of requestedTotals.entries()) {
        const menuItem = db
          .prepare('SELECT * FROM menu_items WHERE id = ? AND is_deleted = 0')
          .get(menuId) as MenuItem | undefined;
        if (!menuItem) {
          throw new HttpError(400, 'One or more selected dishes no longer exist');
        }
        if (menuItem.availability !== 1 || menuItem.stock_quantity <= 0) {
          throw new HttpError(409, `"${menuItem.name}" is currently Sold Out`);
        }
        if (menuItem.stock_quantity < totalQty) {
          throw new HttpError(409, `Only ${menuItem.stock_quantity} left for "${menuItem.name}"`);
        }
        menuCache.set(menuId, menuItem);
      }

      for (const reqItem of items) {
        const menuItem = menuCache.get(reqItem.menu_item_id)!;
        resolvedItems.push({
          menuItem,
          quantity: reqItem.quantity,
          customization_notes: reqItem.customization_notes || '',
          allergy_notes: reqItem.allergy_notes || '',
        });
      }

      const bill = calculateOrderBill(
        resolvedItems.map((entry) => ({ price: entry.menuItem.price, quantity: entry.quantity })),
        settings.gst_percentage,
        settings.service_charge_percentage
      );

      let bookingCode = `SS-${crypto.randomInt(1000, 9999)}`;
      while (db.prepare('SELECT 1 FROM reservations WHERE booking_code = ?').get(bookingCode)) {
        bookingCode = `SS-${crypto.randomInt(10000, 99999)}`;
      }

      const resInfo = db
        .prepare(`
          INSERT INTO reservations (
            booking_code, user_id, customer_name, phone, email, date, arrival_time, party_size, table_id,
            status, special_requests, subtotal, gst_amount, service_charge_amount, total_amount
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Confirmed', ?, ?, ?, ?, ?)
        `)
        .run(
          bookingCode,
          req.user?.id ?? null,
          customer_name,
          phone,
          (email || req.user?.email || '').trim(),
          date,
          arrival_time,
          party_size,
          chosenTable.id,
          special_requests || '',
          bill.subtotal,
          bill.gstAmount,
          bill.serviceChargeAmount,
          bill.totalAmount
        );

      const reservationId = Number(resInfo.lastInsertRowid);

      if (date === clock.current_date && chosenTable.status === 'Available') {
        db.prepare("UPDATE tables SET status = 'Reserved' WHERE id = ?").run(chosenTable.id);
      }

      const insertPO = db.prepare(`
        INSERT INTO pre_orders (
          reservation_id, menu_item_id, item_name_snapshot, price_snapshot, prep_time_snapshot,
          quantity, customization_notes, allergy_notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);

      const insertTicket = db.prepare(`
        INSERT OR IGNORE INTO kitchen_tickets (
          reservation_id, pre_order_id, item_name, quantity, table_number, booking_code,
          target_prep_start, preparation_time, status, priority, allergies, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', 'Normal', ?, ?)
      `);

      const updateStock = db.prepare(`
        UPDATE menu_items SET
          stock_quantity = stock_quantity - ?,
          availability = CASE WHEN stock_quantity - ? <= 0 THEN 0 ELSE availability END
        WHERE id = ? AND stock_quantity >= ?
      `);

      for (const entry of resolvedItems) {
        const stockUpdate = updateStock.run(entry.quantity, entry.quantity, entry.menuItem.id, entry.quantity);
        if (stockUpdate.changes !== 1) {
          throw new HttpError(409, `Insufficient stock for "${entry.menuItem.name}"`);
        }

        const poInfo = insertPO.run(
          reservationId,
          entry.menuItem.id,
          entry.menuItem.name,
          entry.menuItem.price,
          entry.menuItem.preparation_time,
          entry.quantity,
          entry.customization_notes,
          entry.allergy_notes
        );
        const poId = Number(poInfo.lastInsertRowid);
        const targetPrepStart = calculateTargetPrepStart(date, arrival_time, entry.menuItem.preparation_time);

        insertTicket.run(
          reservationId,
          poId,
          entry.menuItem.name,
          entry.quantity,
          chosenTable.table_number,
          bookingCode,
          targetPrepStart,
          entry.menuItem.preparation_time,
          entry.allergy_notes || entry.menuItem.allergy_info,
          entry.customization_notes
        );
      }

      const startCal = `${date.replace(/-/g, '')}T${arrival_time.replace(':', '')}00`;
      const endMin = timeToMinutes(arrival_time) + settings.dining_duration;
      const endCal = `${date.replace(/-/g, '')}T${minutesToHHMM(endMin).replace(':', '')}00`;
      const calendarLink = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(
        `${settings.restaurant_name} Reservation (${bookingCode})`
      )}&dates=${startCal}/${endCal}&details=${encodeURIComponent(
        `Table: ${chosenTable.table_number} | Party: ${party_size} | Pre-ordered items: ${resolvedItems.length}`
      )}`;

      const smsMessage = `[SIMULATED SMS] SpiceStack TableTurn: Confirmed for ${customer_name} (${party_size} guests) on ${date} at ${formatDisplay12h(
        arrival_time
      )}. Assigned: ${chosenTable.table_number}. Booking ID: ${bookingCode}.`;

      db.prepare(
        'INSERT INTO sms_logs (reservation_id, phone, message, calendar_link) VALUES (?, ?, ?, ?)'
      ).run(reservationId, phone, smsMessage, calendarLink);

      return reservationId;
    });

    try {
      const reservationId = createBookingTx.immediate();
      const row = db
        .prepare(
          `SELECT r.*, t.table_number, t.section as table_section, t.capacity as table_capacity
           FROM reservations r LEFT JOIN tables t ON t.id = r.table_id WHERE r.id = ?`
        )
        .get(reservationId) as Reservation;
      const [hydrated] = hydrateReservations([row]);
      const smsLog = db.prepare('SELECT * FROM sms_logs WHERE reservation_id = ?').get(reservationId);
      broadcastSync('reservation:created', hydrated);
      res.status(201).json({ reservation: hydrated, smsLog });
    } catch (err: unknown) {
      if (err instanceof HttpError) {
        res.status(err.status).json({ error: err.message });
        return;
      }
      res.status(409).json({ error: err instanceof Error ? err.message : 'Booking conflict' });
    }
  });

  // Customer or Staff: Modify reservation arrival time / party size / requests
  router.patch('/reservations/:id', bookingRateLimiter, (req: AuthRequest, res) => {
    const id = parsePositiveId(req.params.id, 'reservation ID');
    const { arrival_time, party_size, special_requests } = modifyReservationSchema.parse(req.body);
    const settings = getSettings();

    if (arrival_time && !isWithinOpeningHours(arrival_time, settings.opening_hours)) {
      res.status(400).json({ error: `Arrival time must be within opening hours (${settings.opening_hours})` });
      return;
    }

    const existing = db.prepare('SELECT * FROM reservations WHERE id = ?').get(id) as Reservation | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Reservation not found' });
      return;
    }

    const user = req.user;
    const isStaff = user && ['hostess', 'manager'].includes(user.role);
    const isOwner =
      user &&
      (existing.user_id === user.id || existing.email.toLowerCase() === user.email.toLowerCase());

    if (!isStaff && !isOwner) {
      res.status(403).json({ error: 'You do not have permission to modify this reservation' });
      return;
    }

    if (existing.status !== 'Confirmed') {
      res.status(400).json({ error: 'Only Confirmed reservations can be modified' });
      return;
    }

    try {
      db.transaction(() => {
        const nextTime = arrival_time || existing.arrival_time;
        const nextParty = party_size ?? existing.party_size;
        let nextTableId = existing.table_id;

        if (nextTime !== existing.arrival_time || nextParty !== existing.party_size) {
          const available = getTablesWithAvailability(existing.date, nextTime, nextParty, existing.id);
          const currentFits = available.find((t) => t.id === existing.table_id && t.is_available_for_slot);
          if (!currentFits) {
            const replacement = allocateBestTable(existing.date, nextTime, nextParty, existing.id);
            if (!replacement) {
              throw new Error('No available table fits the modified time or party size');
            }
            nextTableId = replacement.id;
            db.prepare('UPDATE kitchen_tickets SET table_number = ? WHERE reservation_id = ?').run(
              replacement.table_number,
              id
            );
          }
        }

        db.prepare(`
          UPDATE reservations SET
            arrival_time = ?,
            party_size = ?,
            table_id = ?,
            special_requests = COALESCE(?, special_requests)
          WHERE id = ?
        `).run(nextTime, nextParty, nextTableId, special_requests ?? null, id);

        if (nextTime !== existing.arrival_time) {
          const pendingTickets = db
            .prepare("SELECT * FROM kitchen_tickets WHERE reservation_id = ? AND status = 'Pending'")
            .all(id) as KitchenTicket[];
          const updateTicket = db.prepare('UPDATE kitchen_tickets SET target_prep_start = ? WHERE id = ?');
          for (const t of pendingTickets) {
            updateTicket.run(calculateTargetPrepStart(existing.date, nextTime, t.preparation_time), t.id);
          }
        }
      }).immediate();

      broadcastSync('reservation:updated', { reservationId: id });
      const updated = db
        .prepare(
          `SELECT r.*, t.table_number, t.section as table_section, t.capacity as table_capacity
           FROM reservations r LEFT JOIN tables t ON t.id = r.table_id WHERE r.id = ?`
        )
        .get(id) as Reservation;
      res.json({ reservation: hydrateReservations([updated])[0] });
    } catch (err: unknown) {
      res.status(409).json({ error: err instanceof Error ? err.message : 'Unable to modify reservation' });
    }
  });

  // Safe Reservation Cancellation + Inventory Restoration
  router.post('/reservations/:id/cancel', bookingRateLimiter, idempotencyMiddleware(), (req: AuthRequest, res) => {
    const id = parsePositiveId(req.params.id, 'reservation ID');
    const existing = db.prepare('SELECT * FROM reservations WHERE id = ?').get(id) as Reservation | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Reservation not found' });
      return;
    }

    const user = req.user;
    const isStaff = user && ['hostess', 'manager'].includes(user.role);
    const isOwner =
      user &&
      (existing.user_id === user.id || existing.email.toLowerCase() === user.email.toLowerCase());

    if (!isStaff && !isOwner) {
      res.status(403).json({ error: 'You do not have permission to cancel this reservation' });
      return;
    }

    if (existing.status === 'Completed' || existing.status === 'Cancelled' || existing.status === 'No Show') {
      res.status(400).json({ error: `Reservation is already ${existing.status}` });
      return;
    }

    db.transaction(() => {
      db.prepare("UPDATE reservations SET status = 'Cancelled' WHERE id = ?").run(id);
      restoreStockForReservation(id);

      if (existing.table_id) {
        const otherActive = db
          .prepare(
            "SELECT id FROM reservations WHERE table_id = ? AND id != ? AND status IN ('Checked In', 'Seated')"
          )
          .get(existing.table_id, id);
        if (!otherActive) {
          db.prepare("UPDATE tables SET status = 'Available' WHERE id = ? AND status IN ('Reserved', 'Occupied')").run(
            existing.table_id
          );
        }
      }
    }).immediate();

    broadcastSync('reservation:updated', { reservationId: id, cancelled: true });
    res.json({ success: true });
  });

  // Customer: Clear past completed/cancelled order history from personal view
  router.post('/reservations/clear-history', (req: AuthRequest, res) => {
    const user = req.user;
    if (!user) {
      res.status(401).json({ error: 'Sign in required' });
      return;
    }
    db.prepare(`
      UPDATE reservations
      SET is_archived_by_customer = 1
      WHERE (user_id = ? OR LOWER(email) = ?)
        AND status IN ('Completed', 'Cancelled', 'No Show')
    `).run(user.id, user.email.toLowerCase());

    res.json({ success: true });
  });

  // Hostess Check-In (GUEST ARRIVED — CHECK IN)
  router.post('/staff/reservations/:id/check-in', adminRateLimiter, requireRole(['hostess', 'manager']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'reservation ID');
    const clock = getClockState();
    const resRow = db.prepare('SELECT * FROM reservations WHERE id = ?').get(id) as Reservation | undefined;
    if (!resRow) {
      res.status(404).json({ error: 'Reservation not found' });
      return;
    }
    if (resRow.status === 'Cancelled' || resRow.status === 'Completed' || resRow.status === 'No Show') {
      res.status(409).json({ error: `Cannot check in a ${resRow.status} reservation` });
      return;
    }

    db.transaction(() => {
      db.prepare("UPDATE reservations SET status = 'Checked In', checked_in_at = COALESCE(checked_in_at, ?) WHERE id = ?").run(
        clock.current_iso,
        id
      );
      if (resRow.table_id) {
        db.prepare("UPDATE tables SET status = 'Occupied' WHERE id = ?").run(resRow.table_id);
      }
      db.prepare(`
        UPDATE kitchen_tickets SET
          priority = 'Urgent',
          target_prep_start = ?
        WHERE reservation_id = ? AND status = 'Pending'
      `).run(clock.current_iso, id);
    }).immediate();

    broadcastSync('reservation:checked_in', { reservationId: id });
    res.json({ success: true });
  });

  // Hostess Seat / Complete / Update arrival time / Reassign Table
  router.patch('/staff/reservations/:id', adminRateLimiter, requireRole(['hostess', 'manager']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'reservation ID');
    const { status, arrival_time, table_id } = staffReservationUpdateSchema.parse(req.body);
    const settings = getSettings();
    const clock = getClockState();

    if (arrival_time && !isWithinOpeningHours(arrival_time, settings.opening_hours)) {
      res.status(400).json({ error: `Arrival time must be within opening hours (${settings.opening_hours})` });
      return;
    }

    const resRow = db.prepare('SELECT * FROM reservations WHERE id = ?').get(id) as Reservation | undefined;
    if (!resRow) {
      res.status(404).json({ error: 'Reservation not found' });
      return;
    }

    if (resRow.status === 'Cancelled' || resRow.status === 'Completed' || resRow.status === 'No Show') {
      res.status(409).json({ error: `Cannot modify a ${resRow.status} reservation` });
      return;
    }

    try {
      db.transaction(() => {
        if (status) {
          if (status === 'Seated') {
            db.prepare("UPDATE reservations SET status = 'Seated', seated_at = COALESCE(seated_at, ?) WHERE id = ?").run(
              clock.current_iso,
              id
            );
            if (resRow.table_id) db.prepare("UPDATE tables SET status = 'Occupied' WHERE id = ?").run(resRow.table_id);
          } else if (status === 'Completed') {
            db.prepare("UPDATE reservations SET status = 'Completed', completed_at = ? WHERE id = ?").run(
              clock.current_iso,
              id
            );
            if (resRow.table_id) db.prepare("UPDATE tables SET status = 'Cleaning' WHERE id = ?").run(resRow.table_id);
            db.prepare("UPDATE kitchen_tickets SET status = 'Served' WHERE reservation_id = ? AND status = 'Ready'").run(id);
          } else if (status === 'Cancelled' || status === 'No Show') {
            restoreStockForReservation(id);
            db.prepare('UPDATE reservations SET status = ? WHERE id = ?').run(status, id);
            if (resRow.table_id) db.prepare("UPDATE tables SET status = 'Available' WHERE id = ?").run(resRow.table_id);
          } else {
            db.prepare('UPDATE reservations SET status = ? WHERE id = ?').run(status, id);
          }
        }

        const effectiveArrivalTime = arrival_time || resRow.arrival_time;

        if (arrival_time && arrival_time !== resRow.arrival_time) {
          db.prepare('UPDATE reservations SET arrival_time = ? WHERE id = ?').run(arrival_time, id);
          const pendingTickets = db
            .prepare("SELECT * FROM kitchen_tickets WHERE reservation_id = ? AND status = 'Pending'")
            .all(id) as KitchenTicket[];
          const updateTicket = db.prepare('UPDATE kitchen_tickets SET target_prep_start = ? WHERE id = ?');
          for (const t of pendingTickets) {
            const nextTarget = calculateTargetPrepStart(resRow.date, arrival_time, t.preparation_time);
            updateTicket.run(nextTarget, t.id);
          }
        }

        if (table_id && table_id !== resRow.table_id) {
          const candidates = getTablesWithAvailability(resRow.date, effectiveArrivalTime, resRow.party_size, id);
          const targetTable = candidates.find((t) => t.id === table_id);
          if (!targetTable) {
            throw new HttpError(404, 'Replacement table not found');
          }
          if (!targetTable.is_available_for_slot) {
            throw new HttpError(
              409,
              targetTable.conflict_reason || `${targetTable.table_number} is unavailable for this time slot or party size`
            );
          }

          db.prepare('UPDATE reservations SET table_id = ? WHERE id = ?').run(table_id, id);
          db.prepare('UPDATE kitchen_tickets SET table_number = ? WHERE reservation_id = ?').run(
            targetTable.table_number,
            id
          );

          if (resRow.date === clock.current_date) {
            const effectiveStatus = status || resRow.status;
            if (resRow.table_id) {
              const otherActive = db
                .prepare(
                  "SELECT id FROM reservations WHERE table_id = ? AND id != ? AND date = ? AND status IN ('Confirmed', 'Checked In', 'Seated')"
                )
                .get(resRow.table_id, id, resRow.date);
              if (!otherActive) {
                db.prepare("UPDATE tables SET status = 'Available' WHERE id = ? AND status IN ('Reserved', 'Occupied')").run(
                  resRow.table_id
                );
              }
            }
            if (effectiveStatus === 'Checked In' || effectiveStatus === 'Seated') {
              db.prepare("UPDATE tables SET status = 'Occupied' WHERE id = ?").run(table_id);
            } else if (effectiveStatus === 'Confirmed' && targetTable.status === 'Available') {
              db.prepare("UPDATE tables SET status = 'Reserved' WHERE id = ?").run(table_id);
            }
          }
        }
      }).immediate();

      broadcastSync('reservation:updated', { reservationId: id });
      res.json({ success: true });
    } catch (err: unknown) {
      if (err instanceof HttpError) {
        res.status(err.status).json({ error: err.message });
        return;
      }
      res.status(409).json({ error: err instanceof Error ? err.message : 'Unable to update reservation' });
    }
  });

  // ==================== KITCHEN DISPLAY SYSTEM ====================
  router.get('/kitchen/tickets', requireRole(['kitchen', 'manager', 'hostess']), (_req, res) => {
    const clock = getClockState();
    const rows = db
      .prepare(`
        SELECT kt.*, r.customer_name, r.arrival_time, r.date as reservation_date, r.status as reservation_status
        FROM kitchen_tickets kt
        JOIN reservations r ON r.id = kt.reservation_id
        WHERE r.status NOT IN ('Cancelled', 'No Show')
          AND kt.status != 'Served'
        ORDER BY
          CASE kt.priority WHEN 'Urgent' THEN 0 WHEN 'High' THEN 1 ELSE 2 END ASC,
          kt.target_prep_start ASC,
          kt.id ASC
      `)
      .all() as Array<KitchenTicket & { reservation_date: string; arrival_time: string; reservation_status: string }>;

    const escalateStmt = db.prepare("UPDATE kitchen_tickets SET priority = 'Urgent' WHERE id = ?");
    const tickets = rows.map((row) => {
      const computed = computeTicketRuntime(row, clock);
      if (computed.should_fire_now && row.priority !== 'Urgent') {
        escalateStmt.run(row.id);
      }
      return computed;
    });

    tickets.sort((a, b) => {
      const pWeight = { Urgent: 0, High: 1, Normal: 2 };
      if (a.is_overdue !== b.is_overdue) return a.is_overdue ? -1 : 1;
      if (a.should_fire_now !== b.should_fire_now) return a.should_fire_now ? -1 : 1;
      if (pWeight[a.priority] !== pWeight[b.priority]) return pWeight[a.priority] - pWeight[b.priority];
      return (a.minutes_until_fire ?? 999) - (b.minutes_until_fire ?? 999);
    });

    res.json({ tickets, clock });
  });

  router.patch('/kitchen/tickets/:id', adminRateLimiter, requireRole(['kitchen', 'manager']), (req, res) => {
    const id = parsePositiveId(req.params.id, 'ticket ID');
    const { status, priority } = kitchenTicketUpdateSchema.parse(req.body);
    const clock = getClockState();

    const ticket = db
      .prepare(
        `SELECT kt.*, r.status as reservation_status
         FROM kitchen_tickets kt
         JOIN reservations r ON r.id = kt.reservation_id
         WHERE kt.id = ?`
      )
      .get(id) as (KitchenTicket & { reservation_status: string }) | undefined;

    if (!ticket) {
      res.status(404).json({ error: 'Ticket not found' });
      return;
    }

    if (
      ticket.reservation_status === 'Cancelled' ||
      ticket.reservation_status === 'No Show' ||
      ticket.reservation_status === 'Completed'
    ) {
      res.status(409).json({ error: `Cannot update ticket for a ${ticket.reservation_status} reservation` });
      return;
    }

    if (status) {
      const allowedNext = VALID_TICKET_TRANSITIONS[ticket.status] || [];
      if (!allowedNext.includes(status)) {
        res.status(409).json({
          error: `Invalid ticket status transition from ${ticket.status} to ${status}`,
        });
        return;
      }

      if (status === 'Cooking') {
        db.prepare("UPDATE kitchen_tickets SET status = 'Cooking', started_at = ? WHERE id = ?").run(
          clock.current_iso,
          id
        );
      } else if (status === 'Ready') {
        db.prepare("UPDATE kitchen_tickets SET status = 'Ready', ready_at = ? WHERE id = ?").run(clock.current_iso, id);
      } else if (status === 'Served') {
        db.prepare("UPDATE kitchen_tickets SET status = 'Served' WHERE id = ?").run(id);
      }
    }

    if (priority) {
      db.prepare('UPDATE kitchen_tickets SET priority = ? WHERE id = ?').run(priority, id);
    }

    const updated = db.prepare('SELECT * FROM kitchen_tickets WHERE id = ?').get(id);
    broadcastSync('tickets:updated', updated);
    res.json({ ticket: updated });
  });

  // ==================== ANALYTICS (100% REAL STORED RECORDS) ====================
  router.get('/admin/analytics', requireRole(['manager']), (req, res) => {
    const { range } = analyticsQuerySchema.parse(req.query);
    const clock = getClockState();
    const today = clock.current_date;

    const todayDateObj = new Date(`${today}T00:00:00`);
    const daysBack = range === 'today' ? 0 : range === '7d' ? 6 : 29;
    const startDateObj = new Date(todayDateObj);
    startDateObj.setDate(startDateObj.getDate() - daysBack);
    const startDate = formatLocalDate(startDateObj);

    const allRangeReservations = db
      .prepare('SELECT * FROM reservations WHERE date >= ? AND date <= ?')
      .all(startDate, today) as Reservation[];

    const activeReservations = allRangeReservations.filter((r) => r.status !== 'Cancelled' && r.status !== 'No Show');
    const completedReservations = allRangeReservations.filter((r) => r.status === 'Completed');
    const cancelledReservations = allRangeReservations.filter((r) => r.status === 'Cancelled');

    const todayReservations = db
      .prepare("SELECT * FROM reservations WHERE date = ? AND status NOT IN ('Cancelled', 'No Show')")
      .all(today) as Reservation[];

    const tables = db.prepare('SELECT * FROM tables WHERE is_active = 1').all() as RestaurantTable[];
    const occupiedTables = tables.filter((t) => t.status === 'Occupied').length;
    const reservedTables = tables.filter((t) => t.status === 'Reserved').length;
    const availableTables = tables.filter((t) => t.status === 'Available').length;
    const totalActiveTables = tables.length;
    const occupancyPercentage =
      totalActiveTables > 0
        ? Math.round(((occupiedTables + reservedTables) / totalActiveTables) * 100)
        : 0;

    const todayGuests = todayReservations.reduce((sum, r) => sum + r.party_size, 0);
    const totalRevenue = Math.round(activeReservations.reduce((sum, r) => sum + r.total_amount, 0));

    const preOrdersInRange = db
      .prepare(`
        SELECT po.*, COALESCE(c.name, 'General') as category_name
        FROM pre_orders po
        JOIN reservations r ON r.id = po.reservation_id
        LEFT JOIN menu_items m ON m.id = po.menu_item_id
        LEFT JOIN categories c ON c.id = m.category_id
        WHERE r.date >= ? AND r.date <= ? AND r.status NOT IN ('Cancelled', 'No Show')
      `)
      .all(startDate, today) as Array<PreOrder & { category_name?: string }>;

    const totalPreOrders = preOrdersInRange.reduce((sum, p) => sum + p.quantity, 0);

    const withDiningTimestamps = completedReservations.filter((r) => r.seated_at && r.completed_at);
    const avgDiningDuration =
      withDiningTimestamps.length > 0
        ? Math.round(
            withDiningTimestamps.reduce((sum, r) => {
              const s = new Date(r.seated_at!).getTime();
              const e = new Date(r.completed_at!).getTime();
              return sum + Math.max(1, Math.round((e - s) / 60_000));
            }, 0) / withDiningTimestamps.length
          )
        : null;

    const withTurnaroundTimestamps = completedReservations.filter(
      (r) => (r.checked_in_at || r.seated_at) && r.completed_at
    );
    const avgTurnaroundMinutes =
      withTurnaroundTimestamps.length > 0
        ? Math.round(
            withTurnaroundTimestamps.reduce((sum, r) => {
              const s = new Date((r.checked_in_at || r.seated_at)!).getTime();
              const e = new Date(r.completed_at!).getTime();
              return sum + Math.max(1, Math.round((e - s) / 60_000));
            }, 0) / withTurnaroundTimestamps.length
          )
        : null;

    const hourBuckets: Record<
      string,
      { hour: string; bookings: number; guests: number; turnaroundSum: number; turnaroundCount: number }
    > = {};
    for (let h = 12; h <= 22; h++) {
      const label = `${h > 12 ? h - 12 : h}${h >= 12 ? 'PM' : 'AM'}`;
      hourBuckets[String(h).padStart(2, '0')] = {
        hour: label,
        bookings: 0,
        guests: 0,
        turnaroundSum: 0,
        turnaroundCount: 0,
      };
    }

    for (const r of activeReservations) {
      const hh = r.arrival_time.slice(0, 2);
      if (hourBuckets[hh]) {
        hourBuckets[hh].bookings += 1;
        hourBuckets[hh].guests += r.party_size;
        if (r.status === 'Completed' && (r.checked_in_at || r.seated_at) && r.completed_at) {
          const s = new Date((r.checked_in_at || r.seated_at)!).getTime();
          const e = new Date(r.completed_at).getTime();
          hourBuckets[hh].turnaroundSum += Math.max(1, Math.round((e - s) / 60_000));
          hourBuckets[hh].turnaroundCount += 1;
        }
      }
    }

    const dishMap: Record<string, { name: string; orders: number; revenue: number }> = {};
    for (const po of preOrdersInRange) {
      if (!dishMap[po.item_name_snapshot]) {
        dishMap[po.item_name_snapshot] = { name: po.item_name_snapshot, orders: 0, revenue: 0 };
      }
      dishMap[po.item_name_snapshot].orders += po.quantity;
      dishMap[po.item_name_snapshot].revenue += po.price_snapshot * po.quantity;
    }
    const popularDishes = Object.values(dishMap)
      .sort((a, b) => b.orders - a.orders)
      .slice(0, 6);

    const dailyMap: Record<string, { date: string; reservations: number; revenue: number }> = {};
    for (const r of activeReservations) {
      if (!dailyMap[r.date]) {
        dailyMap[r.date] = { date: r.date.slice(5), reservations: 0, revenue: 0 };
      }
      dailyMap[r.date].reservations += 1;
      dailyMap[r.date].revenue += Math.round(r.total_amount);
    }
    const dailyBookingTrends = Object.entries(dailyMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([, v]) => v);

    const divisorDays = Math.max(1, daysBack + 1);
    const occupancyTrends = Object.values(hourBuckets).map((b) => ({
      label: b.hour,
      occupancy:
        totalActiveTables > 0
          ? Math.min(100, Math.round((b.bookings / (totalActiveTables * divisorDays)) * 100))
          : 0,
      turnaround: b.turnaroundCount > 0 ? Math.round(b.turnaroundSum / b.turnaroundCount) : null,
    }));

    const rangeTickets = db
      .prepare(`
        SELECT kt.*, COALESCE(c.name, 'General') as category_name
        FROM kitchen_tickets kt
        JOIN reservations r ON r.id = kt.reservation_id
        LEFT JOIN pre_orders po ON po.id = kt.pre_order_id
        LEFT JOIN menu_items m ON m.id = po.menu_item_id
        LEFT JOIN categories c ON c.id = m.category_id
        WHERE r.date >= ? AND r.date <= ? AND r.status NOT IN ('Cancelled', 'No Show')
      `)
      .all(startDate, today) as Array<KitchenTicket & { category_name: string }>;

    const catPerf: Record<
      string,
      { targetSum: number; targetCount: number; actualSum: number; actualCount: number }
    > = {};
    let completedTicketCount = 0;
    let onTimeTicketCount = 0;
    let totalActualPrep = 0;
    let actualPrepCount = 0;

    for (const t of rangeTickets) {
      const cat = t.category_name || 'General';
      if (!catPerf[cat]) {
        catPerf[cat] = { targetSum: 0, targetCount: 0, actualSum: 0, actualCount: 0 };
      }
      catPerf[cat].targetSum += t.preparation_time;
      catPerf[cat].targetCount += 1;

      if (t.started_at && t.ready_at) {
        const elapsed = Math.max(
          1,
          Math.round((new Date(t.ready_at).getTime() - new Date(t.started_at).getTime()) / 60_000)
        );
        catPerf[cat].actualSum += elapsed;
        catPerf[cat].actualCount += 1;
        totalActualPrep += elapsed;
        actualPrepCount += 1;
        completedTicketCount += 1;
        if (elapsed <= t.preparation_time) {
          onTimeTicketCount += 1;
        }
      }
    }

    const prepPerformance = Object.entries(catPerf).map(([category, v]) => ({
      category,
      targetPrep: Math.round(v.targetSum / Math.max(1, v.targetCount)),
      actualPrep: v.actualCount > 0 ? Math.round(v.actualSum / v.actualCount) : null,
    }));

    const onTimePrepRate =
      completedTicketCount > 0 ? Math.round((onTimeTicketCount / completedTicketCount) * 100) : null;
    const avgPrepTimeMinutes =
      actualPrepCount > 0
        ? Math.round(totalActualPrep / actualPrepCount)
        : rangeTickets.length > 0
          ? Math.round(rangeTickets.reduce((s, t) => s + t.preparation_time, 0) / rangeTickets.length)
          : null;

    const tableCounts: Record<number, number> = {};
    for (const r of activeReservations) {
      if (r.table_id) tableCounts[r.table_id] = (tableCounts[r.table_id] || 0) + 1;
    }
    const tableUtilization = tables.map((t) => ({
      table: t.table_number,
      bookings: tableCounts[t.id] || 0,
      capacity: t.capacity,
    }));

    const payload: AnalyticsOverview = {
      range,
      kpis: {
        totalReservations: allRangeReservations.length,
        completedReservations: completedReservations.length,
        cancelledReservations: cancelledReservations.length,
        todayGuests,
        availableTables,
        occupiedTables,
        totalActiveTables,
        occupancyPercentage,
        avgDiningDuration,
        avgTurnaroundMinutes,
        totalPreOrders,
        totalRevenue,
        onTimePrepRate,
        avgPrepTimeMinutes,
      },
      reservationsByHour: Object.values(hourBuckets).map(({ hour, bookings, guests }) => ({
        hour,
        bookings,
        guests,
      })),
      occupancyTrends,
      popularDishes,
      prepPerformance,
      dailyBookingTrends,
      tableUtilization,
    };

    res.json(payload);
  });

  // ==================== SMS LOGS ====================
  router.get('/sms-logs', requireRole(['hostess', 'manager']), (_req, res) => {
    const logs = db.prepare('SELECT * FROM sms_logs ORDER BY id DESC LIMIT 20').all();
    res.json({ logs });
  });

  return router;
}
