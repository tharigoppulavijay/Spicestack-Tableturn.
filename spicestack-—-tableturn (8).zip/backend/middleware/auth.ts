import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';
import type { User, UserRole } from '../../src/types/index.ts';
import { logger } from '../utils/logger.ts';

const VALID_ROLES: ReadonlySet<UserRole> = new Set(['customer', 'hostess', 'kitchen', 'manager']);
const TOKEN_ISSUER = 'spicestack-tableturn';
const WEAK_SECRET_PATTERNS = [
  'replace_with',
  'my_',
  'example',
  'changeme',
  'your_secret',
  'dev_secret',
  'test_secret',
  'secret_key',
  'password',
  '123456',
];

export function isWeakSecret(secret: string): boolean {
  const trimmed = secret.trim();
  if (trimmed.length < 32) return true;
  const lower = trimmed.toLowerCase();
  if (WEAK_SECRET_PATTERNS.some((pattern) => lower.includes(pattern))) {
    return true;
  }
  if (new Set(trimmed).size < 10) {
    return true;
  }
  return false;
}

export function resolveRuntimeSecret(env: NodeJS.ProcessEnv = process.env): string {
  const envSecret = env.AUTH_SECRET?.trim();
  const isProd = env.NODE_ENV === 'production';

  if (isProd) {
    if (!envSecret || isWeakSecret(envSecret)) {
      throw new Error(
        'FATAL: AUTH_SECRET environment variable must be set to a strong cryptographic secret (minimum 32 characters, non-placeholder) in production.'
      );
    }
    return envSecret;
  }

  if (envSecret && !isWeakSecret(envSecret)) {
    return envSecret;
  }

  if (env.NODE_ENV !== 'test') {
    logger.warn(
      'AUTH_SECRET not set or weak in non-production mode; using ephemeral in-memory secret for this process.'
    );
  }
  return crypto.randomBytes(32).toString('hex');
}

export function isDemoAuthEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  if (env.ALLOW_DEMO_AUTH === 'false') {
    return false;
  }
  if (env.NODE_ENV === 'production') {
    return env.ALLOW_DEMO_AUTH === 'true' || env.HACKATHON_DEMO_MODE === 'true';
  }
  return true;
}

const RUNTIME_SECRET = resolveRuntimeSecret();

export interface AuthRequest extends Request {
  user?: User;
  requestId?: string;
}

interface TokenPayload extends User {
  iss: string;
  iat: number;
  exp: number;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash || !storedHash.includes(':')) return false;
  const [salt, keyHex] = storedHash.split(':');
  if (!salt || !keyHex) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const storedBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== storedBuf.length) return false;
  return crypto.timingSafeEqual(derived, storedBuf);
}

export function signToken(user: User, expiresInSeconds = 60 * 60 * 24): string {
  const nowSec = Math.floor(Date.now() / 1000);
  const tokenData: TokenPayload = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    phone: user.phone,
    iss: TOKEN_ISSUER,
    iat: nowSec,
    exp: nowSec + expiresInSeconds,
  };
  const payload = Buffer.from(JSON.stringify(tokenData)).toString('base64url');
  const sig = crypto.createHmac('sha256', RUNTIME_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

export function verifyToken(token: string): User | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 2) return null;
    const [payload, sig] = parts;
    if (!payload || !sig) return null;

    const expected = crypto.createHmac('sha256', RUNTIME_SECRET).update(payload).digest('base64url');
    const sigBuf = Buffer.from(sig);
    const expBuf = Buffer.from(expected);
    if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
      return null;
    }

    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as Partial<TokenPayload>;
    const nowSec = Math.floor(Date.now() / 1000);
    if (
      decoded.iss !== TOKEN_ISSUER ||
      typeof decoded.id !== 'number' ||
      !Number.isInteger(decoded.id) ||
      decoded.id <= 0 ||
      typeof decoded.email !== 'string' ||
      decoded.email.length === 0 ||
      typeof decoded.role !== 'string' ||
      !VALID_ROLES.has(decoded.role as UserRole) ||
      typeof decoded.iat !== 'number' ||
      !Number.isFinite(decoded.iat) ||
      decoded.iat > nowSec + 60 ||
      typeof decoded.exp !== 'number' ||
      !Number.isFinite(decoded.exp) ||
      decoded.exp <= decoded.iat ||
      nowSec >= decoded.exp
    ) {
      return null;
    }

    return {
      id: decoded.id,
      name: String(decoded.name || ''),
      email: decoded.email,
      role: decoded.role as UserRole,
      phone: String(decoded.phone || ''),
    };
  } catch {
    return null;
  }
}

export function attachUser(req: AuthRequest, _res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7).trim();
    if (token) {
      const decoded = verifyToken(token);
      if (decoded) {
        req.user = decoded;
      } else {
        logger.warn({ requestId: req.requestId, path: req.path }, 'Rejected invalid or expired bearer token');
      }
    }
  }
  next();
}

export function requireRole(allowedRoles: UserRole[]) {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      logger.warn({ requestId: req.requestId, path: req.path, method: req.method }, 'Unauthenticated access attempt');
      res.status(401).json({
        error: 'Authentication required. Please sign in or select a demo workspace.',
      });
      return;
    }
    if (!allowedRoles.includes(req.user.role)) {
      logger.warn(
        {
          requestId: req.requestId,
          path: req.path,
          method: req.method,
          userRole: req.user.role,
          allowedRoles,
        },
        'Forbidden role access attempt'
      );
      res.status(403).json({
        error: `Access denied. Role '${req.user.role}' cannot access this endpoint. Required: ${allowedRoles.join(' or ')}.`,
      });
      return;
    }
    next();
  };
}
