import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import type { AuthRequest } from './auth.ts';
import { logger } from '../utils/logger.ts';

interface RateBucket {
  timestamps: number[];
  lastSeen: number;
}

const DEFAULT_MAX_KEYS = Number(process.env.RATE_LIMIT_MAX_KEYS || 5000);
const rateBuckets = new Map<string, RateBucket>();

interface IdempotencyEntry {
  status: number;
  body: unknown;
  expiresAt: number;
}

const IDEMPOTENCY_TTL_MS = 5 * 60_000;
const IDEMPOTENCY_MAX_ENTRIES = 1000;
const idempotencyCache = new Map<string, IdempotencyEntry>();
const idempotencyInFlight = new Set<string>();

export function clearRateLimiters(): void {
  rateBuckets.clear();
}

export function clearIdempotencyCache(): void {
  idempotencyCache.clear();
  idempotencyInFlight.clear();
}

export function getRateLimiterStats(): { size: number } {
  return { size: rateBuckets.size };
}

function pruneAndEvictBuckets(now: number, maxWindowMs: number, maxKeys: number): void {
  for (const [k, b] of rateBuckets.entries()) {
    if (now - b.lastSeen > maxWindowMs) {
      rateBuckets.delete(k);
    }
  }
  while (rateBuckets.size >= maxKeys) {
    const oldestKey = rateBuckets.keys().next().value;
    if (!oldestKey) break;
    rateBuckets.delete(oldestKey);
  }
}

export function createRateLimiter(opts: {
  windowMs: number;
  max: number;
  keyPrefix: string;
  message?: string;
  maxKeys?: number;
}) {
  const maxKeys = Math.max(10, opts.maxKeys ?? DEFAULT_MAX_KEYS);

  return (req: Request, res: Response, next: NextFunction): void => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const key = `${opts.keyPrefix}:${ip}`;
    const now = Date.now();
    const cutoff = now - opts.windowMs;

    let bucket = rateBuckets.get(key);
    if (!bucket) {
      if (rateBuckets.size >= maxKeys) {
        pruneAndEvictBuckets(now, opts.windowMs, maxKeys);
      }
      bucket = { timestamps: [], lastSeen: now };
    } else {
      // Refresh LRU insertion order
      rateBuckets.delete(key);
    }

    bucket.timestamps = bucket.timestamps.filter((t) => t > cutoff);
    bucket.lastSeen = now;

    const resetEpochSec = Math.ceil((now + opts.windowMs) / 1000);
    res.setHeader('X-RateLimit-Limit', String(opts.max));

    if (bucket.timestamps.length >= opts.max) {
      const oldest = bucket.timestamps[0];
      const retryAfterSec = Math.max(1, Math.ceil((oldest + opts.windowMs - now) / 1000));
      rateBuckets.set(key, bucket);
      res.setHeader('X-RateLimit-Remaining', '0');
      res.setHeader('X-RateLimit-Reset', String(Math.ceil((oldest + opts.windowMs) / 1000)));
      res.setHeader('Retry-After', String(retryAfterSec));
      res.status(429).json({
        error: opts.message || 'Too many requests. Please wait a moment and try again.',
      });
      return;
    }

    bucket.timestamps.push(now);
    rateBuckets.set(key, bucket);
    res.setHeader('X-RateLimit-Remaining', String(Math.max(0, opts.max - bucket.timestamps.length)));
    res.setHeader('X-RateLimit-Reset', String(resetEpochSec));
    next();
  };
}

export function idempotencyMiddleware(opts: { ttlMs?: number; maxEntries?: number } = {}) {
  const ttlMs = opts.ttlMs ?? IDEMPOTENCY_TTL_MS;
  const maxEntries = opts.maxEntries ?? IDEMPOTENCY_MAX_ENTRIES;

  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    const rawKey = req.header('Idempotency-Key');
    if (rawKey === undefined) {
      next();
      return;
    }

    const trimmedKey = rawKey.trim();
    if (!trimmedKey || trimmedKey.length > 128) {
      res.status(400).json({
        error: 'Idempotency-Key header must be a non-empty string up to 128 characters.',
      });
      return;
    }

    const now = Date.now();
    const actor = req.user?.id ? `u:${req.user.id}` : `ip:${req.ip || 'anon'}`;
    const cacheKey = `${actor}:${req.method}:${req.baseUrl}${req.path}:${trimmedKey}`;

    const existing = idempotencyCache.get(cacheKey);
    if (existing) {
      if (existing.expiresAt > now) {
        res.setHeader('X-Idempotent-Replay', 'true');
        res.status(existing.status).json(existing.body);
        return;
      }
      idempotencyCache.delete(cacheKey);
    }

    if (idempotencyInFlight.has(cacheKey)) {
      res.status(409).json({
        error: 'Duplicate request with the same Idempotency-Key is currently being processed.',
      });
      return;
    }

    idempotencyInFlight.add(cacheKey);
    const originalJson = res.json.bind(res);

    res.json = ((body: unknown) => {
      idempotencyInFlight.delete(cacheKey);
      if (res.statusCode >= 200 && res.statusCode < 300) {
        // Evict expired or oldest entries when bounded capacity is reached
        for (const [k, v] of idempotencyCache.entries()) {
          if (v.expiresAt <= Date.now()) {
            idempotencyCache.delete(k);
          }
        }
        while (idempotencyCache.size >= maxEntries) {
          const oldest = idempotencyCache.keys().next().value;
          if (!oldest) break;
          idempotencyCache.delete(oldest);
        }
        idempotencyCache.set(cacheKey, {
          status: res.statusCode,
          body,
          expiresAt: Date.now() + ttlMs,
        });
      }
      return originalJson(body);
    }) as typeof res.json;

    res.on('close', () => {
      idempotencyInFlight.delete(cacheKey);
    });

    next();
  };
}

export function securityHeadersMiddleware(_req: Request, res: Response, next: NextFunction): void {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-DNS-Prefetch-Control', 'off');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  next();
}

export function requestContextMiddleware(req: AuthRequest, res: Response, next: NextFunction): void {
  const reqId = crypto.randomUUID();
  req.requestId = reqId;
  res.setHeader('X-Request-Id', reqId);

  const startedAt = Date.now();
  res.on('finish', () => {
    if (req.originalUrl.startsWith('/api')) {
      const durationMs = Date.now() - startedAt;
      const logPayload = {
        requestId: reqId,
        method: req.method,
        path: req.path,
        status: res.statusCode,
        durationMs,
        role: req.user?.role || 'anonymous',
      };
      if (res.statusCode >= 500) {
        logger.error(logPayload, 'API request failed');
      } else if (res.statusCode >= 400) {
        logger.warn(logPayload, 'API request rejected');
      } else {
        logger.info(logPayload, 'API request completed');
      }
    }
  });

  next();
}

export function errorHandler(err: unknown, req: AuthRequest, res: Response, _next: NextFunction): void {
  if (err instanceof ZodError) {
    res.status(400).json({
      error: err.issues[0]?.message || 'Invalid request input',
      details: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
      requestId: req.requestId,
    });
    return;
  }

  if (err instanceof SyntaxError && 'body' in err) {
    res.status(400).json({
      error: 'Malformed JSON request body',
      requestId: req.requestId,
    });
    return;
  }

  const errObj = err as { status?: number; code?: string; message?: string };
  if (errObj?.code === 'LIMIT_FILE_SIZE') {
    res.status(400).json({
      error: 'Uploaded image exceeds 8 MB limit',
      requestId: req.requestId,
    });
    return;
  }
  if (errObj?.code === 'LIMIT_UNEXPECTED_FILE') {
    res.status(400).json({
      error: 'Unexpected file upload field',
      requestId: req.requestId,
    });
    return;
  }

  const status =
    typeof errObj?.status === 'number' && errObj.status >= 400 && errObj.status < 600
      ? errObj.status
      : 500;

  if (status >= 500) {
    logger.error(
      {
        requestId: req.requestId,
        method: req.method,
        path: req.path,
        err: errObj?.message || 'Internal server error',
      },
      'Unhandled server error'
    );
  }

  res.status(status).json({
    error: status >= 500 ? 'Internal server error' : errObj?.message || 'Request failed',
    requestId: req.requestId,
  });
}
