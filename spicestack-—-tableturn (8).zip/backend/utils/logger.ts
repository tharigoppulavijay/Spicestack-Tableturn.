import pino from 'pino';

const isTest = process.env.NODE_ENV === 'test';
const isProd = process.env.NODE_ENV === 'production';

export const logger = pino({
  name: 'spicestack-tableturn',
  level: process.env.LOG_LEVEL || (isTest ? 'silent' : isProd ? 'info' : 'debug'),
  redact: {
    paths: [
      'req.headers.authorization',
      'req.headers.cookie',
      'headers.authorization',
      'headers.cookie',
      '*.password',
      '*.password_hash',
      '*.token',
      '*.AUTH_SECRET',
      '*.secret',
      'password',
      'password_hash',
      'token',
      'secret',
    ],
    censor: '[REDACTED]',
  },
  base: isProd ? { service: 'spicestack-tableturn' } : undefined,
});
