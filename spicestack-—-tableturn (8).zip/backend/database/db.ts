import Database from 'better-sqlite3';
import path from 'path';
import { logger } from '../utils/logger.ts';

const DB_PATH = process.env.DB_PATH
  ? path.resolve(process.env.DB_PATH)
  : path.resolve(process.cwd(), 'spicestack.db');

export const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');
db.pragma('synchronous = NORMAL');

const REQUIRED_TABLES = [
  'users',
  'restaurant_settings',
  'tables',
  'categories',
  'menu_items',
  'reservations',
  'pre_orders',
  'kitchen_tickets',
  'sms_logs',
];

export function initializeDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('customer', 'hostess', 'kitchen', 'manager')),
      phone TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS restaurant_settings (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      restaurant_name TEXT NOT NULL DEFAULT 'SpiceStack — TableTurn',
      logo_url TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '428 Indigo Boulevard, Culinary District',
      phone TEXT NOT NULL DEFAULT '+91 80 4120 8899',
      email TEXT NOT NULL DEFAULT 'concierge@spicestack.io',
      opening_hours TEXT NOT NULL DEFAULT '11:00 - 23:30',
      dining_duration INTEGER NOT NULL DEFAULT 90 CHECK(dining_duration >= 30 AND dining_duration <= 300),
      gst_percentage REAL NOT NULL DEFAULT 5.0 CHECK(gst_percentage >= 0 AND gst_percentage <= 50),
      service_charge_percentage REAL NOT NULL DEFAULT 10.0 CHECK(service_charge_percentage >= 0 AND service_charge_percentage <= 50),
      currency TEXT NOT NULL DEFAULT '₹',
      slot_interval_minutes INTEGER NOT NULL DEFAULT 30 CHECK(slot_interval_minutes >= 15 AND slot_interval_minutes <= 120),
      max_advance_days INTEGER NOT NULL DEFAULT 30 CHECK(max_advance_days >= 1 AND max_advance_days <= 365),
      clock_mode TEXT NOT NULL DEFAULT 'simulated' CHECK(clock_mode IN ('simulated', 'live')),
      simulated_time TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS tables (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      table_number TEXT NOT NULL UNIQUE,
      capacity INTEGER NOT NULL CHECK(capacity >= 1 AND capacity <= 24),
      type TEXT NOT NULL DEFAULT 'Main Dining',
      section TEXT NOT NULL DEFAULT 'Main Hall',
      description TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Available' CHECK(status IN ('Available', 'Reserved', 'Occupied', 'Cleaning', 'Maintenance', 'Disabled')),
      is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0, 1)),
      pos_x INTEGER NOT NULL DEFAULT 0,
      pos_y INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      display_order INTEGER NOT NULL DEFAULT 0 CHECK(display_order >= 0)
    );

    CREATE TABLE IF NOT EXISTS menu_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      image TEXT NOT NULL DEFAULT '',
      price REAL NOT NULL CHECK(price >= 0),
      category_id INTEGER NOT NULL,
      dietary_type TEXT NOT NULL DEFAULT 'Veg' CHECK(dietary_type IN ('Veg', 'Non-Veg', 'Vegan')),
      spicy_level TEXT NOT NULL DEFAULT 'Medium' CHECK(spicy_level IN ('Mild', 'Medium', 'Hot', 'Extra Hot')),
      preparation_time INTEGER NOT NULL DEFAULT 15 CHECK(preparation_time >= 1),
      is_chef_special INTEGER NOT NULL DEFAULT 0 CHECK(is_chef_special IN (0, 1)),
      is_popular INTEGER NOT NULL DEFAULT 0 CHECK(is_popular IN (0, 1)),
      allergy_info TEXT NOT NULL DEFAULT '',
      customization_options TEXT NOT NULL DEFAULT '[]',
      availability INTEGER NOT NULL DEFAULT 1 CHECK(availability IN (0, 1)),
      stock_quantity INTEGER NOT NULL DEFAULT 25 CHECK(stock_quantity >= 0),
      daily_limit INTEGER NOT NULL DEFAULT 40 CHECK(daily_limit >= 0),
      is_deleted INTEGER NOT NULL DEFAULT 0 CHECK(is_deleted IN (0, 1)),
      FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
    );

    CREATE TABLE IF NOT EXISTS reservations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      booking_code TEXT NOT NULL UNIQUE,
      user_id INTEGER,
      customer_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL DEFAULT '',
      date TEXT NOT NULL,
      arrival_time TEXT NOT NULL,
      party_size INTEGER NOT NULL CHECK(party_size >= 1 AND party_size <= 24),
      table_id INTEGER,
      status TEXT NOT NULL DEFAULT 'Confirmed' CHECK(status IN ('Confirmed', 'Checked In', 'Seated', 'Completed', 'Cancelled', 'No Show')),
      checked_in_at TEXT,
      seated_at TEXT,
      completed_at TEXT,
      special_requests TEXT NOT NULL DEFAULT '',
      subtotal REAL NOT NULL DEFAULT 0 CHECK(subtotal >= 0),
      gst_amount REAL NOT NULL DEFAULT 0 CHECK(gst_amount >= 0),
      service_charge_amount REAL NOT NULL DEFAULT 0 CHECK(service_charge_amount >= 0),
      total_amount REAL NOT NULL DEFAULT 0 CHECK(total_amount >= 0),
      is_archived_by_customer INTEGER NOT NULL DEFAULT 0 CHECK(is_archived_by_customer IN (0, 1)),
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (table_id) REFERENCES tables(id) ON DELETE SET NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS pre_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reservation_id INTEGER NOT NULL,
      menu_item_id INTEGER,
      item_name_snapshot TEXT NOT NULL,
      price_snapshot REAL NOT NULL CHECK(price_snapshot >= 0),
      prep_time_snapshot INTEGER NOT NULL DEFAULT 15 CHECK(prep_time_snapshot >= 1),
      quantity INTEGER NOT NULL CHECK(quantity >= 1),
      customization_notes TEXT NOT NULL DEFAULT '',
      allergy_notes TEXT NOT NULL DEFAULT '',
      FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE,
      FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS kitchen_tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reservation_id INTEGER NOT NULL,
      pre_order_id INTEGER,
      item_name TEXT NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity >= 1),
      table_number TEXT NOT NULL,
      booking_code TEXT NOT NULL,
      target_prep_start TEXT NOT NULL,
      preparation_time INTEGER NOT NULL CHECK(preparation_time >= 1),
      status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending', 'Cooking', 'Ready', 'Served')),
      priority TEXT NOT NULL DEFAULT 'Normal' CHECK(priority IN ('Normal', 'High', 'Urgent')),
      allergies TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      started_at TEXT,
      ready_at TEXT,
      FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE,
      FOREIGN KEY (pre_order_id) REFERENCES pre_orders(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS sms_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reservation_id INTEGER NOT NULL,
      phone TEXT NOT NULL,
      message TEXT NOT NULL,
      calendar_link TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE
    );
  `);

  // Safe schema migrations for existing databases
  const resCols = db.prepare('PRAGMA table_info(reservations)').all() as Array<{ name: string }>;
  const colNames = new Set(resCols.map((c) => c.name));
  if (!colNames.has('user_id')) {
    db.exec('ALTER TABLE reservations ADD COLUMN user_id INTEGER REFERENCES users(id) ON DELETE SET NULL');
  }
  if (!colNames.has('is_archived_by_customer')) {
    db.exec('ALTER TABLE reservations ADD COLUMN is_archived_by_customer INTEGER NOT NULL DEFAULT 0');
  }

  // Prevent negative stock and duplicate kitchen tickets, and optimize hot query paths
  db.exec(`
    CREATE TRIGGER IF NOT EXISTS trg_menu_items_nonneg_stock_update
    BEFORE UPDATE OF stock_quantity ON menu_items
    FOR EACH ROW
    WHEN NEW.stock_quantity < 0
    BEGIN
      SELECT RAISE(ABORT, 'Stock quantity cannot be negative');
    END;

    CREATE UNIQUE INDEX IF NOT EXISTS idx_tickets_preorder
    ON kitchen_tickets(pre_order_id)
    WHERE pre_order_id IS NOT NULL;

    CREATE INDEX IF NOT EXISTS idx_reservations_date_status
    ON reservations(date, status);

    CREATE INDEX IF NOT EXISTS idx_reservations_table_date
    ON reservations(table_id, date);

    CREATE INDEX IF NOT EXISTS idx_reservations_user_id
    ON reservations(user_id);

    CREATE INDEX IF NOT EXISTS idx_tickets_res_status
    ON kitchen_tickets(reservation_id, status);

    CREATE INDEX IF NOT EXISTS idx_preorders_res
    ON pre_orders(reservation_id);
  `);

  logger.debug({ dbPath: DB_PATH }, 'SQLite database initialized');
}

export function checkDatabaseHealth(): { connected: boolean; tablesReady: boolean } {
  try {
    const ping = db.prepare('SELECT 1 as ok').get() as { ok?: number } | undefined;
    if (!ping || ping.ok !== 1) {
      return { connected: false, tablesReady: false };
    }
    const existingTables = db
      .prepare("SELECT name FROM sqlite_master WHERE type = 'table'")
      .all() as Array<{ name: string }>;
    const tableSet = new Set(existingTables.map((t) => t.name));
    const tablesReady = REQUIRED_TABLES.every((t) => tableSet.has(t));
    return { connected: true, tablesReady };
  } catch (err) {
    logger.error({ err }, 'Database health check failed');
    return { connected: false, tablesReady: false };
  }
}

export function closeDatabase(): void {
  try {
    if (db.open) {
      db.close();
      logger.info('SQLite database connection closed cleanly');
    }
  } catch (err) {
    logger.error({ err }, 'Error closing SQLite database connection');
  }
}
