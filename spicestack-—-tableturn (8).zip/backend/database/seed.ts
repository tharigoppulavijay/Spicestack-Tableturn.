import { db } from './db.ts';
import { hashPassword } from '../middleware/auth.ts';

function formatLocalDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function subtractDays(date: Date, days: number): string {
  const copy = new Date(date);
  copy.setDate(copy.getDate() - days);
  return formatLocalDate(copy);
}

const IMG = {
  biryani: '/src/assets/images/dish_chicken_biryani_1795006342681.jpg',
  butterChicken: '/src/assets/images/dish_butter_chicken_1795006343077.jpg',
  risotto: '/src/assets/images/dish_truffle_risotto_1795006343336.jpg',
  tandoori: '/src/assets/images/dish_tandoori_platter_1795006343862.jpg',
  dessert: '/src/assets/images/dish_gulab_tiramisu_1795006345869.jpg',
  beverage: '/src/assets/images/dish_craft_beverage_1795006345099.jpg',
  lamb: '/src/assets/images/dish_lamb_chops_1795006346047.jpg',
};

export function seedDatabaseIfEmpty(): void {
  const today = formatLocalDate(new Date());
  const defaultSimTime = `${today}T19:25:00`;

  // Ensure restaurant settings exist
  const settingsCount = db.prepare('SELECT COUNT(*) as c FROM restaurant_settings').get() as { c: number };
  if (settingsCount.c === 0) {
    db.prepare(`
      INSERT INTO restaurant_settings (
        id, restaurant_name, logo_url, address, phone, email, opening_hours,
        dining_duration, gst_percentage, service_charge_percentage, currency,
        slot_interval_minutes, max_advance_days, clock_mode, simulated_time
      ) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'SpiceStack — TableTurn',
      '',
      '428 Indigo Boulevard, Culinary District',
      '+91 80 4120 8899',
      'concierge@spicestack.io',
      '11:00 - 23:30',
      90,
      5.0,
      10.0,
      '₹',
      30,
      30,
      'simulated',
      defaultSimTime
    );
  }

  // Ensure demo users exist with salted scrypt password hashes
  const usersCount = db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number };
  if (usersCount.c === 0) {
    const insertUser = db.prepare(
      'INSERT INTO users (name, email, password_hash, role, phone) VALUES (?, ?, ?, ?, ?)'
    );
    insertUser.run('Aarav Sharma', 'customer@spicestack.io', hashPassword('Customer@123'), 'customer', '+91 98450 11223');
    insertUser.run('Elena Vance', 'hostess@spicestack.io', hashPassword('Hostess@123'), 'hostess', '+91 98450 22334');
    insertUser.run('Chef Vikram Rao', 'kitchen@spicestack.io', hashPassword('Kitchen@123'), 'kitchen', '+91 98450 33445');
    insertUser.run('Maya Krishnan', 'manager@spicestack.io', hashPassword('Manager@123'), 'manager', '+91 98450 44556');
  } else {
    // Migrate legacy plaintext placeholder hashes if present
    const legacyUsers = db.prepare("SELECT id, role FROM users WHERE password_hash = 'demo-pass'").all() as Array<{ id: number; role: string }>;
    const updateHash = db.prepare('UPDATE users SET password_hash = ? WHERE id = ?');
    const roleDefaultPass: Record<string, string> = {
      customer: 'Customer@123',
      hostess: 'Hostess@123',
      kitchen: 'Kitchen@123',
      manager: 'Manager@123',
    };
    for (const u of legacyUsers) {
      updateHash.run(hashPassword(roleDefaultPass[u.role] || 'SpiceStack@123'), u.id);
    }
  }

  // Ensure 8 initial tables exist (2x 2-person, 4x 4-person, 2x 6-person)
  const tablesCount = db.prepare('SELECT COUNT(*) as c FROM tables').get() as { c: number };
  if (tablesCount.c === 0) {
    const insertTable = db.prepare(`
      INSERT INTO tables (table_number, capacity, type, section, description, status, is_active, pos_x, pos_y)
      VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
    `);
    insertTable.run('Table 1', 2, 'Window Booth', 'Main Hall', 'Intimate sunlit window table for two', 'Available', 1, 1);
    insertTable.run('Table 2', 2, 'Window Booth', 'Main Hall', 'Corner window view overlooking indigo courtyard', 'Reserved', 2, 1);
    insertTable.run('Table 3', 4, 'Main Dining', 'Center Lounge', 'Plush velvet booth beneath amber pendants', 'Occupied', 1, 2);
    insertTable.run('Table 4', 4, 'Main Dining', 'Center Lounge', 'Signature centerpiece four-top table', 'Available', 2, 2);
    insertTable.run('Table 5', 4, 'Chef Counter', 'Open Kitchen', 'Front-row dining facing the live tandoor pass', 'Available', 3, 2);
    insertTable.run('Table 6', 4, 'Terrace Alcove', 'Sky Patio', 'Open-air twilight alcove with ambient heaters', 'Reserved', 3, 1);
    insertTable.run('Table 7', 6, 'Private Alcove', 'Velvet Lounge', 'Semi-private acoustic booth for group dining', 'Available', 1, 3);
    insertTable.run('Table 8', 6, 'Royal Booth', 'Velvet Lounge', 'Curved indigo banquette for celebrations', 'Occupied', 2, 3);
  }

  // Ensure 6 default categories exist
  const catCount = db.prepare('SELECT COUNT(*) as c FROM categories').get() as { c: number };
  if (catCount.c === 0) {
    const insertCat = db.prepare('INSERT INTO categories (name, display_order) VALUES (?, ?)');
    insertCat.run('Starters', 1);
    insertCat.run('Main Course', 2);
    insertCat.run('Biryani', 3);
    insertCat.run('Continental', 4);
    insertCat.run('Desserts', 5);
    insertCat.run('Beverages', 6);
  }

  // Seed 28 rich Indian & Continental dishes
  const menuCount = db.prepare('SELECT COUNT(*) as c FROM menu_items').get() as { c: number };
  if (menuCount.c === 0) {
    const cats = db.prepare('SELECT id, name FROM categories').all() as Array<{ id: number; name: string }>;
    const catMap = Object.fromEntries(cats.map((c) => [c.name, c.id]));

    const insertDish = db.prepare(`
      INSERT INTO menu_items (
        name, description, image, price, category_id, dietary_type, spicy_level,
        preparation_time, is_chef_special, is_popular, allergy_info, customization_options,
        availability, stock_quantity, daily_limit, is_deleted
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 0)
    `);

    const dishes: Array<[string, string, string, number, string, string, string, number, number, number, string, string[], number, number]> = [
      // Starters (5)
      ['Smoked Paneer Tikka', 'Charcoal-roasted cottage cheese marinated in Kashmiri chili, hung curd, and charred bell peppers.', IMG.tandoori, 420, 'Starters', 'Veg', 'Medium', 14, 1, 1, 'Dairy', ['Extra Mint Chutney', 'No Onions', 'Less Char'], 28, 45],
      ['Old Delhi Lamb Seekh', 'Hand-minced lamb skewers infused with ginger, green coriander, and roasted cumin over white oak embers.', IMG.tandoori, 560, 'Starters', 'Non-Veg', 'Hot', 16, 1, 1, 'None', ['Mild Spice', 'Extra Pickled Shallots'], 22, 35],
      ['Truffle Wild Mushroom Crostini', 'Sourdough toast layered with whipped mascarpone, porcini ragout, and shaved black truffle.', IMG.risotto, 460, 'Starters', 'Veg', 'Mild', 10, 0, 1, 'Gluten, Dairy', ['Gluten-Free Bread', 'No Garlic'], 30, 40],
      ['Crispy Lotus Stem Honey Chili', 'Wok-tossed lotus root glazed in wild forest honey, toasted sesame, and crushed bird-eye chili.', IMG.tandoori, 390, 'Starters', 'Vegan', 'Medium', 12, 0, 0, 'Sesame', ['No Sesame', 'Extra Crispy'], 24, 35],
      ['Malabar Pepper Calamari', 'Tender squid rings flash-seared with Tellicherry black peppercorns, curry leaves, and lime zest.', IMG.lamb, 520, 'Starters', 'Non-Veg', 'Hot', 13, 0, 0, 'Shellfish', ['Extra Lime', 'Mild Pepper'], 18, 30],

      // Main Course (5)
      ['Murgh Makhani (Butter Chicken)', 'Tandoor-pulled chicken tikka simmered in a 12-hour heirloom tomato, fenugreek, and cultured butter velouté.', IMG.butterChicken, 640, 'Main Course', 'Non-Veg', 'Mild', 18, 1, 1, 'Dairy, Nuts', ['Extra Butter', 'Nut-Free Base', 'Spicy Kick'], 32, 50],
      ['Dal Bukhara 24-Hour', 'Whole black urad lentils slow-simmered overnight over dying charcoal embers with ginger and cream.', IMG.butterChicken, 480, 'Main Course', 'Veg', 'Mild', 15, 1, 1, 'Dairy', ['Vegan Coconut Finish', 'Extra Garlic Tadka'], 35, 50],
      ['Kashmiri Rogan Josh', 'Slow-braised lamb shoulder in saffron, Kashmiri red chili, caramelized shallots, and fennel reduction.', IMG.lamb, 720, 'Main Course', 'Non-Veg', 'Medium', 22, 0, 1, 'None', ['Boneless Cut', 'Extra Gravy'], 20, 35],
      ['Palak Burrata Kofta', 'Spinach and charred paneer medallions floating in silky baby-spinach emulsion with fresh burrata.', IMG.butterChicken, 540, 'Main Course', 'Veg', 'Mild', 16, 0, 0, 'Dairy', ['No Garlic', 'Extra Burrata'], 22, 35],
      ['Truffle Garlic Naan Basket', 'Three blistered sourdough naans brushed with black truffle ghee, roasted garlic, and sea salt flakes.', IMG.butterChicken, 240, 'Main Course', 'Veg', 'Mild', 8, 0, 1, 'Gluten, Dairy', ['Plain Butter', 'Vegan Olive Oil'], 50, 80],

      // Biryani (4)
      ['Chicken Biryani', 'Royal Hyderabadi kacchi dum biryani with saffron-kissed aged basmati, caramelized onions, mint, and burhani raita.', IMG.biryani, 620, 'Biryani', 'Non-Veg', 'Medium', 20, 1, 1, 'Dairy', ['Extra Raita', 'Boneless Chicken', 'Less Spicy'], 30, 50],
      ['Awadhi Mutton Dum Biryani', 'Tender goat morsels sealed in dough with kewra water, rose petals, and long-grain basmati rice.', IMG.biryani, 760, 'Biryani', 'Non-Veg', 'Medium', 24, 1, 1, 'Dairy', ['Extra Saffron', 'Double Masala'], 18, 30],
      ['Subz Nizami Jackfruit Biryani', 'Young tender jackfruit and heirloom vegetables layered with crispy birista, saffron milk, and mint.', IMG.biryani, 520, 'Biryani', 'Vegan', 'Medium', 18, 0, 0, 'None', ['Vegan Raita', 'Extra Mint'], 24, 40],
      ['Prawn Coastal Masala Biryani', 'Jumbo tiger prawns tossed in Malabar spice paste and steamed under fragrant basmati rice.', IMG.biryani, 790, 'Biryani', 'Non-Veg', 'Hot', 20, 0, 0, 'Shellfish, Dairy', ['Mild Spice', 'Extra Curry Leaves'], 14, 25],

      // Continental (5)
      ['Black Truffle Wild Mushroom Risotto', 'Acquerello carnaroli rice slowly folded with chanterelles, aged Parmigiano crisp, and chive oil.', IMG.risotto, 680, 'Continental', 'Veg', 'Mild', 18, 1, 1, 'Dairy', ['Vegan Truffle Oil', 'Extra Parmesan Crisp'], 24, 40],
      ['Herb-Crusted Lamb Rack', 'Pistachio and rosemary crusted New Zealand lamb chops with fondant potato, charred carrots, and jus.', IMG.lamb, 1180, 'Continental', 'Non-Veg', 'Mild', 22, 1, 1, 'Tree Nuts, Dairy', ['Medium Rare', 'Medium Well', 'Nut-Free Herb Crust'], 15, 25],
      ['Pan-Seared Atlantic Salmon', 'Crisp-skinned salmon fillet over saffron cauliflower purée, asparagus spears, and caper beurre blanc.', IMG.lamb, 960, 'Continental', 'Non-Veg', 'Mild', 16, 0, 1, 'Fish, Dairy', ['Sauce on Side', 'Well Done'], 18, 30],
      ['Burrata & Heirloom Tomato Rigatoni', 'Artisanal bronze-die rigatoni tossed in roasted San Marzano confit, torn basil, and creamy burrata.', IMG.risotto, 590, 'Continental', 'Veg', 'Mild', 14, 0, 0, 'Gluten, Dairy', ['Gluten-Free Pasta', 'Add Chili Flakes'], 28, 45],
      ['Charred Cauliflower Steak', 'Harissa-glazed cauliflower steak with tahini emulsion, toasted pine nuts, and pomegranate.', IMG.risotto, 510, 'Continental', 'Vegan', 'Medium', 15, 0, 0, 'Sesame, Nuts', ['Nut-Free', 'Mild Glaze'], 20, 35],

      // Desserts (4)
      ['Saffron Gulab Tiramisu', 'Espresso-soaked savoiardi layered with cardamom mascarpone mousse and warm saffron gulab jamun.', IMG.dessert, 380, 'Desserts', 'Veg', 'Mild', 8, 1, 1, 'Gluten, Dairy', ['No Pistachio', 'Extra Rose Petals'], 26, 45],
      ['Valrhona Dark Chocolate Fondant', 'Warm 70% molten dark chocolate lava cake served with Madagascar vanilla bean gelato.', IMG.dessert, 420, 'Desserts', 'Veg', 'Mild', 12, 0, 1, 'Gluten, Dairy, Eggs', ['Eggless Preparation', 'Extra Gelato'], 20, 35],
      ['Rose & Pistachio Tres Leches', 'Saffron sponge soaked in three infused milks, crowned with whipped cream and crushed Iranian pistachios.', IMG.dessert, 360, 'Desserts', 'Veg', 'Mild', 6, 0, 0, 'Gluten, Dairy, Nuts', ['Less Sweet', 'No Nuts'], 24, 40],
      ['Mango Coconut Panna Cotta', 'Silky Alphonso mango and coconut cream set with passionfruit pearls and mint.', IMG.dessert, 340, 'Desserts', 'Vegan', 'Mild', 6, 0, 0, 'None', ['Extra Passionfruit'], 22, 35],

      // Beverages (5)
      ['Smoked Mango Cardamom Elixir', 'Alphonso mango nectar shaken with green cardamom bitters, lime, and smoked cinnamon mist.', IMG.beverage, 290, 'Beverages', 'Vegan', 'Mild', 5, 1, 1, 'None', ['Zero Sugar', 'Extra Smoke'], 45, 70],
      ['Kokum & Rosemary Tonic', 'Coastal kokum reduction layered over botanical tonic water, charred rosemary, and citrus peel.', IMG.beverage, 260, 'Beverages', 'Vegan', 'Mild', 4, 0, 1, 'None', ['Less Ice', 'Extra Lime'], 40, 60],
      ['Saffron Badam Cold Brew', '18-hour single-origin cold brew finished with saffron almond cream and nutmeg dust.', IMG.beverage, 280, 'Beverages', 'Vegan', 'Mild', 5, 0, 0, 'Tree Nuts', ['Oat Milk Base', 'Unsweetened'], 35, 50],
      ['Spiced Tamarind Ginger Fizz', 'Tangy tamarind syrup, fresh cold-pressed ginger juice, black salt rim, and sparkling soda.', IMG.beverage, 240, 'Beverages', 'Vegan', 'Mild', 4, 0, 0, 'None', ['No Salt Rim', 'Mild Ginger'], 40, 60],
      ['Darjeeling First Flush Kombucha', 'House-fermented floral Darjeeling tea with white peach essence and sparkling effervescence.', IMG.beverage, 270, 'Beverages', 'Vegan', 'Mild', 3, 0, 0, 'None', ['Chilled Glass'], 30, 50],
    ];

    for (const d of dishes) {
      insertDish.run(
        d[0], d[1], d[2], d[3], catMap[d[4]], d[5], d[6], d[7], d[8], d[9], d[10], JSON.stringify(d[11]), d[12], d[13]
      );
    }
  }

  const demoCustomer = db
    .prepare("SELECT id FROM users WHERE email = 'customer@spicestack.io'")
    .get() as { id: number } | undefined;

  // Ensure existing seeded booking SS-4102 is linked to demo customer if unowned
  if (demoCustomer) {
    db.prepare("UPDATE reservations SET user_id = ? WHERE booking_code = 'SS-4102' AND user_id IS NULL").run(
      demoCustomer.id
    );
  }

  // Backfill timestamps on legacy Served tickets from earlier builds if missing
  const legacyTickets = db
    .prepare("SELECT id, target_prep_start, preparation_time FROM kitchen_tickets WHERE status = 'Served' AND (started_at IS NULL OR ready_at IS NULL)")
    .all() as Array<{ id: number; target_prep_start: string; preparation_time: number }>;
  if (legacyTickets.length > 0) {
    const patchTicket = db.prepare('UPDATE kitchen_tickets SET started_at = ?, ready_at = ? WHERE id = ?');
    for (const lt of legacyTickets) {
      const startMs = new Date(lt.target_prep_start).getTime();
      if (!Number.isNaN(startMs)) {
        const readyDate = new Date(startMs + Math.max(1, lt.preparation_time - 1) * 60_000);
        const pad = (n: number) => String(n).padStart(2, '0');
        const readyIso = `${readyDate.getFullYear()}-${pad(readyDate.getMonth() + 1)}-${pad(readyDate.getDate())}T${pad(readyDate.getHours())}:${pad(readyDate.getMinutes())}:00`;
        patchTicket.run(lt.target_prep_start, readyIso, lt.id);
      }
    }
  }

  // Seed initial reservations & historical records (leaving Table 4 completely free at 20:00 today!)
  const resCount = db.prepare('SELECT COUNT(*) as c FROM reservations').get() as { c: number };
  if (resCount.c === 0) {
    const tables = db.prepare('SELECT id, table_number FROM tables').all() as Array<{ id: number; table_number: string }>;
    const tableByNum = Object.fromEntries(tables.map((t) => [t.table_number, t.id]));
    const items = db.prepare('SELECT id, name, price, preparation_time FROM menu_items').all() as Array<{
      id: number; name: string; price: number; preparation_time: number;
    }>;
    const itemByName = Object.fromEntries(items.map((i) => [i.name, i]));

    const insertRes = db.prepare(`
      INSERT INTO reservations (
        booking_code, user_id, customer_name, phone, email, date, arrival_time, party_size, table_id,
        status, checked_in_at, seated_at, completed_at, special_requests,
        subtotal, gst_amount, service_charge_amount, total_amount, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertPreOrder = db.prepare(`
      INSERT INTO pre_orders (
        reservation_id, menu_item_id, item_name_snapshot, price_snapshot, prep_time_snapshot,
        quantity, customization_notes, allergy_notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertTicket = db.prepare(`
      INSERT INTO kitchen_tickets (
        reservation_id, pre_order_id, item_name, quantity, table_number, booking_code,
        target_prep_start, preparation_time, status, priority, allergies, notes, started_at, ready_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const addMinutesToHHMM = (hhmm: string, delta: number): string => {
      const [h, m] = hhmm.split(':').map(Number);
      const total = h * 60 + m + delta;
      const nh = Math.floor(((total + 1440) % 1440) / 60);
      const nm = (total + 1440) % 60;
      return `${String(nh).padStart(2, '0')}:${String(nm).padStart(2, '0')}`;
    };

    const seedBooking = (opts: {
      code: string;
      userId?: number | null;
      name: string;
      phone: string;
      email: string;
      date: string;
      time: string;
      party: number;
      tableNum: string;
      status: string;
      checkedInAt?: string | null;
      seatedAt?: string | null;
      completedAt?: string | null;
      requests?: string;
      dishes: Array<{ name: string; qty: number; notes?: string; allergies?: string; ticketStatus?: string; priority?: string; readyOffsetMin?: number }>;
    }) => {
      let subtotal = 0;
      for (const d of opts.dishes) {
        const item = itemByName[d.name];
        if (item) subtotal += item.price * d.qty;
      }
      const gst = Number((subtotal * 0.05).toFixed(2));
      const svc = Number((subtotal * 0.10).toFixed(2));
      const total = Number((subtotal + gst + svc).toFixed(2));

      const resInfo = insertRes.run(
        opts.code,
        opts.userId ?? null,
        opts.name,
        opts.phone,
        opts.email,
        opts.date,
        opts.time,
        opts.party,
        tableByNum[opts.tableNum] || null,
        opts.status,
        opts.checkedInAt || null,
        opts.seatedAt || null,
        opts.completedAt || null,
        opts.requests || '',
        subtotal,
        gst,
        svc,
        total,
        `${opts.date}T12:00:00`
      );
      const resId = Number(resInfo.lastInsertRowid);

      for (const d of opts.dishes) {
        const item = itemByName[d.name];
        if (!item) continue;
        const poInfo = insertPreOrder.run(
          resId, item.id, item.name, item.price, item.preparation_time, d.qty, d.notes || '', d.allergies || ''
        );
        const poId = Number(poInfo.lastInsertRowid);
        const targetTime = addMinutesToHHMM(opts.time, -item.preparation_time);
        const targetIso = `${opts.date}T${targetTime}:00`;
        const ticketStatus = d.ticketStatus || 'Pending';
        const startedAt =
          ticketStatus === 'Cooking' || ticketStatus === 'Ready' || ticketStatus === 'Served'
            ? `${opts.date}T${targetTime}:00`
            : null;
        const readyTime = addMinutesToHHMM(opts.time, d.readyOffsetMin ?? -1);
        const readyAt =
          ticketStatus === 'Ready' || ticketStatus === 'Served'
            ? `${opts.date}T${readyTime}:00`
            : null;

        insertTicket.run(
          resId, poId, item.name, d.qty, opts.tableNum, opts.code,
          targetIso, item.preparation_time, ticketStatus, d.priority || 'Normal',
          d.allergies || '', d.notes || '', startedAt, readyAt
        );
      }
    };

    const nowDate = new Date();
    // Today's active reservations (Clock starts at 19:25, Table 4 is OPEN at 20:00!)
    seedBooking({
      code: 'SS-4101',
      name: 'Rohan Mehta',
      phone: '+91 98101 44520',
      email: 'rohan.mehta@example.com',
      date: today,
      time: '19:00',
      party: 4,
      tableNum: 'Table 3',
      status: 'Seated',
      checkedInAt: `${today}T18:56:00`,
      seatedAt: `${today}T19:00:00`,
      requests: 'Anniversary celebration',
      dishes: [
        { name: 'Murgh Makhani (Butter Chicken)', qty: 1, notes: 'Less cream', ticketStatus: 'Ready', priority: 'High' },
        { name: 'Truffle Garlic Naan Basket', qty: 1, ticketStatus: 'Ready', priority: 'Normal' },
        { name: 'Saffron Gulab Tiramisu', qty: 2, ticketStatus: 'Cooking', priority: 'Normal' },
      ],
    });

    seedBooking({
      code: 'SS-4102',
      userId: demoCustomer?.id ?? null,
      name: 'Aarav Sharma',
      phone: '+91 98450 11223',
      email: 'customer@spicestack.io',
      date: today,
      time: '19:30',
      party: 2,
      tableNum: 'Table 2',
      status: 'Confirmed',
      requests: 'Window seat preferred',
      dishes: [
        { name: 'Black Truffle Wild Mushroom Risotto', qty: 1, allergies: 'No Pine Nuts', ticketStatus: 'Cooking', priority: 'High' },
        { name: 'Smoked Mango Cardamom Elixir', qty: 2, ticketStatus: 'Pending', priority: 'Normal' },
      ],
    });

    seedBooking({
      code: 'SS-4103',
      name: 'Kabir Malhotra',
      phone: '+91 97400 88219',
      email: 'kabir.m@example.com',
      date: today,
      time: '19:45',
      party: 6,
      tableNum: 'Table 8',
      status: 'Seated',
      checkedInAt: `${today}T19:20:00`,
      seatedAt: `${today}T19:22:00`,
      requests: 'Corporate dinner',
      dishes: [
        { name: 'Herb-Crusted Lamb Rack', qty: 2, notes: 'Medium rare', allergies: 'Peanut allergy at table', ticketStatus: 'Cooking', priority: 'Urgent' },
        { name: 'Old Delhi Lamb Seekh', qty: 2, ticketStatus: 'Pending', priority: 'High' },
      ],
    });

    seedBooking({
      code: 'SS-4104',
      name: 'Priya Nair',
      phone: '+91 98860 33104',
      email: 'priya.nair@example.com',
      date: today,
      time: '20:15',
      party: 4,
      tableNum: 'Table 6',
      status: 'Confirmed',
      dishes: [
        { name: 'Smoked Paneer Tikka', qty: 2, notes: 'Extra mint chutney', ticketStatus: 'Pending', priority: 'Normal' },
        { name: 'Subz Nizami Jackfruit Biryani', qty: 2, ticketStatus: 'Pending', priority: 'Normal' },
      ],
    });

    // Historical reservations over last 14 days for real timestamp-based analytics
    const histNames = [
      ['Devika Sen', '+91 98201 12001'],
      ['Vikramaditya Joshi', '+91 98201 12002'],
      ['Siddharth Rao', '+91 98201 12003'],
      ['Meera Krishnan', '+91 98201 12004'],
      ['Arjun Kapoor', '+91 98201 12005'],
      ['Nandini Bose', '+91 98201 12006'],
      ['Karanbir Gill', '+91 98201 12007'],
    ];
    const histTimes = ['13:00', '18:30', '19:30', '20:00', '20:30', '21:00'];
    const histDishes = [
      'Chicken Biryani',
      'Murgh Makhani (Butter Chicken)',
      'Black Truffle Wild Mushroom Risotto',
      'Smoked Paneer Tikka',
      'Herb-Crusted Lamb Rack',
      'Saffron Gulab Tiramisu',
    ];
    const tableNames = ['Table 1', 'Table 2', 'Table 3', 'Table 4', 'Table 5', 'Table 6', 'Table 7', 'Table 8'];

    for (let i = 1; i <= 14; i++) {
      const dStr = subtractDays(nowDate, i);
      const countForDay = (i % 3) + 1;
      for (let j = 0; j < countForDay; j++) {
        const person = histNames[(i + j) % histNames.length];
        const t = histTimes[(i * 2 + j) % histTimes.length];
        const tbl = tableNames[(i + j * 2) % tableNames.length];
        const dish1 = histDishes[(i + j) % histDishes.length];
        const dish2 = histDishes[(i + j + 2) % histDishes.length];
        const isCancelled = i === 6 && j === 1;
        const durationMin = 68 + ((i * 7 + j * 11) % 24);
        const readyOffset = (i + j) % 5 === 0 ? 2 : -1;
        seedBooking({
          code: `SS-${3000 + i * 10 + j}`,
          userId: i === 2 && j === 0 ? (demoCustomer?.id ?? null) : null,
          name: i === 2 && j === 0 ? 'Aarav Sharma' : person[0],
          phone: i === 2 && j === 0 ? '+91 98450 11223' : person[1],
          email: i === 2 && j === 0 ? 'customer@spicestack.io' : `${person[0].toLowerCase().replace(/\s+/g, '.')}@example.com`,
          date: dStr,
          time: t,
          party: tbl === 'Table 7' || tbl === 'Table 8' ? 6 : tbl === 'Table 1' || tbl === 'Table 2' ? 2 : 4,
          tableNum: tbl,
          status: isCancelled ? 'Cancelled' : 'Completed',
          checkedInAt: isCancelled ? null : `${dStr}T${addMinutesToHHMM(t, -4)}:00`,
          seatedAt: isCancelled ? null : `${dStr}T${t}:00`,
          completedAt: isCancelled ? null : `${dStr}T${addMinutesToHHMM(t, durationMin)}:00`,
          dishes: [
            { name: dish1, qty: 2, ticketStatus: isCancelled ? 'Pending' : 'Served', readyOffsetMin: readyOffset },
            { name: dish2, qty: 1, ticketStatus: isCancelled ? 'Pending' : 'Served', readyOffsetMin: -1 },
          ],
        });
      }
    }
  }
}
