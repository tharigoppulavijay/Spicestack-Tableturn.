import express from 'express';
import path from 'path';
import type { Server as SocketIOServer } from 'socket.io';
import { createApiRouter } from './routes/api.ts';
import {
  errorHandler,
  requestContextMiddleware,
  securityHeadersMiddleware,
} from './middleware/security.ts';

export interface AppOptions {
  enableSpaFallback?: boolean;
}

export function createApp(io?: SocketIOServer, _options: AppOptions = {}): express.Express {
  const app = express();

  app.disable('x-powered-by');
  app.use(securityHeadersMiddleware);
  app.use(requestContextMiddleware);

  // Strict CORS handling for API routes
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    const configuredAppUrl = process.env.APP_URL;
    if (origin) {
      const isLocal =
        origin.startsWith('http://localhost:') ||
        origin.startsWith('http://127.0.0.1:') ||
        origin.endsWith('.run.app');
      if (isLocal || (configuredAppUrl && origin === configuredAppUrl)) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Vary', 'Origin');
        res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Idempotency-Key');
      }
    }
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.use(express.json({ limit: '2mb' }));
  app.use('/uploads', express.static(path.resolve(process.cwd(), 'uploads')));

  app.use('/api', createApiRouter(io));

  // Centralized error handler (API & middleware errors)
  app.use(errorHandler);

  return app;
}
