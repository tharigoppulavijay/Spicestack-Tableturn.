import { z } from 'zod';

const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
const timeRegex = /^([01]\d|2[0-3]):[0-5]\d$/;

export const registerSchema = z
  .object({
    name: z.string().trim().min(2, 'Name must be at least 2 characters').max(80),
    email: z.string().trim().email('Valid email address is required').max(120),
    password: z.string().min(6, 'Password must be at least 6 characters').max(128),
    phone: z.string().trim().max(30).optional().default(''),
  })
  .strict();

export const loginSchema = z
  .object({
    email: z.string().trim().email('Valid email address is required').max(120),
    password: z.string().min(1, 'Password is required').max(128),
  })
  .strict();

export const demoLoginSchema = z
  .object({
    role: z.enum(['customer', 'hostess', 'kitchen', 'manager']),
  })
  .strict();

export const idParamSchema = z
  .object({
    id: z.coerce.number().int().positive('ID must be a positive integer'),
  })
  .strict();

export const tablesQuerySchema = z
  .object({
    date: z.string().regex(dateRegex, 'Date must be YYYY-MM-DD').optional(),
    time: z.string().regex(timeRegex, 'Time must be HH:MM').optional(),
    partySize: z.coerce.number().int().min(1).max(24).optional(),
  })
  .strict();

export const reservationsQuerySchema = z
  .object({
    date: z.string().regex(dateRegex, 'Date must be YYYY-MM-DD').optional(),
    code: z.string().trim().min(1).max(30).optional(),
    phone: z.string().trim().min(1).max(30).optional(),
    search: z.string().trim().max(100).optional(),
    includeArchived: z.enum(['true', 'false']).optional(),
  })
  .strict();

export const analyticsQuerySchema = z
  .object({
    range: z.enum(['today', '7d', '30d']).optional().default('7d'),
  })
  .strict();

export const orderItemInputSchema = z
  .object({
    menu_item_id: z.coerce.number().int().positive('Invalid menu item ID'),
    quantity: z.coerce.number().int().min(1, 'Quantity must be at least 1').max(50, 'Quantity cannot exceed 50'),
    customization_notes: z.string().trim().max(250).optional().default(''),
    allergy_notes: z.string().trim().max(250).optional().default(''),
  })
  .strict();

export const createReservationSchema = z
  .object({
    customer_name: z.string().trim().min(2, 'Guest name is required').max(100),
    phone: z.string().trim().min(6, 'Valid phone number is required').max(30),
    email: z
      .union([z.string().trim().email('Valid email required').max(120), z.literal('')])
      .optional()
      .default(''),
    date: z.string().regex(dateRegex, 'Date must be in YYYY-MM-DD format'),
    arrival_time: z.string().regex(timeRegex, 'Arrival time must be in HH:MM (24h) format'),
    party_size: z.coerce.number().int().min(1, 'Party size must be at least 1').max(20, 'Party size cannot exceed 20'),
    table_id: z.coerce.number().int().positive().nullable().optional(),
    auto_allocate: z.boolean().optional().default(false),
    special_requests: z.string().trim().max(300).optional().default(''),
    items: z.array(orderItemInputSchema).max(50).optional().default([]),
  })
  .strict()
  .refine((data) => Boolean(data.auto_allocate || data.table_id), {
    message: 'Please select a table or choose Auto-Assign Best Table',
    path: ['table_id'],
  });

export const modifyReservationSchema = z
  .object({
    arrival_time: z.string().regex(timeRegex, 'Arrival time must be in HH:MM format').optional(),
    party_size: z.coerce.number().int().min(1).max(20).optional(),
    special_requests: z.string().trim().max(300).optional(),
  })
  .strict()
  .refine(
    (data) =>
      data.arrival_time !== undefined || data.party_size !== undefined || data.special_requests !== undefined,
    { message: 'At least one modification field is required' }
  );

export const staffReservationUpdateSchema = z
  .object({
    status: z.enum(['Confirmed', 'Checked In', 'Seated', 'Completed', 'Cancelled', 'No Show']).optional(),
    arrival_time: z.string().regex(timeRegex, 'Arrival time must be in HH:MM format').optional(),
    table_id: z.coerce.number().int().positive().optional(),
  })
  .strict()
  .refine(
    (data) => data.status !== undefined || data.arrival_time !== undefined || data.table_id !== undefined,
    { message: 'At least one update field is required' }
  );

export const createTableSchema = z
  .object({
    table_number: z.string().trim().min(1, 'Table number is required').max(40),
    capacity: z.coerce.number().int().min(1).max(24),
    type: z.string().trim().max(60).optional().default('Main Dining'),
    section: z.string().trim().max(60).optional().default('Main Hall'),
    description: z.string().trim().max(250).optional().default(''),
    status: z
      .enum(['Available', 'Reserved', 'Occupied', 'Cleaning', 'Maintenance', 'Disabled'])
      .optional()
      .default('Available'),
  })
  .strict();

export const updateTableSchema = createTableSchema
  .partial()
  .extend({
    is_active: z.coerce.number().int().min(0).max(1).optional(),
  })
  .strict();

export const createCategorySchema = z
  .object({
    name: z.string().trim().min(1, 'Category name is required').max(60),
  })
  .strict();

export const updateCategorySchema = z
  .object({
    name: z.string().trim().min(1).max(60).optional(),
    display_order: z.coerce.number().int().min(0).max(999).optional(),
  })
  .strict()
  .refine((data) => data.name !== undefined || data.display_order !== undefined, {
    message: 'Category name or display_order is required',
  });

export const createMenuItemSchema = z
  .object({
    name: z.string().trim().min(1, 'Dish name is required').max(120),
    description: z.string().trim().max(500).optional().default(''),
    image: z.string().trim().max(500).optional(),
    price: z.coerce.number().min(0, 'Price cannot be negative').max(100000),
    category_id: z.coerce.number().int().positive('Category is required'),
    dietary_type: z.enum(['Veg', 'Non-Veg', 'Vegan']).optional().default('Veg'),
    spicy_level: z.enum(['Mild', 'Medium', 'Hot', 'Extra Hot']).optional().default('Medium'),
    preparation_time: z.coerce.number().int().min(1).max(180).optional().default(15),
    is_chef_special: z.union([z.boolean(), z.number()]).optional().default(false),
    is_popular: z.union([z.boolean(), z.number()]).optional().default(false),
    allergy_info: z.string().trim().max(200).optional().default(''),
    customization_options: z.array(z.string().trim().max(80)).max(20).optional().default([]),
    availability: z.union([z.boolean(), z.number()]).optional().default(true),
    stock_quantity: z.coerce.number().int().min(0).max(10000).optional().default(25),
    daily_limit: z.coerce.number().int().min(0).max(10000).optional().default(40),
  })
  .strict();

export const updateMenuItemSchema = createMenuItemSchema.partial().strict();

export const inventoryPatchSchema = z
  .object({
    stock_quantity: z.coerce.number().int().min(0).max(10000).optional(),
    availability: z.union([z.boolean(), z.number()]).optional(),
    daily_limit: z.coerce.number().int().min(0).max(10000).optional(),
  })
  .strict()
  .refine(
    (data) =>
      data.stock_quantity !== undefined || data.availability !== undefined || data.daily_limit !== undefined,
    { message: 'At least one inventory field (stock_quantity, availability, or daily_limit) is required' }
  );

export const kitchenTicketUpdateSchema = z
  .object({
    status: z.enum(['Pending', 'Cooking', 'Ready', 'Served']).optional(),
    priority: z.enum(['Normal', 'High', 'Urgent']).optional(),
  })
  .strict()
  .refine((data) => Boolean(data.status || data.priority), {
    message: 'At least status or priority must be provided',
  });

export const updateSettingsSchema = z
  .object({
    restaurant_name: z.string().trim().min(1).max(120).optional(),
    logo_url: z.string().trim().max(500).optional(),
    address: z.string().trim().max(250).optional(),
    phone: z.string().trim().max(40).optional(),
    email: z.string().trim().email().max(120).optional(),
    opening_hours: z
      .string()
      .trim()
      .regex(
        /^([01]\d|2[0-3]):[0-5]\d\s*-\s*([01]\d|2[0-3]):[0-5]\d$/,
        'Opening hours must use HH:MM - HH:MM format (e.g., 12:00 - 23:30)'
      )
      .refine(
        (val) => {
          const parts = val.split('-').map((s) => s.trim());
          if (parts.length !== 2) return false;
          const [openStr, closeStr] = parts;
          if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(openStr) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(closeStr)) {
            return false;
          }
          const [oh, om] = openStr.split(':').map(Number);
          const [ch, cm] = closeStr.split(':').map(Number);
          return ch * 60 + cm > oh * 60 + om;
        },
        { message: 'Closing time must be later than opening time' }
      )
      .optional(),
    dining_duration: z.coerce.number().int().min(30).max(300).optional(),
    gst_percentage: z.coerce.number().min(0).max(50).optional(),
    service_charge_percentage: z.coerce.number().min(0).max(50).optional(),
    currency: z.string().trim().min(1).max(8).optional(),
    slot_interval_minutes: z.coerce.number().int().min(15).max(120).optional(),
    max_advance_days: z.coerce.number().int().min(1).max(365).optional(),
  })
  .strict();

export const clockUpdateSchema = z
  .object({
    mode: z.enum(['simulated', 'live']).optional(),
    time: z.string().regex(timeRegex, 'Time must be HH:MM').optional(),
    date: z.string().regex(dateRegex, 'Date must be YYYY-MM-DD').optional(),
    advanceMinutes: z.coerce.number().int().min(-1440).max(1440).optional(),
  })
  .strict()
  .refine(
    (data) =>
      data.mode !== undefined ||
      data.time !== undefined ||
      data.date !== undefined ||
      data.advanceMinutes !== undefined,
    { message: 'At least one clock control parameter is required' }
  );

export const uploadMetadataSchema = z
  .object({
    alt: z.string().trim().max(120).optional(),
    dishName: z.string().trim().max(120).optional(),
  })
  .strict();

export const billCalculationSchema = z
  .object({
    items: z
      .array(
        z
          .object({
            id: z.coerce.number().int().positive().optional(),
            price: z.coerce.number().min(0).max(100000),
            quantity: z.coerce.number().int().min(0).max(100),
          })
          .strict()
      )
      .max(100),
    gst_percentage: z.coerce.number().min(0).max(50).optional(),
    service_charge_percentage: z.coerce.number().min(0).max(50).optional(),
    discount_percentage: z.coerce.number().min(0).max(100).optional().default(0),
    discount_amount: z.coerce.number().min(0).max(1000000).optional().default(0),
  })
  .strict();

export const splitBillSchema = z
  .object({
    mode: z.enum(['equal', 'itemized']),
    total_amount: z.coerce.number().min(0).max(10000000).optional(),
    diners: z.coerce.number().int().min(1).max(50).optional(),
    items: z
      .array(
        z
          .object({
            id: z.coerce.number().int().positive(),
            price: z.coerce.number().min(0).max(100000),
            quantity: z.coerce.number().int().min(0).max(100),
          })
          .strict()
      )
      .max(100)
      .optional(),
    selected_item_ids: z.array(z.coerce.number().int().positive()).max(100).optional(),
    gst_percentage: z.coerce.number().min(0).max(50).optional(),
    service_charge_percentage: z.coerce.number().min(0).max(50).optional(),
  })
  .strict()
  .refine(
    (data) =>
      (data.mode === 'equal' && data.total_amount !== undefined && data.diners !== undefined) ||
      (data.mode === 'itemized' && data.items !== undefined && data.selected_item_ids !== undefined),
    { message: 'Invalid split-bill payload for the selected split mode' }
  );
