import { db } from '../database/db.ts';
import type {
  ClockState,
  KitchenTicket,
  Reservation,
  RestaurantSettings,
  RestaurantTable,
  TicketPriority,
} from '../../src/types/index.ts';

export function getSettings(): RestaurantSettings {
  return db.prepare('SELECT * FROM restaurant_settings WHERE id = 1').get() as RestaurantSettings;
}

export function formatLocalDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatLocalTimeHHMM(d: Date): string {
  const h = String(d.getHours()).padStart(2, '0');
  const m = String(d.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

export function formatDisplay12h(hhmm: string): string {
  const [hStr, mStr] = hhmm.split(':');
  let h = Number(hStr);
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h}:${mStr} ${ampm}`;
}

export function getClockState(): ClockState {
  const settings = getSettings();
  let effectiveDate: Date;

  if (settings.clock_mode === 'simulated' && settings.simulated_time) {
    effectiveDate = new Date(settings.simulated_time);
    if (Number.isNaN(effectiveDate.getTime())) {
      effectiveDate = new Date();
    }
  } else {
    effectiveDate = new Date();
  }

  const current_date = formatLocalDate(effectiveDate);
  const current_time = formatLocalTimeHHMM(effectiveDate);
  return {
    mode: settings.clock_mode,
    current_iso: `${current_date}T${current_time}:00`,
    current_date,
    current_time,
    display_time: formatDisplay12h(current_time),
  };
}

export function parseDateTime(dateStr: string, timeHHMM: string): Date {
  return new Date(`${dateStr}T${timeHHMM}:00`);
}

export function calculateTargetPrepStart(date: string, arrivalTime: string, prepMinutes: number): string {
  const arrivalDate = parseDateTime(date, arrivalTime);
  const target = new Date(arrivalDate.getTime() - prepMinutes * 60_000);
  return `${formatLocalDate(target)}T${formatLocalTimeHHMM(target)}:00`;
}

export function timeToMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

export function minutesToHHMM(totalMinutes: number): string {
  const wrapped = ((totalMinutes % 1440) + 1440) % 1440;
  const h = Math.floor(wrapped / 60);
  const m = wrapped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function addDaysToDate(dateStr: string, days: number): string {
  const d = new Date(`${dateStr}T00:00:00`);
  d.setDate(d.getDate() + days);
  return formatLocalDate(d);
}

export function isWithinOpeningHours(arrivalTime: string, openingHours = '11:00 - 23:30'): boolean {
  const parts = openingHours.split('-').map((s) => s.trim());
  const openMin = timeToMinutes(parts[0] || '11:00');
  const closeMin = timeToMinutes(parts[1] || '23:30');
  const arrMin = timeToMinutes(arrivalTime);
  if (Number.isNaN(arrMin) || Number.isNaN(openMin) || Number.isNaN(closeMin)) return false;
  if (closeMin >= openMin) {
    return arrMin >= openMin && arrMin <= closeMin - 30;
  }
  return arrMin >= openMin || arrMin <= closeMin - 30;
}

export function computeTicketRuntime(
  ticket: KitchenTicket & { reservation_date?: string; arrival_time?: string; reservation_status?: string },
  clock: ClockState
): KitchenTicket {
  const nowMs = new Date(clock.current_iso).getTime();
  const targetMs = new Date(ticket.target_prep_start).getTime();
  const arrivalIso =
    ticket.reservation_date && ticket.arrival_time
      ? `${ticket.reservation_date}T${ticket.arrival_time}:00`
      : null;
  const arrivalMs = arrivalIso ? new Date(arrivalIso).getTime() : targetMs + ticket.preparation_time * 60_000;

  const minutesUntilArrival = Math.round((arrivalMs - nowMs) / 60_000);
  const minutesUntilFire = Math.round((targetMs - nowMs) / 60_000);

  let shouldFireNow = false;
  let isOverdue = false;
  let fireAlertMessage: string | null = null;
  let cookingRemainingMinutes: number | null = null;
  let effectivePriority: TicketPriority = ticket.priority;

  if (ticket.status === 'Pending') {
    if (ticket.reservation_status === 'Checked In' || ticket.reservation_status === 'Seated') {
      shouldFireNow = true;
      effectivePriority = 'Urgent';
      fireAlertMessage =
        minutesUntilArrival > 0
          ? `GUEST CHECKED IN — FIRE DISH NOW (${minutesUntilArrival}M EARLY)`
          : 'GUEST AT TABLE — FIRE DISH IMMEDIATELY';
    } else if (minutesUntilFire <= 0) {
      shouldFireNow = true;
      effectivePriority = 'Urgent';
      if (minutesUntilArrival > 0) {
        fireAlertMessage = `FIRE DISH NOW — GUEST ARRIVES IN ${minutesUntilArrival} MINUTES`;
      } else {
        isOverdue = true;
        fireAlertMessage = `OVERDUE FIRE — GUEST ARRIVED ${Math.abs(minutesUntilArrival)}M AGO`;
      }
      if (minutesUntilFire <= -5) {
        isOverdue = true;
      }
    } else if (minutesUntilFire <= 5 && effectivePriority === 'Normal') {
      effectivePriority = 'High';
    }
  } else if (ticket.status === 'Cooking') {
    const startedMs = ticket.started_at ? new Date(ticket.started_at).getTime() : nowMs;
    const elapsedMin = Math.max(0, Math.round((nowMs - startedMs) / 60_000));
    cookingRemainingMinutes = Math.max(0, ticket.preparation_time - elapsedMin);
    if (elapsedMin > ticket.preparation_time + 3) {
      isOverdue = true;
    }
  }

  return {
    ...ticket,
    priority: effectivePriority,
    minutes_until_arrival: minutesUntilArrival,
    minutes_until_fire: minutesUntilFire,
    should_fire_now: shouldFireNow,
    is_overdue: isOverdue,
    fire_alert_message: fireAlertMessage,
    cooking_remaining_minutes: cookingRemainingMinutes,
  };
}

export function deriveCustomerOrderStage(
  reservation: Reservation,
  tickets: KitchenTicket[]
): string {
  if (reservation.status === 'Cancelled') return 'Cancelled';
  if (reservation.status === 'Completed') return 'Served';
  if (tickets.length === 0) {
    return reservation.status === 'Checked In' || reservation.status === 'Seated'
      ? 'Guest Checked In'
      : 'Reservation Confirmed';
  }
  const statuses = tickets.map((t) => t.status);
  if (statuses.every((s) => s === 'Served')) return 'Served';
  if (statuses.every((s) => s === 'Ready' || s === 'Served')) return 'Ready / Plated';
  if (statuses.some((s) => s === 'Cooking' || s === 'Ready')) return 'Cooking';
  if (tickets.some((t) => t.should_fire_now)) return 'Waiting for Preparation';
  return 'Order Confirmed';
}

export function getTablesWithAvailability(
  date?: string,
  time?: string,
  partySize?: number,
  excludeReservationId?: number
): RestaurantTable[] {
  const settings = getSettings();
  const diningDuration = settings.dining_duration || 90;
  const clock = getClockState();
  const tables = db
    .prepare('SELECT * FROM tables ORDER BY id ASC')
    .all() as RestaurantTable[];

  const targetDate = date || clock.current_date;
  const activeReservations = db
    .prepare(
      `SELECT * FROM reservations 
       WHERE date = ? AND status NOT IN ('Cancelled', 'Completed', 'No Show')`
    )
    .all(targetDate) as Reservation[];

  return tables.map((table) => {
    const currentBooking = activeReservations.find(
      (r) =>
        r.id !== excludeReservationId &&
        r.table_id === table.id &&
        (r.status === 'Seated' || r.status === 'Checked In')
    );
    let estimatedTurnTime: string | null = null;
    let minutesRemaining: number | null = null;

    if (currentBooking) {
      const startHHMM = currentBooking.seated_at
        ? currentBooking.seated_at.slice(11, 16)
        : currentBooking.arrival_time;
      const startMin = timeToMinutes(startHHMM);
      const endMin = startMin + diningDuration;
      const nowMin = timeToMinutes(clock.current_time);
      minutesRemaining = Math.max(5, endMin - nowMin);
      estimatedTurnTime = formatDisplay12h(minutesToHHMM(endMin));
    }

    if (!date || !time) {
      return {
        ...table,
        is_available_for_slot:
          table.is_active === 1 &&
          table.status !== 'Disabled' &&
          table.status !== 'Maintenance' &&
          table.status !== 'Cleaning',
        conflict_reason: null,
        estimated_turn_time: estimatedTurnTime,
        minutes_remaining: minutesRemaining,
      };
    }

    if (table.is_active !== 1 || table.status === 'Disabled') {
      return {
        ...table,
        is_available_for_slot: false,
        conflict_reason: 'Table disabled by manager',
        estimated_turn_time: estimatedTurnTime,
        minutes_remaining: minutesRemaining,
      };
    }

    if (table.status === 'Maintenance') {
      return {
        ...table,
        is_available_for_slot: false,
        conflict_reason: 'Under maintenance',
        estimated_turn_time: estimatedTurnTime,
        minutes_remaining: minutesRemaining,
      };
    }

    if (date === clock.current_date && table.status === 'Cleaning') {
      const reqStart = timeToMinutes(time);
      const nowMin = timeToMinutes(clock.current_time);
      if (Math.abs(reqStart - nowMin) < 20) {
        return {
          ...table,
          is_available_for_slot: false,
          conflict_reason: 'Currently being sanitized',
          estimated_turn_time: estimatedTurnTime,
          minutes_remaining: minutesRemaining,
        };
      }
    }

    if (partySize && table.capacity < partySize) {
      return {
        ...table,
        is_available_for_slot: false,
        conflict_reason: `Capacity ${table.capacity} < ${partySize} guests`,
        estimated_turn_time: estimatedTurnTime,
        minutes_remaining: minutesRemaining,
      };
    }

    const reqStart = timeToMinutes(time);
    const reqEnd = reqStart + diningDuration;

    const overlapping = activeReservations.find((r) => {
      if (r.id === excludeReservationId || r.table_id !== table.id) return false;
      const resStart = timeToMinutes(r.arrival_time);
      const resEnd = resStart + diningDuration;
      return reqStart < resEnd && resStart < reqEnd;
    });

    if (overlapping) {
      return {
        ...table,
        is_available_for_slot: false,
        conflict_reason: `Booked at ${formatDisplay12h(overlapping.arrival_time)} (${diningDuration}m window)`,
        estimated_turn_time: estimatedTurnTime,
        minutes_remaining: minutesRemaining,
      };
    }

    return {
      ...table,
      is_available_for_slot: true,
      conflict_reason: null,
      estimated_turn_time: estimatedTurnTime,
      minutes_remaining: minutesRemaining,
    };
  });
}

export function allocateBestTable(
  date: string,
  time: string,
  partySize: number,
  excludeReservationId?: number
): RestaurantTable | null {
  const candidates = getTablesWithAvailability(date, time, partySize, excludeReservationId)
    .filter((t) => t.is_available_for_slot)
    .sort((a, b) => a.capacity - b.capacity || a.id - b.id);
  return candidates[0] || null;
}

export function restoreStockForReservation(reservationId: number): void {
  const preOrders = db
    .prepare('SELECT menu_item_id, quantity FROM pre_orders WHERE reservation_id = ?')
    .all(reservationId) as Array<{ menu_item_id: number | null; quantity: number }>;

  const restoreStmt = db.prepare(`
    UPDATE menu_items
    SET stock_quantity = stock_quantity + ?,
        availability = CASE WHEN is_deleted = 0 AND (stock_quantity + ?) > 0 THEN 1 ELSE availability END
    WHERE id = ?
  `);

  for (const po of preOrders) {
    if (po.menu_item_id) {
      restoreStmt.run(po.quantity, po.quantity, po.menu_item_id);
    }
  }
}
